<?php
/**
 *    This file is part of OXID eShop Community Edition.
 *
 *    OXID eShop Community Edition is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    OXID eShop Community Edition is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with OXID eShop Community Edition.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @link http://www.oxid-esales.com
 * @package updateApp
 * @copyright (C) OXID eSales AG 2003-2011
 * @version OXID eShop CE
 */

/**
 * base updater class, used for providing base utility functions
 */
class updateBase extends oxSuperCfg
{
    private $_oProcess = null;
    protected $_iRev = 0;
    static $SQL_TIME_LIMIT = 7;

    /**
     * constructor
     *
     * @param updateProcess $oProcess parent process
     * @param int           $iRev     revision for this update
     */
    public function __construct(updateProcess $oProcess, $iRev)
    {
        $this->_oProcess = $oProcess;
        $this->_iRev = $iRev;

        if ( $this->getConfig()->isUtf() ) {
            oxDb::getDb( true )->execute( "SET CHARACTER SET latin1" );
        }
    }

    /**
     * process object getter
     *
     * @return updateProcess
     */
    protected function _getProcess()
    {
        return $this->_oProcess;
    }

    /**
     * default action, used in start update
     *
     * @var string
     */
    protected $_sDefaultAction = 'updateSql';

    /**
     * revisioned updater entry
     * returns next action
     *
     * @param string $sAction action to execute
     * @param mixed  $data    action data
     *
     * @return null
     */
    public function update($sAction, $data)
    {
        if (!$sAction) {
            $sAction = $this->_sDefaultAction;
        }

        if ($sAction && method_exists($this, $sAction)) {
            $oUi = $this->_getProcess()->getUI();
            $oNote = $oUi->createTextNotification();
            $oNote->setText("[exec:] rev: $this->_iRev action: $sAction");
            $oUi->addInfoForUser($oNote, false);

            $sNext = $this->$sAction($data);
            $sNextData = 0;
            if (is_array($sNext) && count($sNext) == 2) {
                $sNextData = $sNext[1];
                $sNext = $sNext[0];
            }
            $iNextRev = $sNext ? $this->_iRev : $this->_iRev + 1;
            $this->_getProcess()->getTracker()->setNextStep(
                    $iNextRev,
                    $sNext,
                    $sNextData
            );
        } else {
            throw new Exception("action $sAction not found");
        }
    }

    /**
     * parse sql file to array
     *
     * @param int $iRev     revision
     * @param int $iCounter counter to slice from
     *
     * @return array
     */
    public function getSqlArray($iRev, $iCounter)
    {
        $sFile = $this->_getProcess()->getConfig()->getSqlPath()."/$iRev.sql";
        if (is_readable($sFile)) {
            $aSqls = preg_split('/;[\s]*$/m', file_get_contents($sFile));
            if ($iCounter) {
                $aSqls = array_slice($aSqls, $iCounter);
            }
            return $aSqls;
        }
        return array();
    }

    /**
     * updates sql and keeps track of last executed one
     *
     * @param int $iInStepCounter sql counter
     *
     * @return string
     */
    public function updateSql($iInStepCounter)
    {
        $iInStepCounter = (int) $iInStepCounter;
        $aSqls = $this->getSqlArray($this->_iRev, $iInStepCounter);
        if (count($aSqls)) {
            $oUi = $this->_getProcess()->getUI();
            $oNote = $oUi->createTextNotification();
            $start = time();
            foreach ($aSqls as $sSql) {
                $this->_getProcess()->getTracker()->setNextStep($this->_iRev, 'updateSql', ++$iInStepCounter);
                $sSql = trim($sSql);
                if ($sSql) {
                    $oNote->setText("[SQL:] $sSql");
                    $oUi->addInfoForUser($oNote, false);
                    oxDb::getDb()->execute($sSql);
                }
                if (time() - self::$SQL_TIME_LIMIT > $start) {
                    return array('updateSql', $iInStepCounter);
                }
            }
        }
        return '';
    }
}
