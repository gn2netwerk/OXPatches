<?php
/**
 *    This file is part of OXID eShop Community Edition.
 *
 *    OXID eShop Community Edition is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    OXID eShop Community Edition is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with OXID eShop Community Edition.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @link http://www.oxid-esales.com
 * @package updateApp
 * @copyright (C) OXID eSales AG 2003-2011
 * @version OXID eShop CE
 */


/**
 * update class for rev.
 */
class update_34028 extends updateBase
{
    /**
     * default action, used in start update
     *
     * @var string
     */
    protected $_sDefaultAction = 'requestTemplatesFilesStructureUpdate';

    protected $_aMultilingualFields = array('OXPIC' => 'oxactions',
                                            'OXLINK' => 'oxactions',
                                            'OXTHUMB' => 'oxcategories',
                                            'OXLONGDESC' => 'oxpayments');

    protected $_aTemplateMap = array(
        '/_footer_plain.tpl' => '/_footer_plain.tpl',
        '/_footer.tpl' => '/_footer.tpl',
        '/_header_plain.tpl' => '/_header_plain.tpl',
        '/_header.tpl' => '/_header.tpl',
        '/_left.tpl' => '/_left.tpl',
        '/_path.tpl' => '/_path.tpl',
        '/_right.tpl' => '/_right.tpl',
        '/account_login_alt.tpl' => '/page/privatesales/login.tpl',
        '/account_login.tpl' => '/page/account/login.tpl',
        '/account_main.tpl' => '/page/account/dashboard.tpl',
        '/account_newsletter.tpl' => '/page/account/newsletter.tpl',
        '/account_noticelist.tpl' => '/page/account/noticelist.tpl',
        '/account_order.tpl' => '/page/account/order.tpl',
        '/account_password.tpl' => '/page/account/password.tpl',
        '/account_recommlist.tpl' => '/page/account/recommendationedit.tpl',
        '/account_user.tpl' => '/page/account/user.tpl',
        '/account_wishlist.tpl' => '/page/account/wishlist.tpl',
        '/basket.tpl' => '/page/checkout/basket.tpl',
        '/compare_popup.tpl' => '/compare_popup.tpl',
        '/compare.tpl' => '/page/compare/compare.tpl',
        '/contact.tpl' => '/page/info/contact.tpl',
        '/content_plain.tpl' => '/page/info/content_plain.tpl',
        '/content.tpl' => '/page/info/content.tpl',
        '/details.tpl' => '/page/details/details.tpl',
        '/email_forgotpwd_html.tpl' => '/email/html/forgotpwd.tpl',
        '/email_forgotpwd_plain.tpl' => '/email/plain/forgotpwd.tpl',
        '/email_invite_html.tpl' => '/email/html/invite.tpl',
        '/email_invite_plain.tpl' => '/email/plain/invite.tpl',
        '/email_newsletteroptin_html.tpl' => '/email/html/newsletteroptin.tpl',
        '/email_newsletteroptin_plain.tpl' => '/email/plain/newsletteroptin.tpl',
        '/email_order_cust_html.tpl' => '/email/html/order_cust.tpl',
        '/email_order_cust_plain.tpl' => '/email/plain/order_cust.tpl',
        '/email_order_owner_html.tpl' => '/email/html/order_owner.tpl',
        '/email_order_owner_plain.tpl' => '/email/plain/order_owner.tpl',
        '/email_owner_reminder_html.tpl' => '/email/html/owner_reminder.tpl',
        '/email_pricealarm_owner.tpl' => '/email/html/pricealarm_owner.tpl',
        '/email_register_html.tpl' => '/email/html/register.tpl',
        '/email_register_plain.tpl' => '/email/plain/register.tpl',
        '/email_sendednow_html.tpl' => '/email/html/sendednow.tpl',
        '/email_sendednow_plain.tpl' => '/email/plain/sendednow.tpl',
        '/email_suggest_html.tpl' => '/email/html/suggest.tpl',
        '/email_suggest_plain.tpl' => '/email/plain/suggest.tpl',
        '/email_wishlist_html.tpl' => '/email/html/wishlist.tpl',
        '/email_wishlist_plain.tpl' => '/email/plain/wishlist.tpl',
        '/err_404.tpl' => '/message/err_404.tpl',
        '/err_accessdenied.tpl' => '/message/err_accessdenied.tpl',
        '/err_expired_days.tpl' => '/message/err_expired_days.tpl',
        '/err_mandates_exceeded.tpl' => '/message/err_mandates_exceeded.tpl',
        '/err_setup.tpl' => '/message/err_setup.tpl',
        '/err_unknown.tpl' => '/message/err_unknown.tpl',
        '/err_unlicensed.tpl' => '/message/err_unlicensed.tpl',
        '/err_update.tpl' => '/message/err_update.tpl',
        '/forgotpwd.tpl' => '/page/account/forgotpwd.tpl',
        '/guestbook_login.tpl' => '/page/guestbook/guestbook_login.tpl',
        '/guestbook.tpl' => '/page/guestbook/guestbook.tpl',
        '/guestbookentry.tpl' => '/page/guestbook/guestbookentry.tpl',
        '/help.tpl' => '/help.tpl',
        '/impressum.tpl' => '/impressum.tpl',
        '/invite.tpl' => '/page/privatesales/invite.tpl',
        '/links.tpl' => '/page/info/links.tpl',
        '/list_more.tpl' => '/page/list/morecategories.tpl',
        '/list.tpl' => '/page/list/list.tpl',
        '/mallstart.tpl' => '/page/shop/mallstart.tpl',
        '/moredetails.tpl' => '/moredetails.tpl',
        '/news.tpl' => '/page/info/news.tpl',
        '/newsletter.tpl' => '/page/info/newsletter.tpl',
        '/order.tpl' => '/page/checkout/order.tpl',
        '/payment.tpl' => '/page/checkout/payment.tpl',
        '/pricealarm.tpl' => '/pricealarm.tpl',
        '/recommadd.tpl' => '/page//account/recommendationadd.tpl',
        '/recommlist.tpl' => '/page/recommendations/recommlist.tpl',
        '/register_confirm.tpl' => '/page/account/register_confirm.tpl',
        '/register_success.tpl' => '/page/account/register_success.tpl',
        '/register.tpl' => '/page/account/register.tpl',
        '/review_login.tpl' => '/review_login.tpl',
        '/review.tpl' => '/review.tpl',
        '/rss.tpl' => '/widget/rss.tpl',
        '/search.tpl' => '/page/search/search.tpl',
        '/security_info.tpl' => '/security_info.tpl',
        '/start.tpl' => '/page/shop/start.tpl',
        '/suggest.tpl' => '/page/info/suggest.tpl',
        '/tags.tpl' => '/page/tags/tags.tpl',
        '/thankyou.tpl' => '/page/checkout/thankyou.tpl',
        '/user_blocked.tpl' => '/user_blocked.tpl',
        '/user.tpl' => '/page/checkout/user.tpl',
        '/wishlist.tpl' => '/page/wishlist/wishlist.tpl',
        '/wrapping.tpl' => '/page/checkout/wrapping.tpl',
    );

    protected $_aDeprecatedMap = array(
        '/page/shop/start.tpl' => array (
            '[{if $rsslinks.newestArticles}]' => '[{assign var="rsslinks" value=$oView->getRssLinks()}][{if $rsslinks.newestArticles}]',
        ),

        '/page/shop/mallstart.tpl' => array (
            '$meta_description' => '$oView->getMetaDescription()',
            '$meta_keywords' => '$oView->getMetaKeywords()',
            '$oViewConf->getImageDir()' => '$oViewConf->getImageUrl()',
        ),

        // no deprecated
        '/page/tags/tags.tpl' => array (),

        '/page/wishlist/wishlist.tpl' => array (
            '$search' => '$oView->getWishListSearchParam()',
            '[{if $oView->getWishUser()}]' => '[{if $oView->getWishUser()}][{assign var="wishuser" value=$oView->getWishUser()}]',
        ),

        '/page/search/search.tpl' => array (
            '[{assign var="template_title" value="$search_title - $searchparamforhtml"}]' => '[{assign var="searchparamforhtml" value=$oView->getSearchParamForHtml() }][{assign var="template_title" value="$search_title - $searchparamforhtml"}]',
            '$pageNavigation->iArtCnt' => '$oView->getArticleCount()',
        ),

        '/page/recommendations/recommlist.tpl' => array (
            '$rate' => '$oView->canRate()',
            '$pageNavigation->iArtCnt' => '$oView->getArticleCount()',
            '[{if $rsslinks.recommlistarts}]' => '[{assign var="rsslinks" value=$oView->getRssLinks()}][{if $rsslinks.recommlistarts}]',
            '$oView->getActiveRecommItems()' => '$oView->getArticleList()'
        ),

        '/page/privatesales/invite.tpl' => array (
            '$success' => '$oView->getInviteSendStatus()'
        ),

        '/page/privatesales/login.tpl' => array (
            '$charset' => '$oView->getCharSet()',
            '$tpl' => '$oViewConf->getActTplName()'
        ),

        '/page/list/list.tpl' => array (
            '[{assign var="pageNavigation" value=$oView->getPageNavigation()}]' => '',
            '$pageNavigation->iArtCnt' => '$oView->getArticleCount()',
            '$tpl' => '$oViewConf->getActTplName()',
            '[{ $actCategory->oxcategories__oxlongdesc->value }]' => '[{oxeval var=$actCategory->oxcategories__oxlongdesc}]',
            '[{if $rsslinks.activeCategory}]' => '[{assign var="rsslinks" value=$oView->getRssLinks()}][{if $rsslinks.activeCategory}]',
            '$oFilterAttr->aValues' => '$oFilterAttr->getValues()',
            'item=oValue' => 'item=sValue',
            '$oValue->id' => '$sValue',
            '$oValue->value' => '$sValue',
            '$oValue->blSelected' => '$oFilterAttr->getActiveValue() == $sValue',
            '[{if $category->oxcategories__oxicon->value }]' => '[{assign var="iconUrl" value=$category->getIconUrl()}][{if $iconUrl}]',
        ),

        // no deprecated
        '/page/list/morecategories.tpl' => array (),

        // no deprecated
        '/page/info/contact.tpl' => array (),

        // no deprecated
        '/page/info/content_plain.tpl' => array (),

        '/page/info/content.tpl' => array (
            '[{include file="_header.tpl" title=$template_title location=$template_title}]' => '[{assign var="tpl" value=$oViewConf->getActTplName()}][{include file="_header.tpl" title=$template_title location=$template_title}]'
        ),

        // no deprecated
        '/page/info/links.tpl' => array (),

        '/page/info/news.tpl' => array (
            '[{ $oNews->oxnews__oxlongdesc->value}]' => '[{oxeval var=$oNews->oxnews__oxlongdesc force=1}]'
        ),

        // no deprecated
        '/page/info/newsletter.tpl' => array (),

        // no deprecated
        '/page/info/suggest.tpl' => array (),

        // no deprecated
        '/page/guestbook/guestbook_login.tpl' => array (),

        '/page/guestbook/guestbook.tpl' => array (
            'pageNavigation=$oView->getPageNavigation()' => '',
        ),

        // no deprecated
        '/page/guestbook/guestbookentry.tpl' => array (),

        '/page/details/details.tpl' => array (
            '$reviews' => '$oView->getReviews()',
            '$isfiltering && ' => '',
            'isfiltering=false' => '',
            '$pageNavigation->actPage-1' => '$oView->getActPage()',
            '[{ $product->oxarticles__oxlongdesc->value }]' => '[{oxeval var=$product->getArticleLongDesc()}]'
        ),

        '/page/compare/compare.tpl' => array (
            'pageNavigation=$oView->getPageNavigation()' => '',
        ),

        '/page/checkout/basket.tpl' => array (
            '$basketproduct->selectlist' => '$basketproduct->getDispSelList()',
            '$basketitem->sProduct' => '$basketitem->getProductId()',
        ),

        '/page/checkout/order.tpl' => array (
            '$basketitem->blSkipDiscounts' => '$basketitem->isSkipDiscount()',
            '$basketitem->sProduct' => '$basketitem->getProductId()',
        ),

        '/page/checkout/payment.tpl' => array (
            '$creditYears' => '$oView->getCreditYears()',
            '$paymencnt' => '$oView->getPaymentCnt()',
            '$oTsProduct->sTsId' => '$oTsProduct->getTsId()',
            '$oTsProduct->iAmount' => '$oTsProduct->getAmount()',
            '$oTsProduct->fPrice' => '$oTsProduct->getFPrice()',
            '[{elseif $sPaymentID == "oxidcreditcard"}]' => '[{elseif $sPaymentID == "oxidcreditcard"}][{ assign var="dynvalue" value=$oView->getDynValue()}]',
            '[{elseif $sPaymentID == "oxiddebitnote"}]'  => '[{elseif $sPaymentID == "oxiddebitnote"}][{ assign var="dynvalue" value=$oView->getDynValue()}]',
        ),

        '/page/checkout/thankyou.tpl' => array (
            '$belboon' => '$oView->getBelboonParam()',
            '[{assign var="order" value=$oView->getOrder()}]' => '[{assign var="order" value=$oView->getOrder()}][{assign var="basket" value=$oView->getBasket()}]'
        ),

        '/page/checkout/user.tpl' => array (
            '[{if $oViewConf->getShowOpenIdLogin() }]' => '[{if false}]',
            '$oView->getCountryList()' => '$oViewConf->getCountryList()',
            '[{if $lgn_usr}][{$lgn_usr}][{else}][{$oxcmp_user->oxuser__oxusername->value}][{/if}]' => '[{$oView->getActiveUsername()}]',
            '[{assign var="currency" value=$oView->getActCurrency() }]' => '[{assign var="invadr" value=$oView->getInvoiceAddress()}][{assign var="currency" value=$oView->getActCurrency() }]',
            '<input type="hidden" id="reloadaddress" name="reloadaddress" value="">' => '<input type="hidden" name="blhideshipaddress" value="0">',
            '[{assign var="delivadr" value=$oView->getDelAddress()}]' => '',
            '[{if $address->oxaddress__oxid->value == -2}]' => '[{if false}]',
            '[{ if $address->selected}]' => '[{if $address->isSelected()}][{assign var="delivadr" value=$address}]',
        ),

        // no deprecated
        '/page/checkout/wrapping.tpl' => array (),

        // no deprecated
        '/page/account/dashboard.tpl' => array (),

        '/page/account/forgotpwd.tpl' => array (
            '$lgn_usr' => '$oView->getActiveUsername()'
        ),

        // no deprecated
        '/page/account/login.tpl' => array (),

        // no deprecated
        '/page/account/newsletter.tpl' => array (),

        // no deprecated
        '/page/account/noticelist.tpl' => array (),

        '/page/account/order.tpl' => array (
            'http://www.dpd.de/cgi-bin/delistrack?typ=1&amp;lang=de&amp;pknr=[{ $order->oxorder__oxtrackcode->value }]' => '[{$order->getShipmentTrackingUrl()}]',
            '$order->oxorder__oxtrackcode->value' => '$order->getShipmentTrackingUrl()',
        ),

        // no deprecated
        '/page/account/password.tpl' => array (),

        '/page/account/user.tpl' => array (
            '[{include file="_header.tpl" title=$template_title location="ACCOUNT_USER_LOCATION"|oxmultilangassign|cat:$template_title}]' => '[{include file="_header.tpl" title=$template_title location="ACCOUNT_USER_LOCATION"|oxmultilangassign|cat:$template_title}][{assign var="invadr" value=$oView->getInvoiceAddress()}]',
            '$oView->getCountryList()' => '$oViewConf->getCountryList()',
            '$address->selected' => '$address->isSelected()',
            '<input type="hidden" id="reloadaddress" name="reloadaddress" value="">' => '<input type="hidden" name="blshowshipaddress" value="1">'
        ),

        // no deprecated
        '/page/account/wishlist.tpl' => array (),

        '/page/account/register.tpl' => array (
            '[{if $lgn_usr}][{$lgn_usr}][{else}][{$oxcmp_user->oxuser__oxusername->value}][{/if}]' => '[{ $oView->getActiveUsername() }]',
            '<form action="[{ $oViewConf->getSslSelfLink() }]" name="order" method="post">' => '[{assign var="invadr" value=$oView->getInvoiceAddress()}]<form action="[{ $oViewConf->getSslSelfLink() }]" name="order" method="post">',
            '[{assign var="delivadr" value=$oView->getDelAddress()}]' => '[{if $oxcmp_user}][{assign var="delivadr" value=$oxcmp_user->getSelectedAddress()}][{/if}]',
        ),

        // no deprecated
        '/page/account/register_success.tpl' => array (),

        // no deprecated
        '/page/account/register_confirm.tpl' => array (),

        // ???
        '/page/account/recommendationlist.tpl' => array (),

        '/page/account/recommendationedit.tpl' => array (
            '$oView->getActiveRecommItems()' => '$oView->getArticleList()'
        ),

        '/page/account/recommendationadd.tpl' => array (
            '[{assign var="template_title" value=$product->oxarticles__oxtitle->value|cat:" "|cat:$product->oxarticles__oxvarselect->value}]' => '[{assign var="product" value=$oView->getProduct() }][{assign var="template_title" value=$product->oxarticles__oxtitle->value|cat:" "|cat:$product->oxarticles__oxvarselect->value}]'
        ),

        // no deprecated
        '/_footer_plain.tpl' => array (),

        '/_footer.tpl' => array (
            '$wishid' => '$oView->getWishlistUserId()'
        ),

        '/_header_plain.tpl' => array (
            '$charset' => '$oView->getCharSet()',
            '[{if $rsslinks}]' => '[{assign var="rsslinks" value=$oView->getRssLinks() }][{if $rsslinks}]',
        ),

        '/_header.tpl' => array (
            '$charset' => '$oView->getCharSet()',
            '[{if $rsslinks}]' => '[{assign var="rsslinks" value=$oView->getRssLinks() }][{if $rsslinks}]',
        ),

        '/_left.tpl' => array (
            '$searchparamforhtml' => '$oView->getSearchParamForHtml()',
            '$searchvendor' => '$oView->getSearchVendor()',
            '$searchmanufacturer' => '$oView->getSearchManufacturer()',
        ),

        // no deprecated
        '/_path.tpl' => array (),

        '/_right.tpl' => array (
            '$pageNavigation->actPage' => '$oView->getActPage()',
            '$tpl' => '$oViewConf->getActTplName()',
            '$product' => '$oView->getProduct()',
            '$oViewConf->getShowOpenIdLogin()' => 'false',
            '[{ if $oView->getTop5ArticleList() }]' => '[{assign var="rsslinks" value=$oView->getRssLinks() }][{ if $oView->getTop5ArticleList() }]'
        ),

        // no deprecated
        '/compare_popup.tpl' => array (
            '[{assign var="template_title" value="COMPARE_POPUP_TITLE"|oxmultilangassign}]' => '[{assign var="template_title" value="COMPARE_POPUP_TITLE"|oxmultilangassign}][{assign var="currency" value=$oView->getActCurrency()}]'
        ),

        // no deprecated
        '/help.tpl' => array (),

        // no deprecated
        '/impressum.tpl' => array (),

        // no deprecated
        '/moredetails.tpl' => array (),

        // no deprecated
        '/pricealarm.tpl' => array (),

        // no deprecated
        '/review_login.tpl' => array (),

        '/review.tpl' => array (
            '[{else}] [{if $oView->getProduct()}]' => '[{else}] [{if $oView->getProduct()}][{assign var="product" value=$oView->getProduct()}]'
        ),

        '/widget/rss.tpl' => array (
            '$charset' => '$oView->getCharSet()',
        ),

        // no deprecated
        '/security_info.tpl' => array (),

        // no deprecated
        '/user_blocked.tpl' => array (),

        // no deprecated
        '/message/err_404.tpl' => array (),

        // no deprecated
        '/message/err_accessdenied.tpl' => array (),

        // no deprecated
        '/message/err_expired_days.tpl' => array (),

        // no deprecated
        '/message/err_mandates_exceeded.tpl' => array (),

        // no deprecated
        '/message/err_setup.tpl' => array (),

        '/message/err_unknown.tpl' => array (
            '$errornr' => '$oView->getErrorNumber()'
        ),

        // no deprecated
        '/message/err_unlicensed.tpl' => array (),

        // no deprecated
        '/message/err_update.tpl' => array (),

        // no deprecated
        '/dyn/add_recomm.tpl' => array (),

        // no deprecated
        '/dyn/cmp_fbconnect_right.tpl' => array (),

        '/dyn/cmp_login_links.tpl' => array (
            '$isfiltering &&' => '',
        ),

        '/dyn/cmp_login_right.tpl' => array (
            '$_login_pgnr-1' => '$_login_pgnr',
        ),

        // no deprecated
        '/dyn/compare_links.tpl' => array (),

        // no deprecated
        '/dyn/formparams.tpl' => array (),

        '/dyn/last_seen_products.tpl' => array (
            '[{if $aLastProducts && $aLastProducts->count() > 0 }]' => '[{assign var="aLastProducts" value=$oView->getLastProducts() }][{if $aLastProducts && $aLastProducts->count() > 0 }]'
        ),

        // no deprecated
        '/dyn/mini_basket.tpl' => array (),

        // no deprecated
        '/dyn/newbasketitem_message.tpl' => array (),

        // no deprecated
        '/dyn/newbasketitem_popup.tpl' => array (),

        // no deprecated
        '/dyn/oxscript.tpl' => array (),

        '/dyn/popup_scbasketexcl.tpl' => array (
            '$scRootCatChanged' => '$oView->isRootCatChanged()',
            '$tpl' => '$oViewConf->getActTplName()'
        ),

        '/dyn/promotions.tpl' => array (
            '[{$promo->getLongDesc()}]' => '[{oxeval var=$promo->oxactions__oxlongdesc}]'
        ),

        // no deprecated
        '/dyn/top_account.tpl' => array (),

        // no deprecated
        '/dyn/top_basket.tpl' => array (),

        // no deprecated
        '/inc/facebook/fb_comments.tpl' => array (
            '<fb:comments publish_feed=0 width="560"></fb:comments>' => '<div id="fb-root"></div><script src="http://connect.facebook.net/en_US/all.js#appId=[{$oViewConf->getFbAppId()}]&amp;xfbml=1"></script><fb:comments href="[{$oViewConf->getHomeLink()}]" num_posts="5" width="560"></fb:comments>'
        ),

        // no deprecated
        '/inc/facebook/fb_facepile.tpl' => array (),

        // no deprecated
        '/inc/facebook/fb_init.tpl' => array (),

        '/inc/facebook/fb_invite.tpl' => array (
            '[{assign var="product" value=$oView->getProduct() }]' => '',
            '$product->getLink()' => '$oView->getCanonicalUrl()',
        ),

        '/inc/facebook/fb_like.tpl' => array (
            '[{assign var="oProduct" value=$oView->getProduct() }]' => '',
            '$oProduct->getLink()' => '$oView->getCanonicalUrl()',
        ),

        '/inc/facebook/fb_live_stream.tpl' => array (
            '"$oViewConf->getFbAppId()"' => '"[{$oViewConf->getFbAppId()}]"',
        ),

        // no deprecated
        '/inc/facebook/fb_share.tpl' => array (),

        '/inc/account_header.tpl' => array (
            '$isfiltering && ' => '',
        ),

        // no deprecated
        '/inc/admin_banner.tpl' => array (),

        // no deprecated
        '/inc/bargain_items.tpl' => array (),

        // no deprecated
        '/inc/bookmarks.tpl' => array (),

        '/inc/category_options.tpl' => array (
            '$searchcnid' => '$oView->getSearchCatId()'
        ),

        // no deprecated
        '/inc/category_tree.tpl' => array (),

        '/inc/cmp_lang.tpl' => array (),

        '/inc/cmp_login.tpl' => array (
            '$tpl' => '$oViewConf->getActTplName()',
            '$oViewConf->getShowOpenIdLogin()' => 'false',
        ),

        '/inc/cmp_news.tpl' => array (
            '[{ $oxcmp_news->oxnews__oxlongdesc->value|strip_tags|oxtruncate:100 }]' => '[{oxeval var=$oxcmp_news->oxnews__oxlongdesc assign=\'_sNewsItem\' force=1}]
             [{ $_sNewsItem|strip_tags|oxtruncate:100 }]'
        ),

        // no deprecated
        '/inc/cmp_newsletter.tpl' => array (),

        '/inc/compare_locator.tpl' => array (
            '<div class="locator compare">' => '[{assign var="pageNavigation" value=$oView->getPageNavigation()}]<div class="locator compare">'
        ),

        // no deprecated
        '/inc/del_time.tpl' => array (),

        '/inc/details_locator.tpl' => array (
            '[{if ($actCategory && $actCategory->iProductPos) || $actCategory->prevProductLink || $actCategory->nextProductLink }]' =>
            '[{assign var="actCategory" value=$oView->getActiveCategory()}][{if ($actCategory && $actCategory->iProductPos) || $actCategory->prevProductLink || $actCategory->nextProductLink }]',
            '$sListType' => '$oView->getListType()'
        ),

        // no deprecated
        '/inc/error.tpl' => array (),

        '/inc/guestbook_locator.tpl' => array (
            '<div class="locator">' => '[{assign var="pageNavigation" value=$oView->getPageNavigation()}]<div class="locator">',
            '$tpl' => '$oViewConf->getActTplName()',
            '$additionalparams' => '$oView->getAdditionalParams()'
        ),

        // no deprecated
        '/inc/infobox.tpl' => array (),

        '/inc/list_locator.tpl' => array (
            '<div class="locator">' => '[{assign var="pageNavigation" value=$oView->getPageNavigation()}]<div class="locator">',
            '$tpl' => '$oViewConf->getActTplName()'
        ),

        // no deprecated
        '/inc/manufacturer_tree.tpl' => array (),

        // no deprecated
        '/inc/media.tpl' => array (),

        // no deprecated
        '/inc/msg_basket.tpl' => array (),

        // no deprecated
        '/inc/popup_basket.tpl' => array (),

        // no deprecated
        '/inc/popup_fblogin_msg.tpl' => array (),

        // no deprecated
        '/inc/popup_fblogin.tpl' => array (),

        '/inc/popup_zoom.tpl' => array (
            '[{if $aZoomPics|@count > 1}]' => '[{assign var="aZoomPics" value=$oView->getZoomPics() }][{assign var="iZoomPic" value=$oView->getActZoomPic() }][{if $aZoomPics|@count > 1}]'
        ),

        '/inc/product.tpl' => array (
            '<div [{if $test_Cntr}]id="test_cntr_[{$test_Cntr}]_[{$product->oxarticles__oxartnum->value}]"[{/if}] class="product hproduct[{if $head}] head[{/if}]' =>
            '[{assign var="currency" value=$oView->getActCurrency()}]<div [{if $test_Cntr}]id="test_cntr_[{$test_Cntr}]_[{$product->oxarticles__oxartnum->value}]"[{/if}] class="product hproduct[{if $head}] head[{/if}]',
            '$pageNavigation->actPage-1' => '$oView->getActPage()',
            '$product->selectlist' => '$product->getDispSelList()',
            '$isfiltering && ' => '',
            '$wishid' => '$oView->getWishlistUserId()'
        ),

        // no deprecated
        '/inc/recommlist.tpl' => array (
            '$oView->getActiveRecommItems()' => '$oView->getArticleList()',
        ),

        // no deprecated
        '/inc/right_recommlist.tpl' => array (),

        '/inc/rightlist.tpl' => array (
            '$pageNavigation->actPage-1' => '$oView->getActPage()',
            '$isfiltering && ' => '',
        ),

        // no deprecated
        '/inc/salutation.tpl' => array (),

        // no deprecated
        '/inc/sort_guestbook.snippet.tpl' => array (),

        '/inc/sort.snippet.tpl' => array (
            '$pageNavigation->iArtCnt' => '$oView->getArticleCount()'
        ),

        '/inc/state_selector.snippet.tpl' => array (
            '$oxcountrylist' => '$oView->getCountryList()'
        ),

        // no deprecated
        '/inc/steps_item.tpl' => array (),

        '/inc/tags.tpl' => array (
            '$product->detailslink' => '$product->getLink()',
            '$oView->getTagCloud()' => '$oView->getTagCloudManager()',
        ),

        '/inc/top_items.tpl' => array (
            '[{foreach from=$oView->getTop5ArticleList() item=_product}]' => '[{assign var="currency" value=$oView->getActCurrency()}][{foreach from=$oView->getTop5ArticleList() item=_product}]',
        ),

        // no deprecated
        '/inc/trustedshops_item.tpl' => array (),

        // no deprecated
        '/inc/ts_ratings.tpl' => array (),

        '/inc/variant_selector.tpl' => array (
            ' isfiltering=false ' => '',
        ),

        // no deprecated
        '/inc/vendor_tree.tpl' => array (),

        '/email/html/forgotpwd.tpl' => array (
            '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">' =>
            '[{ assign var="shop"     value=$oEmailView->getShop() }]
                [{ assign var="oViewConf" value=$oEmailView->getViewConfig() }]
                [{ assign var="user"     value=$oEmailView->getUser() }]
            <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">',
            '$charset' => '$oEmailView->getCharset()',
            '$oViewConf->getNoSslImageDir()' => '$oViewConf->getImageUrl()'
        ),

        '/email/html/invite.tpl' => array (
             '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">' =>
            '[{ assign var="shop"     value=$oEmailView->getShop() }]
                [{ assign var="oViewConf" value=$oEmailView->getViewConfig() }]
                [{ assign var="userinfo" value=$oEmailView->getUser() }]
            <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">',

            '$charset' => '$oEmailView->getCharset()',
            '$oViewConf->getNoSslImageDir()' => '$oViewConf->getImageUrl()'
        ),

        '/email/html/newsletteroptin.tpl' => array (
            '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">' =>
            '[{ assign var="shop"     value=$oEmailView->getShop() }]
                [{ assign var="oViewConf" value=$oEmailView->getViewConfig() }]
                [{ assign var="user"     value=$oEmailView->getUser() }]
                <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">',

            '$charset' => '$oEmailView->getCharset()',
            '$oViewConf->getNoSslImageDir()' => '$oViewConf->getImageUrl()'

        ),

        '/email/html/order_cust.tpl' => array (
            '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">' =>
            '[{ assign var="shop"     value=$oEmailView->getShop() }]
                [{ assign var="oViewConf" value=$oEmailView->getViewConfig() }]
                [{ assign var="currency" value=$oEmailView->getCurrency() }]
                [{ assign var="user"     value=$oEmailView->getUser() }]
                [{ assign var="oDelSet"   value=$order->getDelSet() }]
                [{ assign var="basket"   value=$order->getBasket() }]
                [{ assign var="payment"  value=$order->getPayment() }]
                <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">',

            '$charset' => '$oEmailView->getCharset()',
            '$oViewConf->getNoSslImageDir()' => '$oViewConf->getImageUrl()',
            '<br><b>[{ oxmultilang ident="EMAIL_ORDER_CUST_HTML_WRAPPING" }]&nbsp;</b>[{ if !$basketitem->wrapping }][{ oxmultilang ident="EMAIL_ORDER_CUST_HTML_NONE" }][{else}][{$basketitem->oWrap->oxwrapping__oxname->value}][{/if}]' =>
            '[{assign var="oWrapping" value=$basketitem->getWrapping() }]
            <br><b>[{ oxmultilang ident="EMAIL_ORDER_CUST_HTML_WRAPPING" }]&nbsp;</b>[{ if !$basketitem->getWrappingId() }][{ oxmultilang ident="EMAIL_ORDER_CUST_HTML_NONE" }][{else}][{$oWrapping->oxwrapping__oxname->value }][{/if}]',
            '$basketitem->chosen_selectlist' => '$basketitem->getChosenSelList()',
            '$basketitem->aPersParam' => '$basketitem->getPersParams()',
            '$basketitem->dAmount' => '$basketitem->getAmount()',
            '$reviewuserhash' => '$user->getReviewUserHash($user->getId())',
            '[{if $oViewConf->getShowGiftWrapping() && $basket->oCard }]' => '[{if $oViewConf->getShowGiftWrapping() && $basket->getCard() }][{assign var="oCard" value=$basket->getCard() }]',
            '<img src="[{$basket->oCard->nossl_dimagedir}]/0/[{$basket->oCard->oxwrapping__oxpic->value}]" alt="[{$basket->oCard->oxwrapping__oxname->value}]" hspace="0" vspace="0" border="0" align="top"><br><br>' => '<img src="[{$oCard->getNoSslDynImageDir()}]/0/[{$oCard->oxwrapping__oxpic->value}]" alt="[{$oCard->oxwrapping__oxname->value}]" hspace="0" vspace="0" border="0" align="top"><br><br>',
            '$basket->giftmessage' => '$basket->getCardMessage()',
            '$basket->dVoucherDiscount' => '$basket->getVoucherDiscValue()',
            '$vouchers' => '$order->getVoucherList()',
            '$basket->aDiscounts' => '$basket->getDiscounts()',
            '$basket->fproductsnetprice' => '$basket->getProductsNetPrice()',
            '$basket->aVATs' => '$basket->getProductVats()',
            '$basket->fproductsprice' => '$basket->getFProductsPrice()',
            '$basket->fVoucherDiscount' => '$basket->getFVoucherDiscountValue()',
            '$basket->fdeliverynetcost' => '$basket->getDelCostNet()',
            '$basket->fDelVATPercent*100' => '$basket->getDelCostVatPercent()',
            '$basket->fDelVAT' => '$basket->getDelCostVat()',
            '$basket->dDelVAT' => '$basket->getDelCostVat()',
            '$basket->fdeliverycost' => '$basket->getFDeliveryCosts()',
            '$basket->fAddPaymentNetSum' => '$basket->getPayCostNet()',
            '$basket->fAddPaymentSumVATPercent' => '$basket->getPayCostVatPercent()',
            '$basket->dAddPaymentSumVAT' => '$basket->getDelCostVat()',
            '$basket->fAddPaymentSumVAT' => '$basket->getPayCostVat()',
            '$basket->fAddPaymentSum' => '$basket->getFPaymentCosts()',
            '$basket->dWrappingPrice' => '$basket->getFWrappingCosts()',
            '$basket->fWrappingVATPercent' => '$basket->getWrappCostVatPercent()',
            '$basket->fWrappingVAT' => '$basket->getWrappCostVat()',
            '$basket->fWrappingNetto' => '$basket->getWrappCostNet()',
            '$basket->fWrappingVAT' => '$basket->getWrappCostVat()',
            '$basket->fWrappingPrice' => '$basket->getFWrappingCosts()',
            '$basket->fprice' => '$basket->getFPrice()',
            '$basket->dAddPaymentSum' => '$basket->getPaymentCosts()',
            '[{if $payment->oxuserpayments__oxpaymentsid->value != "oxempty"}][{ oxmultilang ident="EMAIL_ORDER_CUST_HTML_SHIPPINGCARRIER" }] <strong>[{ $order->oDelSet->oxdeliveryset__oxtitle->value }]</strong><br>[{/if}]' =>
            '[{if $payment->oxuserpayments__oxpaymentsid->value != "oxempty"}][{ oxmultilang ident="EMAIL_ORDER_CUST_HTML_SHIPPINGCARRIER" }] <strong>[{ $oDelSet->oxdeliveryset__oxtitle->value }]</strong><br>[{/if}]'
        ),

        '/email/html/order_owner.tpl' => array (
            '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">' =>
            '[{ assign var="shop"     value=$oEmailView->getShop() }]
                [{ assign var="oViewConf" value=$oEmailView->getViewConfig() }]
                [{ assign var="currency" value=$oEmailView->getCurrency() }]
                [{ assign var="user"     value=$oEmailView->getUser() }]
                [{ assign var="basket"   value=$order->getBasket() }]
                [{ assign var="oDelSet"   value=$order->getDelSet() }]
                [{ assign var="payment"  value=$order->getPayment() }]
                <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">',
            '$charset' => '$oEmailView->getCharset()',
            '$oViewConf->getNoSslImageDir()' => '$oViewConf->getImageUrl()',
            '<br><b>[{ oxmultilang ident="EMAIL_ORDER_CUST_HTML_WRAPPING" }]&nbsp;</b>[{ if !$basketitem->wrapping }][{ oxmultilang ident="EMAIL_ORDER_CUST_HTML_NONE" }][{else}][{$basketitem->oWrap->oxwrapping__oxname->value}][{/if}]' =>
            '[{assign var="oWrapping" value=$basketitem->getWrapping() }]
                    <br><b>[{ oxmultilang ident="EMAIL_ORDER_CUST_HTML_WRAPPING" }]&nbsp;</b>[{ if !$basketitem->getWrappingId() }][{ oxmultilang ident="EMAIL_ORDER_CUST_HTML_NONE" }][{else}][{$oWrapping->oxwrapping__oxname->value}][{/if}]',
            '$basketitem->chosen_selectlist' => '$basketitem->getChosenSelList()',
            '$basketitem->aPersParam' => '$basketitem->getPersParams()',
            '$basketitem->dAmount' => '$basketitem->getAmount()',
            '$basket->oCard->nossl_dimagedir' => '$basket->oCard->getNoSslDynImageDir()',
            '$basket->giftmessage' => '$basket->getCardMessage()',
            '$basket->dVoucherDiscount' => '$basket->getVoucherDiscValue()',
            '$vouchers' => '$order->getVoucherList()',
            '$basket->aDiscounts' => '$basket->getDiscounts()',
            '$basket->fproductsnetprice' => '$basket->getProductsNetPrice()',
            '$basket->aVATs' => '$basket->getProductVats()',
            '$basket->fproductsprice' => '$basket->getFProductsPrice()',
            '$basket->aDiscounts' => '$basket->getDiscounts()',
            '$basket->fproductsnetprice' => '$basket->getProductsNetPrice()',
            '$basket->aVATs' => '$basket->getProductVats()',
            '$basket->dVoucherDiscount' => '$basket->getVoucherDiscValue()',
            '$basket->fVoucherDiscount' => '$basket->getFVoucherDiscountValue()',
            '$basket->dDelVAT' => '$basket->getDelCostVat()',
            '$basket->fdeliverynetcost' => '$basket->getDelCostNet()',
            '$basket->fDelVATPercent*100' => '$basket->getDelCostVatPercent()',
            '$basket->fDelVAT' => '$basket->getDelCostVat()',
            '$basket->fdeliverycost' => '$basket->getFDeliveryCosts()',
            '$basket->dAddPaymentSumVAT' => '$basket->getDelCostVat()',
            '$basket->fAddPaymentSumVATPercent' => '$basket->getPayCostVatPercent()',
            '$basket->fAddPaymentSumVAT' => '$basket->getPayCostVat()',
            '$basket->dWrappingPrice' => '$basket->getFWrappingCosts()',
            '$basket->fWrappingNetto' => '$basket->getWrappCostNet()',
            '$basket->fWrappingVATPercent' => '$basket->getWrappCostVatPercent()',
            '$basket->fWrappingVAT' => '$basket->getWrappCostVat()',
            '$basket->fWrappingPrice' => '$basket->getFWrappingCosts()',
            '$basket->fprice' => '$basket->getFPrice()',
            '$basket->dAddPaymentSum' => '$basket->getPaymentCosts()',
            '$basket->fAddPaymentSum' => '$basket->getFPaymentCosts()',
            '[{if $payment->oxuserpayments__oxpaymentsid->value != "oxempty"}][{ oxmultilang ident="EMAIL_ORDER_CUST_HTML_SHIPPINGCARRIER" }] <strong>[{ $order->oDelSet->oxdeliveryset__oxtitle->value }]</strong><br>[{/if}]' =>
            '[{if $payment->oxuserpayments__oxpaymentsid->value != "oxempty"}][{ oxmultilang ident="EMAIL_ORDER_CUST_HTML_SHIPPINGCARRIER" }] <strong>[{ $oDelSet->oxdeliveryset__oxtitle->value }]</strong><br>[{/if}]'
        ),

        '/email/html/owner_reminder.tpl' => array (
            '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">' => '[{ assign var="shop"     value=$oEmailView->getShop() }]
            [{ assign var="oViewConf" value=$oEmailView->getViewConfig() }]
            <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">',
            '$charset' => '$oEmailView->getCharset()',
            '$oViewConf->getNoSslImageDir()' => '$oViewConf->getImageUrl()'
        ),

        '/email/html/pricealarm_owner.tpl' => array (
            '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">' => '[{ assign var="shop"      value=$oEmailView->getShop() }]
            [{ assign var="oViewConf" value=$oEmailView->getViewConfig() }]
            [{ assign var="currency"  value=$oEmailView->getCurrency() }]
            [{ assign var="user"      value=$oEmailView->getUser() }]
            <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">',
            '$charset' => '$oEmailView->getCharset()',
            '$oViewConf->getNoSslImageDir()' => '$oViewConf->getImageUrl()'

        ),

        '/email/html/register.tpl' => array (
            '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">' => '[{ assign var="shop"     value=$oEmailView->getShop() }]
            [{ assign var="oViewConf" value=$oEmailView->getViewConfig() }]
            [{ assign var="user"     value=$oEmailView->getUser() }]
            <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">',
            '$charset' => '$oEmailView->getCharset()',
            '$oViewConf->getNoSslImageDir()' => '$oViewConf->getImageUrl()'
        ),

        '/email/html/sendednow.tpl' => array (
             '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">' => '[{ assign var="shop"     value=$oEmailView->getShop() }]
                [{ assign var="oViewConf" value=$oEmailView->getViewConfig() }]
                <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">',
             '$charset' => '$oEmailView->getCharset()',
        ),

        '/email/html/suggest.tpl' => array (
             '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">' => '[{ assign var="shop"     value=$oEmailView->getShop() }]
            [{ assign var="oViewConf" value=$oEmailView->getViewConfig() }]
            [{ assign var="user"     value=$oEmailView->getUser() }]
            <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">',
            '$charset' => '$oEmailView->getCharset()',
            '$oViewConf->getNoSslImageDir()' => '$oViewConf->getImageUrl()',
            '$userinfo' => '$user'
        ),

        '/email/html/wishlist.tpl' => array (
            '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">' =>
            '[{ assign var="shop"     value=$oEmailView->getShop() }]
            [{ assign var="oViewConf" value=$oEmailView->getViewConfig() }]
            [{ assign var="user"     value=$oEmailView->getUser() }]
            <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">',
            '$charset' => '$oEmailView->getCharset()',
            '$oViewConf->getNoSslImageDir()' => '$oViewConf->getImageUrl()',
            '$userinfo' => '$user'
        ),

        // no deprecated
        '/email/plain/forgotpwd.tpl' => array (),

        // no deprecated
        '/email/plain/invite.tpl' => array (),


        '/email/plain/newsletteroptin.tpl' => array (
            '[{ oxcontent ident="oxnewsletterplainemail" }]' =>
            '[{ assign var="shop"      value=$oEmailView->getShop() }]
                [{ assign var="oViewConf" value=$oEmailView->getViewConfig() }]
                [{ assign var="user"      value=$oEmailView->getUser() }]
                [{ oxcontent ident="oxnewsletterplainemail" }]'
        ),

        '/email/plain/order_cust.tpl' => array (
            '[{if $payment->oxuserpayments__oxpaymentsid->value == "oxempty"}]' =>
            '[{ assign var="shop"      value=$oEmailView->getShop() }]
            [{ assign var="oViewConf" value=$oEmailView->getViewConfig() }]
            [{ assign var="currency"  value=$oEmailView->getCurrency() }]
            [{ assign var="user"      value=$oEmailView->getUser() }]
            [{ assign var="oDelSet"   value=$order->getDelSet() }]
            [{ assign var="basket"    value=$order->getBasket() }]
            [{ assign var="payment"   value=$order->getPayment() }]
            [{if $payment->oxuserpayments__oxpaymentsid->value == "oxempty"}]',
            '$oViewConf->getNoSslImageDir()' => '$oViewConf->getImageUrl()',
            '$basketitem->chosen_selectlist' => '$basketitem->getChosenSelList()',
            '$basketitem->aPersParam' => '$basketitem->getPersParams()',
            '$basketitem->dAmount' => '$basketitem->getAmount()',
            '$reviewuserhash' => '$user->getReviewUserHash($user->getId())',
            '$basket->giftmessage' => '$basket->getCardMessage()',
            '$basket->dVoucherDiscount' => '$basket->getVoucherDiscValue()',
            '$vouchers' => '$order->getVoucherList()',
            '$basket->aDiscounts' => '$basket->getDiscounts()',
            '$basket->fproductsnetprice' => '$basket->getProductsNetPrice()',
            '$basket->aVATs' => '$basket->getProductVats()',
            '$basket->fproductsprice' => '$basket->getFProductsPrice()',
            '$basket->fVoucherDiscount' => '$basket->getFVoucherDiscountValue()',
            '$basket->dDelVAT' => '$basket->getDelCostVat()',
            '$basket->fdeliverynetcost' => '$basket->getDelCostNet()',
            '$basket->fDelVATPercent*100' => '$basket->getDelCostVatPercent()',
            '$basket->fDelVAT' => '$basket->getDelCostVat()',
            '$basket->fdeliverycost' => '$basket->getFDeliveryCosts()',
            '$basket->fAddPaymentNetSum' => '$basket->getPayCostNet()',
            '$basket->fAddPaymentSumVATPercent' => '$basket->getPayCostVatPercent()',
            '$basket->fAddPaymentSumVAT' => '$basket->getPayCostVat()',
            '$basket->dWrappingPrice' => '$basket->getFWrappingCosts()',
            '$basket->fWrappingNetto' => '$basket->getWrappCostNet()',
            '$basket->fWrappingVATPercent' => '$basket->getWrappCostVatPercent()',
            '$basket->fWrappingVAT' => '$basket->getWrappCostVat()',
            '$basket->fWrappingPrice' => '$basket->getFWrappingCosts()',
            '$basket->fprice' => '$basket->getFPrice()',
            '$basket->oCard' => '$basket->getCard()',
            '$basket->dAddPaymentSumVAT' => '$basket->getDelCostVat()',
            '$basket->dAddPaymentSum' => '$basket->getPaymentCosts()',
            '$basket->fAddPaymentSum' => '$basket->getFPaymentCosts()',
            '[{ oxmultilang ident="EMAIL_ORDER_CUST_HTML_WRAPPING" }] [{ if !$basketitem->wrapping }][{ oxmultilang ident="EMAIL_ORDER_CUST_HTML_NONE" }][{else}][{$basketitem->oWrap->oxwrapping__oxname->getRawValue()}][{/if}]' =>
            '[{assign var="oWrapping" value=$basketitem->getWrapping() }]
            [{ oxmultilang ident="EMAIL_ORDER_CUST_HTML_WRAPPING" }] [{ if !$basketitem->getWrappingId() }][{ oxmultilang ident="EMAIL_ORDER_CUST_HTML_NONE" }][{else}][{$oWrapping->oxwrapping__oxname->value}][{/if}]'

        ),

        '/email/plain/order_owner.tpl' => array (
            '[{if $payment->oxuserpayments__oxpaymentsid->value == "oxempty"}]' =>
            '[{ assign var="shop"      value=$oEmailView->getShop() }]
            [{ assign var="oViewConf" value=$oEmailView->getViewConfig() }]
            [{ assign var="currency"  value=$oEmailView->getCurrency() }]
            [{ assign var="user"      value=$oEmailView->getUser() }]
            [{ assign var="basket"    value=$order->getBasket() }]
            [{ assign var="oDelSet"   value=$order->getDelSet() }]
            [{ assign var="payment"   value=$order->getPayment() }]
            [{if $payment->oxuserpayments__oxpaymentsid->value == "oxempty"}]',
            '$oViewConf->getNoSslImageDir()' => '$oViewConf->getImageUrl()',
            '$basketitem->chosen_selectlist' => '$basketitem->getChosenSelList()',
            '$basketitem->aPersParam' => '$basketitem->getPersParams()',
            '$basketitem->dAmount' => '$basketitem->getAmount()',
            '$basket->oCard->nossl_dimagedir' => '$basket->oCard->getNoSslDynImageDir()',
            '$basket->giftmessage' => '$basket->getCardMessage()',
            '$basket->dVoucherDiscount' => '$basket->getVoucherDiscValue()',
            '$vouchers' => '$order->getVoucherList()',
            '$basket->aDiscounts' => '$basket->getDiscounts()',
            '$basket->fproductsnetprice' => '$basket->getProductsNetPrice()',
            '$basket->aVATs' => '$basket->getProductVats()',
            '$basket->fproductsprice' => '$basket->getFProductsPrice()',
            '$basket->aDiscounts' => '$basket->getDiscounts()',
            '$basket->fproductsnetprice' => '$basket->getProductsNetPrice()',
            '$basket->aVATs' => '$basket->getProductVats()',
            '$basket->dVoucherDiscount' => '$basket->getVoucherDiscValue()',
            '$basket->fVoucherDiscount' => '$basket->getFVoucherDiscountValue()',
            '$basket->dDelVAT' => '$basket->getDelCostVat()',
            '$basket->fdeliverynetcost' => '$basket->getDelCostNet()',
            '$basket->fDelVATPercent*100' => '$basket->getDelCostVatPercent()',
            '$basket->fDelVAT' => '$basket->getDelCostVat()',
            '$basket->fdeliverycost' => '$basket->getFDeliveryCosts()',
            '$basket->fAddPaymentNetSum' => '$basket->getPayCostNet()',
            '$basket->dAddPaymentSumVAT' => '$basket->getDelCostVat()',
            '$basket->fAddPaymentSumVATPercent' => '$basket->getPayCostVatPercent()',
            '$basket->fAddPaymentSumVAT' => '$basket->getPayCostVat()',
            '$basket->dWrappingPrice' => '$basket->getFWrappingCosts()',
            '$basket->fWrappingNetto' => '$basket->getWrappCostNet()',
            '$basket->fWrappingVATPercent' => '$basket->getWrappCostVatPercent()',
            '$basket->fWrappingVAT' => '$basket->getWrappCostVat()',
            '$basket->fWrappingPrice' => '$basket->getFWrappingCosts()',
            '$basket->fprice' => '$basket->getFPrice()',
            '$basket->dAddPaymentSum' => '$basket->getPaymentCosts()',
            '$basket->fAddPaymentSum' => '$basket->getFPaymentCosts()',
            '[{ oxmultilang ident="EMAIL_ORDER_CUST_HTML_WRAPPING" }] [{ if !$basketitem->wrapping }][{ oxmultilang ident="EMAIL_ORDER_CUST_HTML_NONE" }][{else}][{$basketitem->oWrap->oxwrapping__oxname->getRawValue()}][{/if}]' =>
            '[{assign var="oWrapping" value=$basketitem->getWrapping() }]
            [{ oxmultilang ident="EMAIL_ORDER_CUST_HTML_WRAPPING" }] [{ if !$basketitem->getWrappingId() }][{ oxmultilang ident="EMAIL_ORDER_CUST_HTML_NONE" }][{else}][{$oWrapping->oxwrapping__oxname->getRawValue()}][{/if}]'
        ),

        // no deprecated
        '/email/plain/register.tpl' => array (),

        '/email/plain/sendednow.tpl' => array (
            '[{ oxcontent ident="oxordersendplainemail" }]' =>
            '[{ assign var="shop"      value=$oEmailView->getShop() }]
            [{ assign var="oViewConf" value=$oEmailView->getViewConfig() }]
            [{ oxcontent ident="oxordersendplainemail" }]'
        ),

        '/email/plain/suggest.tpl' => array (
            '[{ oxmultilang ident="EMAIL_SUGGEST_HTML_PRODUCTPOSTCARDFROM" }] [{ $shop->oxshops__oxname->getRawValue() }]' =>
            '[{ assign var="shop"     value=$oEmailView->getShop() }]
            [{ assign var="oViewConf" value=$oEmailView->getViewConfig() }]
            [{ assign var="user"     value=$oEmailView->getUser() }]
            [{ oxmultilang ident="EMAIL_SUGGEST_HTML_PRODUCTPOSTCARDFROM" }] [{ $shop->oxshops__oxname->getRawValue() }]'
        ),

        '/email/plain/wishlist.tpl' => array (
            '[{ oxmultilang ident="EMAIL_WISHLIST_HTML_MYWISHLISTBY" }] [{ $shop->oxshops__oxname->getRawValue() }]' =>
            '[{ assign var="shop"      value=$oEmailView->getShop() }]
            [{ assign var="oViewConf" value=$oEmailView->getViewConfig() }]
            [{ assign var="user"      value=$oEmailView->getUser() }]
            [{ oxmultilang ident="EMAIL_WISHLIST_HTML_MYWISHLISTBY" }] [{ $shop->oxshops__oxname->getRawValue() }]'
        ),
    );
    /**
     * requests user to answer the question
     *
     * @return string
     */
    public function requestTemplatesFilesStructureUpdate()
    {
        $oUI = $this->_getProcess()->getUI();
        $oInfo = $oUI->createRadioBtnQuestion();
        $aOptions = array( "1" => "Yes", "2" => "No" );
        $oInfo->setOptions($aOptions);
        $sDescription = "Do you want to move the existing templates into the new template structure of the theme \"Basic\"?";
        $sDescription .= "<br><br><span style='font-size:11px; color: #900;'>(Please backup the existing templates. The script will change the templates of the template set \"Basic\". If this templates were customized, please check the template documentation /templ_docu/index.html.)</span>";
        $oInfo->setDescription( $sDescription );
        //$oInfo->setDefault("2");

        $oUI->userInputRequest(
            "reqId1",
            array("q1" => $oInfo),
            "Updating templates structure"
        );

        return "processUserInputRequest_1";
    }

    /**
     * checks user input and selects action to perform
     *
     * @return string
     */
    public function processUserInputRequest_1()
    {
        $oUI = $this->_getProcess()->getUI();

        $aResponce = $oUI->getUserAnswer( "reqId1" );

        switch ($aResponce["q1"]) {
            case "1":
                //updating templates files sturcture
                return "updateTemplatesStructure";
                break;
            case "2":
                // skipping all templates updates, continuing general update
                return "continueUpdate";
                break;
            default:
                // no (or bad) user input, requesting for user input again
                return "requestTemplatesFilesStructureUpdate";
                break;
        }
    }

    /**
     * requests user to answer the question
     *
     * @return string
     */
    public function requestDeprecatedValuesUpdate()
    {
        $oUI = $this->_getProcess()->getUI();
        $oInfo = $oUI->createRadioBtnQuestion();
        $aOptions = array( "1" => "Yes", "2" => "No" );
        $oInfo->setOptions($aOptions);
        $oInfo->setDescription( "Do you want to remove deprecated and no longer supported values from the templates?" );

        $oUI->userInputRequest(
            "reqId2",
            array("q1" => $oInfo),
            "Removing deprecated values"
        );

        return "processUserInputRequest_2";
    }

    /**
     * checks user input and selects action to perform
     *
     * @return string
     */
    public function processUserInputRequest_2()
    {
        $oUI = $this->_getProcess()->getUI();
        $aResponce = $oUI->getUserAnswer( "reqId2" );

        switch ($aResponce["q1"]) {
            case "1":
                //updating templates files sturcture
                return "updateDeprecatedValues";
                break;
            case "2":
                // skipping all templates updates, continuing general update
                return "continueUpdate";
                break;
            default:
                // no (or bad) user input, requesting for user input again
                return "requestDeprecatedValuesUpdate";
                break;
        }
    }

    /**
     * updates templates and continues next actions
     *
     * @return string
     */
    public function updateTemplatesStructure()
    {
        $myConfig  = $this->getConfig();
        $oUI   = $this->_getProcess()->getUI();

        $sOutDir      = $myConfig->getOutDir();
        $sTheme       = $myConfig->getConfigParam('sTheme').'/tpl';
        $sCustomTheme = $myConfig->getConfigParam('sCustomTheme').'/tpl';

        $aTplDir = array($sOutDir.$sTheme);
        if ($sCustomTheme) {
            $aTplDir[] = $sOutDir.$sCustomTheme;
        }

        foreach ($aTplDir as $sTplDir) {
            if(is_dir($sTplDir)) {
                foreach($this->_aTemplateMap as $sFrom => $sTo) {
                    $sPathFrom = $sTplDir.$sFrom;
                    $sPathTo   = $sTplDir.$sTo;
                    if (file_exists($sPathFrom) && !file_exists($sPathTo)) {
                        $sDirTo = dirname($sPathTo);
                        if ($sDirTo && !is_dir($sDirTo)) {
                            if (!mkdir($sDirTo, 0755, true)) {
                                $oInfo = $oUI->createTextNotification();
                                $oInfo->setText("Can not create dir {$sDirTo}");
                                $oUI->addErrorForUser($oInfo, false, false);
                                return 'updateTemplatesStructure';
                            }
                        }
                        if (($sPathFrom !== $sPathTo) && is_file($sPathFrom))  {
                            if ( copy($sPathFrom, $sPathTo) && unlink($sPathFrom)) {
                                $oInfo = $oUI->createTextNotification();
                                $oInfo->setText("Moved form {$sPathFrom} to {$sPathTo}");
                                $oUI->addInfoForUser($oInfo);
                            } else {
                                $oInfo = $oUI->createTextNotification();
                                $oInfo->setText("Can not move file from {$sPathFrom} to {$sPathTo}");
                                $oUI->addErrorForUser($oInfo, false, false);
                                return 'updateTemplatesStructure';
                            }
                        }
                    }
                }
            }
        }

        //templates structure update
        return "requestDeprecatedValuesUpdate";
    }

    /**
     * updates deprecated values and continues next actions
     *
     * @return string
     */
    public function updateDeprecatedValues()
    {
        $myConfig  = $this->getConfig();
        $oUI       = $this->_getProcess()->getUI();

        $sOutDir      = $myConfig->getOutDir();
        $sTheme       = $myConfig->getConfigParam('sTheme').'/tpl';
        $sCustomTheme = $myConfig->getConfigParam('sCustomTheme').'/tpl';

        $aTplDir = array($sOutDir.$sTheme);
        if ($sCustomTheme) {
            $aTplDir[] = $sOutDir.$sCustomTheme;
        }

        foreach ($aTplDir as $sTplDir) {
            if(is_dir($sTplDir)) {
                foreach($this->_aDeprecatedMap as $sFile => $aDeprecated) {
                    $sPath = $sTplDir.$sFile;
                    if (file_exists($sPath)) {
                        if(is_readable($sPath) && is_writable($sPath)) {
                            $sTemplate = file_get_contents($sPath);
                            $iFileCnt = 0;
                            foreach ($aDeprecated as $sFrom => $sTo){
                                $iCnt = 0;

                                $sFrom = preg_replace('/\s+/i', ' ', trim($sFrom));
                                $sFrom = preg_replace('/'.preg_quote('[{','/').'\s+/i', '[{', trim($sFrom));
                                $sFrom = preg_replace('/\s+'.preg_quote('}]','/').'/i', '}]', trim($sFrom));

                                $aReplace = array(
                                    ' ' => '\s+',
                                    preg_quote('[{','/') => preg_quote('[{','/').'\s*',
                                    preg_quote('}]','/') => '\s*'.preg_quote('}]','/'),
                                );

                                $sFromPtrn = '/'.strtr (preg_quote($sFrom,'/'),$aReplace).'/i';
                                $sTemplate = preg_replace($sFromPtrn, $sTo, $sTemplate,-1,$iCnt);

                                $iFileCnt += $iCnt;
                            }
                            file_put_contents($sPath, $sTemplate);

                            $oInfo = $oUI->createTextNotification();
                            $oInfo->setText("Updated deprecated in file {$sPath} ({$iFileCnt})");
                            $oUI->addInfoForUser($oInfo);
                        } else {
                            $oInfo = $oUI->createTextNotification();
                            $oInfo->setText("Can not read/write file {$sPath}");
                            $oUI->addErrorForUser($oInfo, false, false);
                            return 'updateDeprecatedValues';
                        }
                    }
                }
            }
        }

        //updating deprecated values
        return "continueUpdate";
    }

    /**
     * return name of method to continue after templates updates are finished
     *
     * @param int $iInStepCounter sql counter
     *
     * @return string
     */
    public function continueUpdate()
    {
        return "updateSql";
    }

    /**
     * updates sql and keeps track of last executed one
     *
     * @param int $iInStepCounter sql counter
     *
     * @return string
     */
    public function updateMultilingualFields($iInStepCounter)
    {
        $sRet = parent::updateMultilingualFields($iInStepCounter);
        if ($sRet == '') {
            return 'updateThemesConfig';
        }
        return $sRet;
    }

    /**
     * updates oxconfig table - copy theme:basic values to theme:{curr theme}
     *
     * @param int $iInStepCounter step counter
     *
     * @return string
     */
    public function updateThemesConfig($iInStepCounter)
    {
        $sCurrentTheme = $this->getConfig()->getConfigParam('sTheme');
        if ($sCurrentTheme != 'basic') {
            $oDb = oxDb::getDb();
            $oDb->execute(
                "INSERT INTO `oxconfig`
                select md5(UUID()), oxshopid, 'theme:$sCurrentTheme', oxvarname, oxvartype, oxvarvalue
                from oxconfig
                where oxmodule = 'theme:basic'"
            );
            $oDb->execute(
                "INSERT INTO `oxconfigdisplay`
                select md5(UUID()), 'theme:$sCurrentTheme', oxcfgvarname, oxgrouping, oxvarconstraint, oxpos
                from oxconfigdisplay
                where oxcfgmodule = 'theme:basic'"
            );
        }
        return 'setCompareListParam';
    }

    /**
     * updates oxconfig table - copy theme:basic values to theme:{curr theme}
     *
     * @param int $iInStepCounter step counter
     *
     * @return string
     */
    public function setCompareListParam()
    {
        $sKey = $this->getConfig()->getConfigParam( 'sConfigKey' );
        $oDb = oxDb::getDb();

        $oDb->execute("
            UPDATE `oxconfig`
                LEFT JOIN `oxconfig` AS `oxconfig2` ON `oxconfig`.`oxshopid` = `oxconfig2`.`oxshopid` AND `oxconfig`.`oxmodule` = `oxconfig2`.`oxmodule`  AND `oxconfig2`.`OXVARNAME` = 'bl_perfLoadCompare'
            SET `oxconfig`.`OXVARVALUE` = IF( decode(`oxconfig`.`OXVARVALUE`, '" . $sKey . "') = 1 AND decode(`oxconfig2`.`OXVARVALUE`, '" . $sKey . "') = 1, encode(1, '" . $sKey . "'), encode(0, '" . $sKey . "'))
            WHERE `oxconfig`.`OXVARNAME` = 'bl_showCompareList'
        ");

        return 'deleteLoadCompareParam';
    }

    /**
     * updates oxconfig table - copy theme:basic values to theme:{curr theme}
     *
     * @param int $iInStepCounter step counter
     *
     * @return string
     */
    public function deleteLoadCompareParam()
    {
        $oDb = oxDb::getDb();

        $oDb->execute("DELETE FROM `oxconfig` WHERE `OXVARNAME` = 'bl_perfLoadCompare'");

        return 'updateCategoryThumbs';
    }

    /**
     * updates oxconfig table - copy theme:basic values to theme:{curr theme}
     *
     * @param int $iInStepCounter step counter
     *
     * @return string
     */
    public function updateCategoryThumbs()
    {
        $aLangData = $this->getConfig()->getConfigParam( 'aLanguages' );
        $oDb = oxDb::getDb();
        if ( is_array($aLangData) && count($aLangData) > 1 ) {
            $sSql = "";
            for ( $iLang = 1; $iLang < count($aLangData); $iLang++ ) {
                $sSql .= "UPDATE `oxcategories` SET `OXTHUMB_$iLang` = `OXTHUMB`; ";
            }
            $oDb->execute($sSql);
        }

        return '';
    }
}

