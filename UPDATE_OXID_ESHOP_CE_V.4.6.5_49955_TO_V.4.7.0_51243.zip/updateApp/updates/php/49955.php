<?php
/**
 * This Software is the property of OXID eSales and is protected
 * by copyright law - it is NOT Freeware.
 *
 * Any unauthorized use of this software without a valid license key
 * is a violation of the license agreement and will be prosecuted by
 * civil and criminal law.
 *
 * @link http://www.oxid-esales.com
 * @package updateApp
 * @copyright (C) OXID eSales AG 2003-2011
 * @version OXID eShop EE
 */


/**
 * update class for
 */
class update_49955 extends updateBase
{
    /**
     * default action, used in start update
     *
     * @var string
     */
    protected $_sDefaultAction = 'requestFilesStructureUpdate';

    /**
     * requests user to answer the question
     *
     * @return string
     */
    public function requestFilesStructureUpdate()
    {
        $oUI = $this->_getProcess()->getUI();
        $oInfo = $oUI->createRadioBtnQuestion();
        $aOptions = array( "1" => "Yes", "2" => "No" );
        $oInfo->setOptions($aOptions);
        $sDescription = "Do you want to move your themes and modules from old shop?";
        $oInfo->setDescription( $sDescription );
        $oInfo->setDefault("1");

        $oUI->userInputRequest( "reqId1", array("q1" => $oInfo), "Updating structure" );

        return "processUserInputRequest_1";
    }

    /**
     * checks user input and selects action to perform
     *
     * @return string
     */
    public function processUserInputRequest_1()
    {
        $oUI = $this->_getProcess()->getUI();
        $aResponce = $oUI->getUserAnswer( "reqId1" );

        switch ($aResponce["q1"]) {
            case "1":
                //updating files sturcture
                return "getPath";
                break;
            case "2":
                // skipping all file structure changes
                return "continueUpdate";
                break;
            default:
                // no (or bad) user input, requesting for user input again
                return "requestFilesStructureUpdate";
                break;
        }
    }

    /**
     * Continue update with sql script
     *
     * @return string
     */
    public function continueUpdate()
    {
        return 'updateSql';
    }


    /**
     * Inserts counter values from ox orders table
     *
     * @return string
     */
    public function getPath()
    {
        $oUI = $this->_getProcess()->getUI();
        $oInfo = $oUI->createTextQuestion();
        $oInfo->setLabel('Full path:');
        $oUI->userInputRequest( "reqId3", array("q1" => $oInfo), "Enter 4.6 shop full path (must be on the same server):" );
        return 'processUserInputRequest_2';
    }

    /**
     * checks user input and selects action to perform
     *
     * @return string
     */
    public function processUserInputRequest_2()
    {
        $oUI = $this->_getProcess()->getUI();
        $aResponce = $oUI->getUserAnswer( "reqId3" );
        $sPath = $aResponce["q1"];


        if (!is_dir($sPath)){
            //on error
            $oInfo = $oUI->createTextNotification();
            $oInfo->setText("Bad path or permissions.");
            $oUI->addErrorForUser($oInfo, false, false);
            return 'getPath';
        } else {
            $this->_moveThemeFiles( $sPath );
            $this->_moveModuleFiles( $sPath );
            $this->_moveLangFiles( $sPath );
        }

        return 'continueUpdate';
    }

    /**
     * moves module files
     */
    protected function _moveModuleFiles( $sShopPath )
    {
        $sShopDir = $this->getConfig()->getConfigParam('sShopDir');

        $aModuleFolders = $this->_getModuleList( $sShopPath );

        foreach ($aModuleFolders as $sFolder){
            $this->_moveFolder($sShopPath.'/modules/'.$sFolder, $sShopDir.'/modules/'.$sFolder);
        }
    }

    /**
     * moves theme files
     */
    protected function _moveThemeFiles( $sShopPath )
    {
        $sOutDir = $sShopPath.'/'.'out/';
        $sAppDir = $this->getConfig()->getAppDir();
        $sShopDir = $this->getConfig()->getConfigParam('sShopDir');

        $aThemeFolders = $this->_getThemeList( $sShopPath );

        $oLang = new oxLang();
        $aLangs = $oLang->getLanguageIds();



        foreach ($aThemeFolders as $sFolder) {

            if ( !is_dir( $sAppDir.'/views/'.$sFolder )  ) {

                mkdir( $sAppDir.'views/'.$sFolder );

                $this->_moveFolder( $sOutDir.$sFolder.'/tpl', $sAppDir.'views/'.$sFolder.'/tpl');
                $this->_moveFile( $sOutDir.$sFolder.'/theme.php', $sAppDir.'views/'.$sFolder.'/theme.php');
                foreach ($aLangs as $slang) {
                    $this->_moveFolder($sOutDir.$sFolder.'/'.$slang, $sAppDir.'views/'.$sFolder.'/'.$slang);
                }


               //moving to new shop
               $this->_moveFolder($sOutDir.$sFolder, $sShopDir.'/out/'.$sFolder);
            }
        }
    }

    /**
     * moves custom lang  files
     */
    protected function _moveLangFiles( $sShopPath )
    {
        $sOutDir = $sShopPath.'/'.'out/';
        $sAppDir = $this->getConfig()->getAppDir();

        $oLang = new oxLang();
        $aLangs = $oLang->getLanguageIds();

        foreach ($aLangs as $slang){
            $this->_moveFile($sOutDir.'/'.$slang.'/cust_lang.php', $sAppDir.'/translations/'.$slang.'/cust_lang.php');
        }
    }

    /**
     * get module names
     */
    protected function _getModuleList($sPath)
    {
        $aModuleNames = array();
        foreach ( glob( $sPath.'/modules/'."*", GLOB_ONLYDIR ) as $sDir ) {
            $aParts = explode('/', $sDir);
            $aModuleNames[] = $aParts[count($aParts)-1];
        }

        return $aModuleNames;
    }

    /**
     * get theme names
     */
    protected function _getThemeList( $sPath )
    {
        $aThemeNames = array();
        foreach ( glob( $sPath.'/out/'."*", GLOB_ONLYDIR ) as $sDir ) {
            if ( is_file($sDir.'/theme.php') ) {
                $aParts = explode('/', $sDir);
                $aThemeNames[] = $aParts[count($aParts)-1];
            }
        }

        return $aThemeNames;
    }


    /**
     * move file
     */
    protected function _moveFile( $sFile, $sNewLocation )
    {
        return rename( $sFile, $sNewLocation );
    }

    /**
     * move folder
     */
    protected function _moveFolder( $sFolder, $sNewLocation )
    {
        return rename( $sFolder, $sNewLocation );
    }

}
