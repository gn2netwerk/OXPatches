UPDATE `oxshops` SET `OXVERSION` = '4.6.0-';

UPDATE
    `oxcontents`
SET
    `OXCONTENT` = '<table>[{foreach from=$oView->getBargainArticleList() item=articlebargain_item}] <tbody><tr><td>\r\n<div class="product_image_s_container"><a href="[{$articlebargain_item->getLink()}]"><img border="0" alt="[{ $articlebargain_item->oxarticles__oxtitle->value }][{if $articlebargain_item->oxarticles__oxvarselect->value }] [{ $articlebargain_item->oxarticles__oxvarselect->value }][{/if}] [{$oxcmp_shop->oxshops__oxtitlesuffix->value}]" src="[{ $articlebargain_item->getDynImageDir()}]/[{$articlebargain_item->oxarticles__oxicon->value}]"></a></div> </td><td class="boxrightproduct-td"> <a href="[{$articlebargain_item->getLink()}]" class="boxrightproduct-td"><strong>[{ $articlebargain_item->oxarticles__oxtitle->value|cat:"\r\n"|cat:$articlebargain_item->oxarticles__oxvarselect->value|strip_tags|smartwordwrap:15:"<br>\r\n":2:1:"..." }]</strong></a><br>\r\n [{ if $articlebargain_item->isBuyable() }] <a href="[{$articlebargain_item->getToBasketLink()}]&amp;am=1&amp;oxcid=[{$oView->getContentId()}]" class="details" onclick="showBasketWnd();" rel="nofollow"><img border="0" src="[{$oViewConf->getImageUrl(''arrow_details.gif'')}]" alt=""> Jetzt bestellen! </a> [{/if}] </td></tr>[{/foreach}]\r\n</tbody></table>'
    , `OXCONTENT_1` = '<table>[{foreach from=$oView->getBargainArticleList() item=articlebargain_item}] <tbody><tr><td>\r\n<div class="product_image_s_container"><a href="[{$articlebargain_item->getLink()}]"><img border="0" src="[{ $articlebargain_item->getDynImageDir()}]/[{$articlebargain_item->oxarticles__oxicon->value}]" alt="[{ $articlebargain_item->oxarticles__oxtitle->value }][{if $articlebargain_item->oxarticles__oxvarselect->value }] [{ $articlebargain_item->oxarticles__oxvarselect->value }][{/if}] [{$oxcmp_shop->oxshops__oxtitlesuffix->value}]"></a></div> </td><td class="boxrightproduct-td"> <a class="boxrightproduct-td" href="[{$articlebargain_item->getLink()}]"><strong>[{ $articlebargain_item->oxarticles__oxtitle->value|cat:"\r\n"|cat:$articlebargain_item->oxarticles__oxvarselect->value|strip_tags|smartwordwrap:15:"<br>\r\n ":2:1:"..." }]</strong></a><br>\r\n [{ if $articlebargain_item->isBuyable()}] <a onclick="showBasketWnd();" class="details" href="[{$articlebargain_item->getToBasketLink()}]&amp;am=1&amp;oxcid=[{$oView->getContentId()}]" rel="nofollow"><img border="0" alt="" src="[{$oViewConf->getImageUrl(''arrow_details.gif'')}]"> Order now! </a> [{/if}] </td></tr>[{/foreach}] </tbody></table>'
WHERE `OXID` = 'c4241316c6e7b9503.93160420';

ALTER TABLE `oxarticles` ADD INDEX ( `OXSOLDAMOUNT` );
ALTER TABLE `oxarticles` ADD INDEX `parentsort` ( `OXPARENTID` , `OXSORT` );

ALTER TABLE `oxorder` CHANGE `OXORDERNR` `OXORDERNR` INT( 11 ) UNSIGNED NOT NULL DEFAULT '0';

ALTER TABLE  `oxarticles`
ADD  `OXUPDATEPRICE` DOUBLE NOT NULL default '0' AFTER `OXDELTIMEUNIT`,
ADD  `OXUPDATEPRICEA` DOUBLE NOT NULL default '0',
ADD  `OXUPDATEPRICEB` DOUBLE NOT NULL default '0',
ADD  `OXUPDATEPRICEC` DOUBLE NOT NULL default '0',
ADD  `OXUPDATEPRICETIME` TIMESTAMP NOT NULL ,
ADD INDEX (  `OXUPDATEPRICETIME` );

#
# donloadable products
#
ALTER TABLE  `oxarticles` ADD  `OXISDOWNLOADABLE` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT  '0';
ALTER TABLE  `oxarticles` ADD INDEX (  `OXISDOWNLOADABLE` );

CREATE TABLE IF NOT EXISTS `oxfiles` (
  `OXID` char(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `OXARTID` char(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `OXFILENAME` varchar(128) NOT NULL,
  `OXSTOREHASH` char(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `OXPURCHASEDONLY` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `OXMAXDOWNLOADS` int(11) NOT NULL default '-1',
  `OXMAXUNREGDOWNLOADS` int(11) NOT NULL default '-1',
  `OXLINKEXPTIME` int(11) NOT NULL default '-1',
  `OXDOWNLOADEXPTIME` int(11) NOT NULL default '-1',
  PRIMARY KEY (`OXID`),
  KEY `OXARTID` (`OXARTID`)
) ENGINE=MyISAM;


#
# Table structure for table `oxorderfiles`
#

CREATE TABLE IF NOT EXISTS `oxorderfiles` (
  `OXID` char(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `OXORDERID` char(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `OXFILENAME` varchar(128) NOT NULL,
  `OXFILEID` char(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `OXSHOPID` char(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `OXORDERARTICLEID` char(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `OXFIRSTDOWNLOAD` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `OXLASTDOWNLOAD` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `OXDOWNLOADCOUNT` int(10) unsigned NOT NULL,
  `OXMAXDOWNLOADCOUNT` int(10) unsigned NOT NULL,
  `OXDOWNLOADEXPIRATIONTIME` int(10) unsigned NOT NULL,
  `OXLINKEXPIRATIONTIME` int(10) unsigned NOT NULL,
  `OXRESETCOUNT` int(10) unsigned NOT NULL,
  `OXVALIDUNTIL` datetime NOT NULL,
  PRIMARY KEY (`OXID`),
  KEY `OXORDERID` (`OXORDERID`),
  KEY `OXFILEID` (`OXFILEID`),
  KEY `OXORDERARTICLEID` (`OXORDERARTICLEID`)
) ENGINE=InnoDB;

#
#for ipv6 was changed varchar size from 16 to 39
#

ALTER TABLE `oxorder` CHANGE `OXIP` `OXIP` VARCHAR( 39 ) NOT NULL default '';


#
# performance tunning
#
ALTER TABLE  `oxobject2category` ADD INDEX (  `OXTIME` );
ALTER TABLE  `oxuserbaskets` ADD INDEX (  `OXTITLE` );
ALTER TABLE  `oxuserbaskets` ADD INDEX (  `OXUSERID` );

ALTER TABLE `oxseo` CHANGE `OXSTDURL` `OXSTDURL` VARCHAR( 2048 ) NOT NULL ;
ALTER TABLE `oxseo` CHANGE `OXSEOURL` `OXSEOURL` VARCHAR( 2048 ) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL ;
ALTER TABLE `oxseo` ADD INDEX `SEARCHSEO`(OXSEOURL(100));

UPDATE `oxconfigdisplay` SET `OXVARCONSTRAINT` = '0|1|2|3' WHERE `oxconfigdisplay`.`OXID` = '1ec42a395d0595ee7741091898848474';

# splitted one option into two
INSERT oxconfig (OXID, OXSHOPID, OXVARNAME, OXVARTYPE, OXVARVALUE)
SELECT
    md5(concat(round(rand()*100000), now())),
    oxshops.OXID,
    'blWrappingVatOnTop',
    'bool',
    (select cfg.OXVARVALUE from oxconfig as cfg where cfg.OXVARNAME = 'blEnterNetPrice' and cfg.OXSHOPID=oxshops.oxid)
FROM oxshops
where not exists (select 1 from oxconfig as config where config.OXVARNAME = 'blWrappingVatOnTop' and config.OXSHOPID=oxshops.oxid);

#2747: Option blDisableNavBars must be global
update oxconfig set oxmodule = '' where oxvarname in ( 'blDisableNavBars' );
DELETE FROM `oxconfigdisplay` WHERE `oxcfgvarname` = 'blDisableNavBars';

#3757: replace options
INSERT INTO oxconfig
SELECT md5(concat(round(rand()*100000), now())), oxshops.OXID, '', 'blShowVATForPayCharge', 'bool', (select cfg.OXVARVALUE from oxconfig as cfg where cfg.OXVARNAME = 'blCalcVATForPayCharge' and cfg.OXSHOPID=oxshops.oxid)
FROM oxshops WHERE EXISTS (SELECT * FROM oxconfig WHERE oxvarname = 'blCalcVATForPayCharge');
INSERT INTO oxconfig
SELECT md5(concat(round(rand()*100000), now())), oxshops.OXID, '', 'blShowVATForDelivery', 'bool', (select cfg.OXVARVALUE from oxconfig as cfg where cfg.OXVARNAME = 'blCalcVATForDelivery' and cfg.OXSHOPID=oxshops.oxid)
FROM oxshops WHERE EXISTS (SELECT * FROM oxconfig WHERE oxvarname = 'blCalcVATForDelivery');
INSERT INTO oxconfig
SELECT md5(concat(round(rand()*100000), now())), oxshops.OXID, '', 'blShowVATForWrapping', 'bool', (select cfg.OXVARVALUE from oxconfig as cfg where cfg.OXVARNAME = 'blCalcVatForWrapping' and cfg.OXSHOPID=oxshops.oxid)
FROM oxshops WHERE EXISTS (SELECT * FROM oxconfig WHERE oxvarname = 'blCalcVatForWrapping');

ALTER TABLE  `oxnewsletter` ADD  `OXSUBJECT` VARCHAR( 255 ) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL default '';

UPDATE `oxshops` SET `OXVERSION` = '4.6.0';