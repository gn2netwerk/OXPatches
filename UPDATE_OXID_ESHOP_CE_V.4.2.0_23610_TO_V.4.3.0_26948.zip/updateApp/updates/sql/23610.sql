# updating shop version
UPDATE `oxshops` SET `OXVERSION` = '4.3.0-';

ALTER TABLE `oxactions` ADD `OXTITLE_1` CHAR( 128 ) NOT NULL default '' AFTER `OXTITLE` ;
ALTER TABLE `oxactions` ADD `OXTITLE_2` CHAR( 128 ) NOT NULL default '' AFTER `OXTITLE_1` ;
ALTER TABLE `oxactions` ADD `OXTITLE_3` CHAR( 128 ) NOT NULL default '' AFTER `OXTITLE_2` ;

INSERT oxconfig (OXID, OXSHOPID, OXVARNAME, OXVARTYPE, OXVARVALUE)
SELECT
    md5(concat(round(rand()*100000), now())),
    oxshops.OXID,
    options.name,
    'bool',
    0x07
FROM
    (select           convert('bl_perfShowCompareList' using latin1) as name
        union select  convert('bl_perfShowListmania' using latin1)
        union select  convert('bl_perfShowWishlist' using latin1)
        union select  convert('bl_perfShowVouchers' using latin1)
        union select  convert('bl_perfShowGiftWrapping' using latin1)
        union select  convert('bl_perfShowOpenId' using latin1)
    ) as options,
     oxshops
where not exists (select 1 from oxconfig as cfg where convert(cfg.OXVARNAME using latin1) =options.name and cfg.OXSHOPID=oxshops.oxid);

ALTER TABLE `oxarticles` ADD `OXISCONFIGURABLE` TINYINT NOT NULL DEFAULT '0' AFTER `OXISSEARCH` ;
ALTER TABLE `oxvoucherseries` ADD `OXCALCULATEONCE` TINYINT(1) NOT NULL DEFAULT 0 AFTER `OXMINIMUMVALUE` ;
ALTER TABLE `oxarticles` ADD `OXMPN` VARCHAR( 16 ) character set latin1 collate latin1_general_ci NOT NULL DEFAULT '' AFTER `OXDISTEAN`;
ALTER TABLE `oxarticles` ADD `OXPICSGENERATED` TINYINT(3) NOT NULL DEFAULT '0' AFTER `OXICON`;
update oxarticles set oxpicsgenerated = '12';

DROP TABLE IF EXISTS `oxstates`;

CREATE TABLE `oxstates` (
  `OXID` char(32) character set latin1 collate latin1_general_ci NOT NULL default '',
  `OXCOUNTRYID` char(32) character set latin1 collate latin1_general_ci NOT NULL default '',
  `OXTITLE` char(128) NOT NULL default '',
  `OXISOALPHA2` char(2) character set latin1 collate latin1_general_ci NOT NULL default '',
  `OXTITLE_1` char(128) NOT NULL default '',
  `OXTITLE_2` char(128) NOT NULL default '',
  `OXTITLE_3` char(128) NOT NULL default '',
  PRIMARY KEY  (`OXID`)
) ENGINE = MYISAM ;


ALTER TABLE oxuser ADD OXSTATEID varchar(32) character set latin1 collate latin1_general_ci NOT NULL default '' AFTER OXCOUNTRYID;

ALTER TABLE oxgroups MODIFY `OXTITLE` varchar(128) NOT NULL default '';

ALTER TABLE oxaddress  MODIFY `OXCOUNTRYID` varchar(32) collate latin1_general_ci NOT NULL default '';
ALTER TABLE oxaddress ADD OXSTATEID varchar(32) character set latin1 collate latin1_general_ci NOT NULL default '' AFTER OXCOUNTRYID;

ALTER TABLE oxorder MODIFY `OXCURRENCY` varchar(32) NOT NULL default '';
ALTER TABLE oxorder MODIFY `OXFOLDER` varchar(32) NOT NULL default '';
ALTER TABLE oxorder ADD OXBILLSTATEID varchar(32) character set latin1 collate latin1_general_ci NOT NULL default '' AFTER OXBILLCOUNTRYID;
ALTER TABLE oxorder ADD OXDELSTATEID varchar(32) character set latin1 collate latin1_general_ci NOT NULL default '' AFTER OXDELCOUNTRYID;
ALTER TABLE oxorder ADD `OXARTVAT1` DOUBLE NOT NULL DEFAULT '0' AFTER OXTOTALORDERSUM;
ALTER TABLE oxorder ADD `OXARTVATPRICE1` DOUBLE NOT NULL DEFAULT '0' AFTER OXARTVAT1;
ALTER TABLE oxorder ADD `OXARTVAT2` DOUBLE NOT NULL DEFAULT '0' AFTER OXARTVATPRICE1;
ALTER TABLE oxorder ADD `OXARTVATPRICE2` DOUBLE NOT NULL DEFAULT '0' AFTER OXARTVAT2;

#
# Data for table `oxstates`
#

INSERT INTO `oxstates` VALUES ('BB', 'a7c40f631fc920687.20179984', 'Brandenburg', 'BB', 'Brandenburg', '', '');
INSERT INTO `oxstates` VALUES ('BE', 'a7c40f631fc920687.20179984', 'Berlin', 'BE', 'Berlin', '', '');
INSERT INTO `oxstates` VALUES ('BW', 'a7c40f631fc920687.20179984', 'Baden-W�rttemberg', 'BW', 'Baden-Wurttemberg', '', '');
INSERT INTO `oxstates` VALUES ('BY', 'a7c40f631fc920687.20179984', 'Bayern', 'BY', 'Bavaria', '', '');
INSERT INTO `oxstates` VALUES ('HB', 'a7c40f631fc920687.20179984', 'Bremen', 'HB', 'Bremen', '', '');
INSERT INTO `oxstates` VALUES ('HE', 'a7c40f631fc920687.20179984', 'Hessen', 'HE', 'Hesse', '', '');
INSERT INTO `oxstates` VALUES ('HH', 'a7c40f631fc920687.20179984', 'Hamburg', 'HH', 'Hamburg', '', '');
INSERT INTO `oxstates` VALUES ('MV', 'a7c40f631fc920687.20179984', 'Mecklenburg-Vorpommern', 'MV', 'Mecklenburg-Western Pomerania', '', '');
INSERT INTO `oxstates` VALUES ('NI', 'a7c40f631fc920687.20179984', 'Niedersachsen', 'NI', 'Lower Saxony', '', '');
INSERT INTO `oxstates` VALUES ('NW', 'a7c40f631fc920687.20179984', 'Nordrhein-Westfalen', 'NW', 'North Rhine-Westphalia', '', '');
INSERT INTO `oxstates` VALUES ('RP', 'a7c40f631fc920687.20179984', 'Rheinland-Pfalz', 'RP', 'Rhineland-Palatinate', '', '');
INSERT INTO `oxstates` VALUES ('SH', 'a7c40f631fc920687.20179984', 'Schleswig-Holstein', 'SH', 'Schleswig-Holstein', '', '');
INSERT INTO `oxstates` VALUES ('SL', 'a7c40f631fc920687.20179984', 'Saarland', 'SL', 'Saarland', '', '');
INSERT INTO `oxstates` VALUES ('SN', 'a7c40f631fc920687.20179984', 'Sachsen', 'SN', 'Saxony', '', '');
INSERT INTO `oxstates` VALUES ('ST', 'a7c40f631fc920687.20179984', 'Sachsen-Anhalt', 'ST', 'Saxony-Anhalt', '', '');
INSERT INTO `oxstates` VALUES ('TH', 'a7c40f631fc920687.20179984', 'Th�ringen', 'TH', 'Thuringia', '', '');
INSERT INTO `oxstates` VALUES ('MB', '8f241f11095649d18.02676059', 'Manitoba', 'MB', 'Manitoba', '', '');
INSERT INTO `oxstates` VALUES ('NB', '8f241f11095649d18.02676059', 'Neubraunschweig', 'NB', 'New Brunswick', '', '');
INSERT INTO `oxstates` VALUES ('NF', '8f241f11095649d18.02676059', 'Neufundland und Labrador', 'NF', 'Newfoundland and Labrador', '', '');
INSERT INTO `oxstates` VALUES ('NT', '8f241f11095649d18.02676059', 'Nordwest-Territorien', 'NT', 'Northwest Territories', '', '');
INSERT INTO `oxstates` VALUES ('NS', '8f241f11095649d18.02676059', 'Nova Scotia', 'NS', 'Nova Scotia', '', '');
INSERT INTO `oxstates` VALUES ('NU', '8f241f11095649d18.02676059', 'Nunavut', 'NU', 'Nunavut', '', '');
INSERT INTO `oxstates` VALUES ('ON', '8f241f11095649d18.02676059', 'Ontario', 'ON', 'Ontario', '', '');
INSERT INTO `oxstates` VALUES ('PE', '8f241f11095649d18.02676059', 'Prince Edward Island', 'PE', 'Prince Edward Island', '', '');
INSERT INTO `oxstates` VALUES ('QC', '8f241f11095649d18.02676059', 'Quebec', 'QC', 'Quebec', '', '');
INSERT INTO `oxstates` VALUES ('SK', '8f241f11095649d18.02676059', 'Saskatchewan', 'SK', 'Saskatchewan', '', '');
INSERT INTO `oxstates` VALUES ('YK', '8f241f11095649d18.02676059', 'Yukon', 'YK', 'Yukon', '', '');
INSERT INTO `oxstates` VALUES ('AL', '8f241f11096877ac0.98748826', 'Alabama', 'AL', 'Alabama', '', '');
INSERT INTO `oxstates` VALUES ('AK', '8f241f11096877ac0.98748826', 'Alaska', 'AK', 'Alaska', '', '');
INSERT INTO `oxstates` VALUES ('AS', '8f241f11096877ac0.98748826', 'Amerikanisch-Samoa', 'AS', 'American Samoa', '', '');
INSERT INTO `oxstates` VALUES ('AZ', '8f241f11096877ac0.98748826', 'Arizona', 'AZ', 'Arizona', '', '');
INSERT INTO `oxstates` VALUES ('AR', '8f241f11096877ac0.98748826', 'Arkansas', 'AR', 'Arkansas', '', '');
INSERT INTO `oxstates` VALUES ('CA', '8f241f11096877ac0.98748826', 'Kalifornien', 'CA', 'California', '', '');
INSERT INTO `oxstates` VALUES ('CO', '8f241f11096877ac0.98748826', 'Colorado', 'CO', 'Colorado', '', '');
INSERT INTO `oxstates` VALUES ('CT', '8f241f11096877ac0.98748826', 'Connecticut', 'CT', 'Connecticut', '', '');
INSERT INTO `oxstates` VALUES ('DE', '8f241f11096877ac0.98748826', 'Delaware', 'DE', 'Delaware', '', '');
INSERT INTO `oxstates` VALUES ('DC', '8f241f11096877ac0.98748826', 'District of Columbia', 'DC', 'District of Columbia', '', '');
INSERT INTO `oxstates` VALUES ('FM', '8f241f11096877ac0.98748826', 'F�derierten Staaten von Mikronesien', 'FM', 'Federated States of Micronesia', '', '');
INSERT INTO `oxstates` VALUES ('FL', '8f241f11096877ac0.98748826', 'Florida', 'FL', 'Florida', '', '');
INSERT INTO `oxstates` VALUES ('GA', '8f241f11096877ac0.98748826', 'Georgia', 'GA', 'Georgia', '', '');
INSERT INTO `oxstates` VALUES ('GU', '8f241f11096877ac0.98748826', 'Guam', 'GU', 'Guam', '', '');
INSERT INTO `oxstates` VALUES ('HI', '8f241f11096877ac0.98748826', 'Hawaii', 'HI', 'Hawaii', '', '');
INSERT INTO `oxstates` VALUES ('ID', '8f241f11096877ac0.98748826', 'Idaho', 'ID', 'Idaho', '', '');
INSERT INTO `oxstates` VALUES ('IL', '8f241f11096877ac0.98748826', 'Illinois', 'IL', 'Illinois', '', '');
INSERT INTO `oxstates` VALUES ('IN', '8f241f11096877ac0.98748826', 'Indiana', 'IN', 'Indiana', '', '');
INSERT INTO `oxstates` VALUES ('IA', '8f241f11096877ac0.98748826', 'Iowa', 'IA', 'Iowa', '', '');
INSERT INTO `oxstates` VALUES ('KS', '8f241f11096877ac0.98748826', 'Kansas', 'KS', 'Kansas', '', '');
INSERT INTO `oxstates` VALUES ('KY', '8f241f11096877ac0.98748826', 'Kentucky', 'KY', 'Kentucky', '', '');
INSERT INTO `oxstates` VALUES ('LA', '8f241f11096877ac0.98748826', 'Louisiana', 'LA', 'Louisiana', '', '');
INSERT INTO `oxstates` VALUES ('ME', '8f241f11096877ac0.98748826', 'Maine', 'ME', 'Maine', '', '');
INSERT INTO `oxstates` VALUES ('MH', '8f241f11096877ac0.98748826', 'Marshallinseln', 'MH', 'Marshall Islands', '', '');
INSERT INTO `oxstates` VALUES ('MD', '8f241f11096877ac0.98748826', 'Maryland', 'MD', 'Maryland', '', '');
INSERT INTO `oxstates` VALUES ('MA', '8f241f11096877ac0.98748826', 'Massachusetts', 'MA', 'Massachusetts', '', '');
INSERT INTO `oxstates` VALUES ('MI', '8f241f11096877ac0.98748826', 'Michigan', 'MI', 'Michigan', '', '');
INSERT INTO `oxstates` VALUES ('MN', '8f241f11096877ac0.98748826', 'Minnesota', 'MN', 'Minnesota', '', '');
INSERT INTO `oxstates` VALUES ('MS', '8f241f11096877ac0.98748826', 'Mississippi', 'MS', 'Mississippi', '', '');
INSERT INTO `oxstates` VALUES ('MO', '8f241f11096877ac0.98748826', 'Missouri', 'MO', 'Missouri', '', '');
INSERT INTO `oxstates` VALUES ('MT', '8f241f11096877ac0.98748826', 'Montana', 'MT', 'Montana', '', '');
INSERT INTO `oxstates` VALUES ('NE', '8f241f11096877ac0.98748826', 'Nebraska', 'NE', 'Nebraska', '', '');
INSERT INTO `oxstates` VALUES ('NV', '8f241f11096877ac0.98748826', 'Nevada', 'NV', 'Nevada', '', '');
INSERT INTO `oxstates` VALUES ('NH', '8f241f11096877ac0.98748826', 'New Hampshire', 'NH', 'New Hampshire', '', '');
INSERT INTO `oxstates` VALUES ('NJ', '8f241f11096877ac0.98748826', 'New Jersey', 'NJ', 'New Jersey', '', '');
INSERT INTO `oxstates` VALUES ('NM', '8f241f11096877ac0.98748826', 'New Mexico', 'NM', 'Neumexiko', '', '');
INSERT INTO `oxstates` VALUES ('NY', '8f241f11096877ac0.98748826', 'New York', 'NY', 'New York', '', '');
INSERT INTO `oxstates` VALUES ('NC', '8f241f11096877ac0.98748826', 'North Carolina', 'NC', 'North Carolina', '', '');
INSERT INTO `oxstates` VALUES ('ND', '8f241f11096877ac0.98748826', 'North Dakota', 'ND', 'North Dakota', '', '');
INSERT INTO `oxstates` VALUES ('MP', '8f241f11096877ac0.98748826', 'N�rdlichen Marianen', 'MP', 'Northern Mariana Islands', '', '');
INSERT INTO `oxstates` VALUES ('OH', '8f241f11096877ac0.98748826', 'Ohio', 'OH', 'Ohio', '', '');
INSERT INTO `oxstates` VALUES ('OK', '8f241f11096877ac0.98748826', 'Oklahoma', 'OK', 'Oklahoma', '', '');
INSERT INTO `oxstates` VALUES ('OR', '8f241f11096877ac0.98748826', 'Oregon', 'OR', 'Oregon', '', '');
INSERT INTO `oxstates` VALUES ('PW', '8f241f11096877ac0.98748826', 'Palau', 'PW', 'Palau', '', '');
INSERT INTO `oxstates` VALUES ('PA', '8f241f11096877ac0.98748826', 'Pennsylvania', 'PA', 'Pennsylvania', '', '');
INSERT INTO `oxstates` VALUES ('PR', '8f241f11096877ac0.98748826', 'Puerto Rico', 'PR', 'Puerto Rico', '', '');
INSERT INTO `oxstates` VALUES ('RI', '8f241f11096877ac0.98748826', 'Rhode Island', 'RI', 'Rhode Island', '', '');
INSERT INTO `oxstates` VALUES ('SC', '8f241f11096877ac0.98748826', 'South Carolina', 'SC', 'S�dkarolina', '', '');
INSERT INTO `oxstates` VALUES ('SD', '8f241f11096877ac0.98748826', 'South Dakota', 'SD', 'S�ddakota', '', '');
INSERT INTO `oxstates` VALUES ('TN', '8f241f11096877ac0.98748826', 'Tennessee', 'TN', 'Tennessee', '', '');
INSERT INTO `oxstates` VALUES ('TX', '8f241f11096877ac0.98748826', 'Texas', 'TX', 'Texas', '', '');
INSERT INTO `oxstates` VALUES ('UT', '8f241f11096877ac0.98748826', 'Utah', 'UT', 'Utah', '', '');
INSERT INTO `oxstates` VALUES ('VT', '8f241f11096877ac0.98748826', 'Vermont', 'VT', 'Vermont', '', '');
INSERT INTO `oxstates` VALUES ('VI', '8f241f11096877ac0.98748826', 'Jungferninseln', 'VI', 'Virgin Islands', '', '');
INSERT INTO `oxstates` VALUES ('VA', '8f241f11096877ac0.98748826', 'Virginia', 'VA', 'Virginia', '', '');
INSERT INTO `oxstates` VALUES ('WA', '8f241f11096877ac0.98748826', 'Washington', 'WA', 'Washington', '', '');
INSERT INTO `oxstates` VALUES ('WV', '8f241f11096877ac0.98748826', 'West Virginia', 'WV', 'West Virginia', '', '');
INSERT INTO `oxstates` VALUES ('WI', '8f241f11096877ac0.98748826', 'Wisconsin', 'WI', 'Wisconsin', '', '');
INSERT INTO `oxstates` VALUES ('WY', '8f241f11096877ac0.98748826', 'Wyoming', 'WY', 'Wyoming', '', '');
INSERT INTO `oxstates` VALUES ('AA', '8f241f11096877ac0.98748826', 'Armed Forces Americas', 'AA', 'Armed Forces Americas', '', '');
INSERT INTO `oxstates` VALUES ('AE', '8f241f11096877ac0.98748826', 'Armed Forces', 'AE', 'Armed Forces', '', '');
INSERT INTO `oxstates` VALUES ('AP', '8f241f11096877ac0.98748826', 'Armed Forces Pacific', 'AP', 'Armed Forces Pacific', '', '');

#removing fields
ALTER TABLE `oxcountry` DROP COLUMN `OXSHOPID`;
ALTER TABLE `oxcountry` DROP KEY `OXSHOPID`;
ALTER TABLE `oxreviews` DROP COLUMN `OXSHOPID`;

#additional indexes
ALTER TABLE `oxgbentries` ADD INDEX ( `OXUSERID` );
ALTER TABLE `oxvendor` ADD INDEX ( `OXACTIVE` );
ALTER TABLE `oxstates` ADD INDEX ( `OXCOUNTRYID` );
ALTER TABLE `oxcountry` ADD KEY (`OXACTIVE`);
ALTER TABLE `oxuser` ADD KEY `OXLNAME` (`OXLNAME`);

# updating shop version
UPDATE `oxshops` SET `OXVERSION` = '4.3.0';