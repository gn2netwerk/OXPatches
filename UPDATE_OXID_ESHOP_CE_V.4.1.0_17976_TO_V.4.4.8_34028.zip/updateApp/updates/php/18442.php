<?php 
/**
 *    This file is part of OXID eShop Community Edition.
 *
 *    OXID eShop Community Edition is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    OXID eShop Community Edition is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with OXID eShop Community Edition.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @link http://www.oxid-esales.com
 * @package updateApp
 * @copyright (C) OXID eSales AG 2003-2011
 * @version OXID eShop CE
 */

/**
 * update class for rev. 18442
 */
class update_18442 extends updateBase
{
    /**
     * default action, used in start update
     *
     * @var string
     */
    protected $_sDefaultAction = 'updateOxShops';

    protected $_iRecPerTick = 500;

    /**
     * Inserting salts for all users (which has not salts yet) according to shop id
     *
     * @return string
     */
    public function updateOxShops()
    {
        $myConfig = $this->getConfig();
        
        $this->_removeFields();

        return 'updateSql';
    }

    /**
     * Get selected table fields
     *
     * @param sTableName table name
     *
     * return array
     */
    public function getFields( $sTableName )
    {

        $aFields = oxDb::getDb()->getAll("show columns from $sTableName where Field like 'OXACTIVE%' ");

        foreach ( $aFields as $aFieldInfo) {
            $aDbTablesFields[] = $aFieldInfo[0];
        }

        return $aDbTablesFields;
    }

    /**
     * Get selected table fields
     *
     * return null
     */
    protected function _removeFields()
    {
        $aFields = $this->getFields( "oxshops" );
        $aSql = array();
        foreach( $aFields as $sFieldName ) {
            if ( preg_match("/OXACTIVE_\d+/i", $sFieldName) ) {
                $aSql[] = "ALTER TABLE oxshops DROP COLUMN $sFieldName ";
            }
        }

        $oDb = oxDb::getDb();
        
        if ( !empty($aSql) ) {
            foreach( $aSql as $sSql ) {
                $oDb->execute( $sSql );
            }
        }
    }
}
