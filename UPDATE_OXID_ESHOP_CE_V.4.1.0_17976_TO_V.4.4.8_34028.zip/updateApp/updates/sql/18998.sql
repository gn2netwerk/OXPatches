# updating shop version
UPDATE `oxshops` SET `OXVERSION` = '4.1.3-';

ALTER TABLE `oxactions2article` ADD INDEX ( `OXARTID` ) ;

# updating shop version
UPDATE `oxshops` SET `OXVERSION` = '4.1.3';

