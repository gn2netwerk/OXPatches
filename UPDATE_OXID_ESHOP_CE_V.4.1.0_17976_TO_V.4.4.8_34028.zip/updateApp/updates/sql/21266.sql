# updating shop version
UPDATE `oxshops` SET `OXVERSION` = '4.1.5-';

# updating shop version
UPDATE `oxshops` SET `OXVERSION` = '4.1.5';
