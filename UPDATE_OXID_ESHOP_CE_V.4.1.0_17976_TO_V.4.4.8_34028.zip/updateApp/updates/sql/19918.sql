# updating shop version
UPDATE `oxshops` SET `OXVERSION` = '4.1.4-';

# updating shop version
UPDATE `oxshops` SET `OXVERSION` = '4.1.4';
