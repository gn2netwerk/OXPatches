# updating shop version
UPDATE `oxshops` SET `OXVERSION` = '4.1.1-';

alter table oxpricealarm modify `OXARTID` char(32) character set latin1 collate latin1_general_ci NOT NULL default '';

alter table oxobject2attribute modify `OXVALUE` char(255) NOT NULL default '';

# updating shop version
UPDATE `oxshops` SET `OXVERSION` = '4.1.1';