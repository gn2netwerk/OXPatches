# updating shop version
UPDATE `oxshops` SET `OXVERSION` = '4.2.0-';

UPDATE oxuser SET OXSAL = "MRS" WHERE OXSAL = "Frau";
UPDATE oxuser SET OXSAL = "MR"  WHERE OXSAL = "Herr";
UPDATE oxaddress SET OXSAL = "MRS" WHERE OXSAL = "Frau";
UPDATE oxaddress SET OXSAL = "MR"  WHERE OXSAL = "Herr";

# updating shop version
UPDATE `oxshops` SET `OXVERSION` = '4.2.0';