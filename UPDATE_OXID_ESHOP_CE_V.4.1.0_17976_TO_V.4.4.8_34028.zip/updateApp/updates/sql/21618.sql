# updating shop version
UPDATE `oxshops` SET `OXVERSION` = '4.1.6-';

ALTER TABLE `oxseo` CHANGE `OXSEOURL` `OXSEOURL` TEXT CHARACTER SET latin1 COLLATE latin1_bin NOT NULL;

# updating shop version
UPDATE `oxshops` SET `OXVERSION` = '4.1.6';