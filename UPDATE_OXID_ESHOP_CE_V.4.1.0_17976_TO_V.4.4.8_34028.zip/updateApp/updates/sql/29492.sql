# updating shop version
UPDATE `oxshops` SET `OXVERSION` = '4.4.3-';

ALTER TABLE `oxuserbasketitems` ADD `OXPERSPARAM` text NOT NULL AFTER `OXSELLIST`;

# updating shop version
UPDATE `oxshops` SET `OXVERSION` = '4.4.3';