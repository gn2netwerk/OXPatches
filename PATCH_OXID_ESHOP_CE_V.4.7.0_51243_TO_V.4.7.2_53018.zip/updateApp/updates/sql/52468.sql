UPDATE `oxshops` SET `OXVERSION` = '-4.7.2';

UPDATE `oxarticles`
    INNER JOIN (
        SELECT
            MIN( IF( `v`.`oxprice` > 0, `v`.`oxprice`, `p`.`oxprice` ) ) AS `varminprice`,
            MAX( IF( `v`.`oxprice` > 0, `v`.`oxprice`, `p`.`oxprice` ) ) AS `varmaxprice`,
            `v`.`oxparentid`
        FROM
            `oxarticles` AS `v`
            LEFT JOIN `oxarticles` AS `p` ON ( `p`.`oxid` = `v`.`oxparentid` AND `p`.`oxprice` > 0 )
        WHERE
            ( `v`.oxactive = 1 AND ( `v`.`oxstockflag` != 2 OR ( `v`.`oxstock` + `v`.`oxvarstock` ) > 0 ) AND IF( `v`.`oxvarcount` = 0, 1, ( select 1 from `oxarticles` as `art` where `art`.`oxparentid` = `v`.`oxid` and ( `art`.`oxactive` = 1 ) and ( `art`.`oxstockflag` != 2 or `art`.`oxstock` > 0 ) limit 1 ) ) )
        AND `v`.`oxparentid` IS NOT NULL
        AND `v`.`oxparentid` != ''
        GROUP BY
            `v`.`oxparentid`
    ) AS `arts` ON `oxarticles`.`oxid` = `arts`.`oxparentid`
SET
    `oxarticles`.`oxvarminprice` = `arts`.`varminprice`,
    `oxarticles`.`oxvarmaxprice` = `arts`.`varmaxprice`;

UPDATE `oxshops` SET `OXVERSION` = '4.7.2';
