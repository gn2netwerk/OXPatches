UPDATE `oxshops` SET `OXVERSION` = '4.5.3-';

UPDATE
    `oxmediaurls`
SET `oxurl` = SUBSTRING(`oxurl` FROM LOCATE( 'out/media/', `oxurl` ) + 10 )
WHERE
    `oxisuploaded` = 1;

UPDATE `oxshops` SET `OXVERSION` = '4.5.3';