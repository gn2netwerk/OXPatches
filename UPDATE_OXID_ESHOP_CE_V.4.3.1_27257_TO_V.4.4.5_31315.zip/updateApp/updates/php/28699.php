<?php
/**
 *    This file is part of OXID eShop Community Edition.
 *
 *    OXID eShop Community Edition is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    OXID eShop Community Edition is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with OXID eShop Community Edition.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @link http://www.oxid-esales.com
 * @package updateApp
 * @copyright (C) OXID eSales AG 2003-2010
 * @version OXID eShop CE
 */

/**
 * update class for rev. 28699
 */
class update_28699 extends updateBase
{
    /**
     * default action, used in start update
     *
     * @var string
     */
    protected $_sDefaultAction = 'fixOxStates';

    /**
     * Fixes oxstates table in utf-8 runing shops
     *
     * @return string
     */
    public function fixOxStates()
    {
        // only if shop runs utf-8
        if ( $this->getConfig()->isUtf() ) {
            $oDb = oxDb::getDb( true );

            $aMap = array( "Baden-W?rttemberg"                   => "Baden-W�rttemberg",
                           "Th?ringen"                           => "Th�ringen",
                           "F?derierten Staaten von Mikronesien" => "F�derierten Staaten von Mikronesien",
                           "N?rdlichen Marianen"                 => "N�rdlichen Marianen",
                           "S?dkarolina"                         => "S�dkarolina",
                           "S?ddakota"                           => "S�ddakota" );

            // selecting title fields
            $aCols = $oDb->getAll( "SHOW COLUMNS FROM oxstates WHERE field LIKE 'oxtitle%'" );

            // changing default table collation
            $oDb->execute( "ALTER TABLE oxstates DEFAULT CHARACTER SET utf8, COLLATE utf8_general_ci" );

            // fixing title fields collation and data
            foreach ( $aCols as $aCol ) {
               $oDb->execute( "ALTER TABLE oxstates CHANGE {$aCol['Field']} {$aCol['Field']} {$aCol['Type']} CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL default ''" );

               foreach ( $aMap as $sKey => $aValue ) {
                   $oDb->execute( "UPDATE oxstates SET {$aCol['Field']}='{$aValue}' WHERE {$aCol['Field']}='{$sKey}'" );
               }
            }
        }

        return 'updateSql';
    }
}