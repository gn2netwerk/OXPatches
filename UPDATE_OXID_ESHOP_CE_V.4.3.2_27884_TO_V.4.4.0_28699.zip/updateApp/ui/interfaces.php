<?php
/**
 *    This file is part of OXID eShop Community Edition.
 *
 *    OXID eShop Community Edition is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    OXID eShop Community Edition is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with OXID eShop Community Edition.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @link http://www.oxid-esales.com
 * @package updateApp
 * @copyright (C) OXID eSales AG 2003-2010
 * @version OXID eShop CE
 */

/**
 * abstract question interface
 */
interface IQuestionUI
{
    /**
     * display question
     *
     * @return null
     */
    public function display();

    /**
     * set default value
     *
     * @param string $sDefault
     *
     * @return null
     */
    public function setDefault($sDefault);
}

/**
 * interface for using free text questions
 */
interface IQuestionUIText extends IQuestionUI
{
    /**
     * set question label
     *
     * @param string $sMsg label
     *
     * @return null
     */
    public function setLabel($sMsg);
}

/**
 * interface for using radio buttons
 */
interface IQuestionUIRadioBtn extends IQuestionUI
{
    /**
     * set question options
     *
     * @param array $aOptions with key as abbrevation and value as text
     *
     * @return null
     */
    public function setOptions(array $aOptions);
}

interface IUserNotification
{
    /**
     * display note
     *
     * @return null
     */
    public function display();
}

interface IUserTextNotification extends IUserNotification
{
    /**
     * set note text
     *
     * @param string $sMsg text
     *
     * @return null
     */
    public function setText($sMsg);
}

interface IUserDataTableNotification extends IUserNotification
{
    /**
     * set note data
     *
     * @param array $aRows data matrix. rows[] = array(columns)
     *
     * @return null
     */
    public function setData(array $aRows);

    /**
     * set note header
     *
     * @param string $sMessage
     *
     * @return null
     */
    public function setHeader($sMessage);
}



/**
 * interface for accessing UI
 */
interface IUpdateUI
{
    /**
     * called on step start
     *
     * @return null
     */
    public function stepStart();

    /**
     * called on step end
     *
     * @return
     */
    public function stepEnd();

    /**
     * IQuestionUIText factory
     *
     * @return IQuestionUIText
     */
    public function createTextQuestion();

    /**
     * IQuestionUIRadioBtn factory
     *
     * @return IQuestionUIRadioBtn
     */
    public function createRadioBtnQuestion();

    /**
     * IUserTextNotification factory
     *
     * @return IUserTextNotification
     */
    public function createTextNotification();

    /**
     * IUserDataTableNotification factory
     *
     * @return IUserDataTableNotification
     */
    public function createDataTableNotification();

    /**
     * user input required. $aInput in request is array(data_id => IQuestionUI)
     *
     * @param string $sId         question id, to filter the answer
     * @param array  $aInput      questions
     * @param string $sMessage    question message header
     *
     * @return string
     */
    public function userInputRequest($sId, array $aInput, $sMessage);

    /**
     * user inputed answer
     *
     * @param string $sId         question id, to filter the answer
     *
     * @return array
     */
    public function getUserAnswer($sId);

    /**
     * print info for user
     *
     * @param IUserNotification $oInfo
     * @param bool              $blPause
     * @param bool              $blCopyMain
     * 
     * @return null
     */
    public function addInfoForUser(IUserNotification $oInfo, $blPause = true, $blCopyMain = false);

    /**
     * print error for user
     *
     * @param IUserNotification $oInfo
     *
     * @return null
     */
    public function addErrorForUser(IUserNotification $oInfo);
}
