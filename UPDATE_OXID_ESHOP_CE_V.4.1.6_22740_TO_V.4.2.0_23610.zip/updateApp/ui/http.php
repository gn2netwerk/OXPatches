<?php
/**
 *    This file is part of OXID eShop Community Edition.
 *
 *    OXID eShop Community Edition is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    OXID eShop Community Edition is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with OXID eShop Community Edition.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @link http://www.oxid-esales.com
 * @package updateApp
 * @copyright (C) OXID eSales AG 2003-2009
 * @version OXID eShop CE
 */

require_once dirname(__FILE__).'/interfaces.php';

/**
 * abstract Http question class
 */
abstract class uiHttpQuestion
{
    protected $_sDefault = null;
    protected $_sName = null;

    /**
     * set default value
     *
     * @param string $sDefault
     *
     * @return null
     */
    public function setDefault($sDefault)
    {
        $this->_sDefault = $sDefault;
    }

    /**
     * set question name
     *
     * @param string $sName
     *
     * @return null
     */
    public function setName($sName)
    {
        $this->_sName = $sName;
    }
}

/**
 * class for using free text questions in Http UI
 */
class uiHttpTextQuestion extends uiHttpQuestion implements IQuestionUIText
{
    protected $_sLabel = '';
    protected $_sInputRequired = false;

    /**
     * set question label
     *
     * @param string $sMsg label
     *
     * @return null
     */
    public function setLabel($sMsg)
    {
        $this->_sLabel = $sMsg;
    }

    /**
     * display question
     *
     * @return null
     */
    public function display()
    {
        if (!$this->_sName) {
            throw new Exception("input element without name!");
        }
        echo "<div class='question'>$this->_sLabel <input type='text' name='$this->_sName' value='";
        if ($this->_sDefault !== null) {
            echo htmlspecialchars($this->_sDefault);
        }
        echo "'></div>";
    }

}

class uiHttpRadioBtnQuestion extends uiHttpQuestion implements IQuestionUIRadioBtn
{
    protected $_aOptions = array();

    /**
     * set question options
     *
     * @param array $aOptions with key as abbrevation and value as text
     *
     * @return null
     */
    public function setOptions(array $aOptions)
    {
        $this->_aOptions = $aOptions;
    }

    /**
     * display question
     *
     * @return null
     */
    public function display()
    {
        echo "<div class='question'>";
        foreach ($this->_aOptions as $sValue => $sText) {
            $sChecked = '';
            if ($this->_sDefault === $sValue) {
                $sChecked = ' checked ';
            }
            echo "<input type='radio' name='".htmlspecialchars($this->_sName)
                ."' value='".htmlspecialchars($sValue)."'$sChecked>"
                .htmlspecialchars($this->$sText).'<br>';
        }
        echo "</div>";
    }
}


class uiHttpUserTextNotification implements IUserTextNotification
{
    protected $_sText = '';

    /**
     * set note text
     *
     * @param string $sMsg text
     *
     * @return null
     */
    public function setText($sMsg)
    {
        $this->_sText = $sMsg;
    }

    /**
     * display note
     *
     * @return null
     */
    public function display()
    {
        echo "<li> ".implode('<br>', array_map('htmlspecialchars', explode("\n", $this->_sText)));
    }
}

class uiHttpUserDataTableNotification implements IUserDataTableNotification
{
    protected $_aRows = array();
    protected $_sHeader = '';

    /**
     * set note data.
     *
     * @param array $aRows data matrix. rows[] = array(columns)
     *
     * @return null
     */
    public function setData(array $aRows)
    {
        $this->_aRows = $aRows;
    }

    /**
     * set note header
     *
     * @param string $sMessage
     *
     * @return null
     */
    public function setHeader($sMessage)
    {
        $this->_sHeader = $sMessage;
    }

    /**
     * display note
     *
     * @return null
     */
    public function display()
    {
        echo "<table>";
        if ($this->_sHeader) {
            echo "<caption>".htmlspecialchars($this->_sHeader)."</caption>";
            foreach ($this->_aRows as $aRow) {
                echo "<tr>";
                foreach ($aRow as $sCol) {
                    echo "<td>".implode('<br>', array_map('htmlspecialchars', explode("\n", $sCol)))."</td>";
                }
                echo "</tr>";
            }
        }
        echo "</table>";
    }
}


/**
 * Http UI handler class
 */
class uiHttp implements IUpdateUI
{

    protected $_sLog = '';
    protected $_sInputRequired = false;

    /**
     * called on step start
     *
     * @return null
     */
    public function stepStart() {}

    /**
     * called on step end
     *
     * @return
     */
    public function stepEnd() {}

    /**
     * IQuestionUIText factory
     *
     * @return IQuestionUIText
     */
    public function createTextQuestion()
    {
        return new uiHttpTextQuestion();
    }

    /**
     * IQuestionUIRadioBtn factory
     *
     * @return IQuestionUIRadioBtn
     */
    public function createRadioBtnQuestion()
    {
        return new uiHttpRadioBtnQuestion();
    }

    /**
     * IUserTextNotification factory
     *
     * @return IUserTextNotification
     */
    public function createTextNotification()
    {
        return new uiHttpUserTextNotification();
    }

    /**
     * IUserDataTableNotification factory
     *
     * @return IUserDataTableNotification
     */
    public function createDataTableNotification()
    {
        return new uiHttpUserDataTableNotification();
    }

    /**
     * user input required. $aInput in request is array(data_id => IQuestionUI)
     * after processing user request, callback fnc is invoked with array(data_id => user answer)
     *
     * @param string $sId         question id, to filter the answer
     * @param array  $aInput      questions
     * @param string $sMessage    question message header
     *
     * @return string
     */
    public function userInputRequest($sId, array $aInput, $sMessage)
    {
        if ($sMessage) {
            echo "<h2>$sMessage</h2>";
        }
        echo "<input type='hidden' value='".htmlspecialchars($sId)."' name='userInputRequestId'>";
        foreach ($aInput as $id => $question) {
            $question->setName($id);
            $question->display();
        }
        $this->_sInputRequired = true;
    }

    /**
     * user inputed answer
     *
     * @param string $sId         question id, to filter the answer
     *
     * @return array
     */
    public function getUserAnswer($sId)
    {
        if (!isset($_POST['userInputRequestId'])) {
            return array();
        }
        if ($sId != $_POST['userInputRequestId']) {
            return array();
        }

        return $_POST;
    }

    /**
     * print info for user
     *
     * @param IUserNotification $oInfo
     * @param bool              $blPause
     * @param bool              $blCopyMain
     *
     * @return null
     */
    public function addInfoForUser(IUserNotification $oInfo, $blPause = true, $blCopyMain = false)
    {
        if ($blCopyMain) {
            $oInfo->display();
        }

        ob_start();
        $oInfo->display();
        $this->_sLog .= ob_get_clean();

        if ($blPause) {
            $this->_sInputRequired = true;
        }
    }

    /**
     * print error for user
     *
     * @param IUserNotification $oInfo
     *
     * @return null
     */
    public function addErrorForUser(IUserNotification $oInfo)
    {
        echo "<div class='errorbox'>";
        $oInfo->display();
        echo "</div>";
        $this->_sInputRequired = true;
    }

    /**
     * get text for log window
     * 
     * @return string
     */
    public function getLogText()
    {
        return $this->_sLog;
    }

    /**
     * return true if we need user attention.
     *
     * @return bool
     */
    public function getConfirmStatus()
    {
        return (bool)$this->_sInputRequired;
    }
}
