<?php
/**
 *    This file is part of OXID eShop Community Edition.
 *
 *    OXID eShop Community Edition is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    OXID eShop Community Edition is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with OXID eShop Community Edition.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @link http://www.oxid-esales.com
 * @package updateApp
 * @copyright (C) OXID eSales AG 2003-2010
 * @version OXID eShop CE
 */

/**
 * class for keeping and retrieving update process states
 */
class updateTracker
{
    protected static $TRACKER_TABLE = 'oxupdatetrack';

    /**
     * class constructor
     */
    public function __construct()
    {
        oxDb::getDb()->execute(
           "create table if not exists ".self::$TRACKER_TABLE." (
              `oxid`            int auto_increment NOT NULL,
              `oxtime`          timestamp NOT NULL,
              `oxrev`           int NOT NULL,
              `oxpendingstep`   char(100) character set latin1 collate latin1_general_ci NOT NULL,
              `oxdata`          blob NOT NULL,
              PRIMARY KEY  (`oxid`),
              KEY `OXOBJECTID` (`oxtime`)
            ) TYPE=MyISAM;"
        );
    }

    /**
     *
     */
    public function deleteTable()
    {
        oxDb::getDb()->execute("drop table if exists ".self::$TRACKER_TABLE.";");
    }

    /**
     * return next revision and step
     *
     * @return array | null
     */
    public function getNextStep()
    {
        $oRs = oxDb::getDb()->execute("select oxrev, oxpendingstep, oxdata from ".self::$TRACKER_TABLE." order by oxtime desc, oxid desc limit 1");
        if ( $oRs != false && $oRs->recordCount() > 0 && !$oRs->EOF) {
            $data = @unserialize($oRs->fields[2]);
            return array($oRs->fields[0], $oRs->fields[1], $data);
        }
        return null;
    }

    /**
     * add a line to update table about next step
     *
     * @param int    $iRev        revision
     * @param string $sStep       next step
     * @param mixed  $iInStepData instep used data
     * 
     * @return null
     */
    public function setNextStep($iRev, $sStep, $iInStepData)
    {
        oxDb::getDb()->execute("insert into ".self::$TRACKER_TABLE." (oxtime, oxrev, oxpendingstep, oxdata) values (NOW(), ".(int)$iRev.", ".oxDb::getDb()->quote($sStep).", ".oxDb::getDb()->quote(serialize($iInStepData)).")");
    }
}
