UPDATE `oxshops` SET `OXVERSION` = '4.5.1-';

INSERT INTO `oxcontents` VALUES ('220404cee0caf470e227c1c9f1ec4ae3', 'oxrighttocancellegend2', 'oxbaseshop', 1, 0, 1, 1, '', 'Widerrufsrecht Hinweistext', '[{oxifcontent ident="oxagb" object="oCont"}]\r\n    Es gelten unsere <a id="orderConfirmAgbBottom" rel="nofollow" href="[{ $oCont->getLink() }]" onclick="window.open(''[{ $oCont->getLink()|oxaddparams:"plain=1"}]'', ''agb_popup'', ''resizable=yes,status=no,scrollbars=yes,menubar=no,width=620,height=400'');return false;" class="fontunderline">Allgemeinen Gesch�ftsbedingungen</a>.&nbsp;\r\n[{/oxifcontent}]\r\n[{oxifcontent ident="oxrightofwithdrawal" object="oCont"}]\r\n    Hier finden Sie <a id="test_OrderOpenWithdrawalBottom" rel="nofollow" href="[{ $oCont->getLink() }]" onclick="window.open(''[{ $oCont->getLink()|oxaddparams:"plain=1"}]'', ''rightofwithdrawal_popup'', ''resizable=yes,status=no,scrollbars=yes,menubar=no,width=620,height=400'');return false;">Einzelheiten zum Widerrufsrecht</a>.\r\n[{/oxifcontent}]', 'Right to Cancel Legend', '[{oxifcontent ident="oxagb" object="oCont"}] Our general <a id="orderConfirmAgbBottom" rel="nofollow" href="[{ $oCont->getLink() }]" onclick="window.open(''[{ $oCont->getLink()|oxaddparams:"plain=1"}]'', ''agb_popup'', ''resizable=yes,status=no,scrollbars=yes,menubar=no,width=620,height=400'');return false;" class="fontunderline">terms and conditions</a> apply.&nbsp;\r\n[{/oxifcontent}]\r\n[{oxifcontent ident="oxrightofwithdrawal" object="oCont"}]\r\n    Read details about  <a id="test_OrderOpenWithdrawalBottom" rel="nofollow" href="[{ $oCont->getLink() }]" onclick="window.open(''[{ $oCont->getLink()|oxaddparams:"plain=1"}]'', ''rightofwithdrawal_popup'', ''resizable=yes,status=no,scrollbars=yes,menubar=no,width=620,height=400'');return false;">right of withdrawal</a>.\r\n[{/oxifcontent}]', 1, '', '', 1, '', '', '8a142c3e4143562a5.46426637', 'CMSFOLDER_USERINFO', '');

#move top category perf options

INSERT INTO `oxconfig` VALUES('c20424bf2f8e71271.429555451', 'oxbaseshop', 'theme:basic', 'bl_perfLoadTreeForSearch', 'bool', 0x07);
INSERT INTO `oxconfig` VALUES('79e417a442934fcb9.117331841', 'oxbaseshop', 'theme:basic', 'bl_perfLoadCatTree', 'bool', 0x07);
INSERT INTO `oxconfig` VALUES('8563fba1c3936e4e0.645674481', 'oxbaseshop', 'theme:basic', 'blLoadFullTree', 'bool', '');
INSERT INTO `oxconfig` VALUES('8563fba1c39367724.92308656123456', 'oxbaseshop', '', 'blShowTags', 'bool', 0x07);
INSERT INTO `oxconfig` VALUES('1ec42a395d0595ee7741091898848992', 'oxbaseshop', 'theme:azure', 'sStartPageListDisplayType', 'select', 0x83CD10B7F09064ED);

UPDATE `oxconfigdisplay` SET `OXGROUPING` = 'navigation', `OXPOS` = 430 WHERE `OXCFGVARNAME` = 'blTopNaviLayout' AND `OXCFGMODULE` = 'theme:basic';

INSERT INTO `oxconfigdisplay` VALUES('79e417a442934fcb9.117331841', 'theme:basic', 'bl_perfLoadCatTree',       'navigation', '', 410);
INSERT INTO `oxconfigdisplay` VALUES('c20424bf2f8e71271.429555451', 'theme:basic', 'bl_perfLoadTreeForSearch', 'navigation', '', 420);
INSERT INTO `oxconfigdisplay` VALUES('8563fba1c3936e4e0.645674481', 'theme:basic', 'blLoadFullTree',           'navigation', '', 440);
INSERT INTO `oxconfigdisplay` VALUES('1ec42a395d0595ee7741091898848992', 'theme:azure', 'sStartPageListDisplayType',  'display',  'infogrid|line|grid', 22);

UPDATE `oxconfigdisplay` SET `OXPOS` = 110 WHERE `OXCFGVARNAME` = 'sIconsize'              AND `OXCFGMODULE` = 'theme:basic';
UPDATE `oxconfigdisplay` SET `OXPOS` = 120 WHERE `OXCFGVARNAME` = 'sThumbnailsize'         AND `OXCFGMODULE` = 'theme:basic';
UPDATE `oxconfigdisplay` SET `OXPOS` = 130 WHERE `OXCFGVARNAME` = 'sCatThumbnailsize'      AND `OXCFGMODULE` = 'theme:basic';
UPDATE `oxconfigdisplay` SET `OXPOS` = 140 WHERE `OXCFGVARNAME` = 'sZoomImageSize'         AND `OXCFGMODULE` = 'theme:basic';
UPDATE `oxconfigdisplay` SET `OXPOS` = 150 WHERE `OXCFGVARNAME` = 'aDetailImageSizes'      AND `OXCFGMODULE` = 'theme:basic';
UPDATE `oxconfigdisplay` SET `OXPOS` = 210 WHERE `OXCFGVARNAME` = 'bl_showCompareList'     AND `OXCFGMODULE` = 'theme:basic';
UPDATE `oxconfigdisplay` SET `OXPOS` = 220 WHERE `OXCFGVARNAME` = 'bl_showListmania'       AND `OXCFGMODULE` = 'theme:basic';
UPDATE `oxconfigdisplay` SET `OXPOS` = 230 WHERE `OXCFGVARNAME` = 'bl_showWishlist'        AND `OXCFGMODULE` = 'theme:basic';
UPDATE `oxconfigdisplay` SET `OXPOS` = 240 WHERE `OXCFGVARNAME` = 'bl_showVouchers'        AND `OXCFGMODULE` = 'theme:basic';
UPDATE `oxconfigdisplay` SET `OXPOS` = 250 WHERE `OXCFGVARNAME` = 'bl_showGiftWrapping'    AND `OXCFGMODULE` = 'theme:basic';
UPDATE `oxconfigdisplay` SET `OXPOS` = 310 WHERE `OXCFGVARNAME` = 'bl_perfShowLeftBasket'  AND `OXCFGMODULE` = 'theme:basic';
UPDATE `oxconfigdisplay` SET `OXPOS` = 320 WHERE `OXCFGVARNAME` = 'bl_perfShowRightBasket' AND `OXCFGMODULE` = 'theme:basic';
UPDATE `oxconfigdisplay` SET `OXPOS` = 330 WHERE `OXCFGVARNAME` = 'bl_perfShowTopBasket'   AND `OXCFGMODULE` = 'theme:basic';
UPDATE `oxconfigdisplay` SET `OXPOS` = 340 WHERE `OXCFGVARNAME` = 'blShowBirthdayFields'   AND `OXCFGMODULE` = 'theme:basic';
UPDATE `oxconfigdisplay` SET `OXPOS` = 350 WHERE `OXCFGVARNAME` = 'iTopNaviCatCount'       AND `OXCFGMODULE` = 'theme:basic';
UPDATE `oxconfigdisplay` SET `OXPOS` = 360 WHERE `OXCFGVARNAME` = 'blShowFinalStep'        AND `OXCFGMODULE` = 'theme:basic';
UPDATE `oxconfigdisplay` SET `OXPOS` = 370 WHERE `OXCFGVARNAME` = 'iNewBasketItemMessage'  AND `OXCFGMODULE` = 'theme:basic';
UPDATE `oxconfigdisplay` SET `OXPOS` = 380 WHERE `OXCFGVARNAME` = 'aNrofCatArticles'       AND `OXCFGMODULE` = 'theme:basic';
UPDATE `oxconfigdisplay` SET `OXPOS` = 390 WHERE `OXCFGVARNAME` = 'blDisableNavBars'       AND `OXCFGMODULE` = 'theme:basic';
UPDATE `oxconfigdisplay` SET `OXVARCONSTRAINT` = '0|1|2' WHERE `OXCFGMODULE` = 'theme:azure' AND `OXCFGVARNAME` = 'iNewBasketItemMessage';


CREATE INDEX SEARCHSTD  ON oxseo (OXSTDURL(100),`OXSHOPID`);

DROP TABLE IF EXISTS `oxcaptcha`;
CREATE TABLE IF NOT EXISTS `oxcaptcha` (
  `OXID` int(11) NOT NULL AUTO_INCREMENT,
  `OXHASH` char(32) NOT NULL default '',
  `OXTIME` int(11) NOT NULL,
  PRIMARY KEY (`OXID`),
  KEY `OXID` (`OXID`,`OXHASH`),
  KEY `OXTIME` (`OXTIME`)
) ENGINE=MEMORY AUTO_INCREMENT=1;

UPDATE `oxcontents`
SET
    `OXCONTENT` = '[{oxifcontent ident="oxagb" object="oCont"}]\r\n    Es gelten unsere <a id="orderConfirmAgbBottom" rel="nofollow" href="[{ $oCont->getLink() }]" onclick="window.open(''[{ $oCont->getLink()|oxaddparams:"plain=1"}]'', ''agb_popup'', ''resizable=yes,status=no,scrollbars=yes,menubar=no,width=620,height=400'');return false;" class="fontunderline">Allgemeinen Gesch�ftsbedingungen</a>.&nbsp;\r\n[{/oxifcontent}]\r\n[{oxifcontent ident="oxrightofwithdrawal" object="oCont"}]\r\n    Hier finden Sie <a id="test_OrderOpenWithdrawalBottom" rel="nofollow" href="[{ $oCont->getLink() }]" onclick="window.open(''[{ $oCont->getLink()|oxaddparams:"plain=1"}]'', ''rightofwithdrawal_popup'', ''resizable=yes,status=no,scrollbars=yes,menubar=no,width=620,height=400'');return false;">Einzelheiten zum Widerrufsrecht</a>.\r\n[{/oxifcontent}]'
    , `OXCONTENT_1` = '[{oxifcontent ident="oxagb" object="oCont"}] Our general <a id="orderConfirmAgbBottom" rel="nofollow" href="[{ $oCont->getLink() }]" onclick="window.open(''[{ $oCont->getLink()|oxaddparams:"plain=1"}]'', ''agb_popup'', ''resizable=yes,status=no,scrollbars=yes,menubar=no,width=620,height=400'');return false;" class="fontunderline">terms and conditions</a> apply.&nbsp;\r\n[{/oxifcontent}]\r\n[{oxifcontent ident="oxrightofwithdrawal" object="oCont"}]\r\n    Read details about  <a id="test_OrderOpenWithdrawalBottom" rel="nofollow" href="[{ $oCont->getLink() }]" onclick="window.open(''[{ $oCont->getLink()|oxaddparams:"plain=1"}]'', ''rightofwithdrawal_popup'', ''resizable=yes,status=no,scrollbars=yes,menubar=no,width=620,height=400'');return false;">right of withdrawal</a>.\r\n[{/oxifcontent}]'
WHERE
    `OXID` = '220404cee0caf470e227c1c9f1ec4ae3';

ALTER TABLE `oxtplblocks` CHANGE `OXBLOCKNAME` `OXBLOCKNAME` CHAR( 128 ) COLLATE latin1_general_ci NOT NULL;

UPDATE `oxshops` SET `OXVERSION` = '4.5.1';