# updating shop version
UPDATE `oxshops` SET `OXVERSION` = '4.4.0-';

ALTER TABLE `oxuser` DROP  KEY `OXACTIVE`;
ALTER TABLE `oxuser` DROP  KEY `OXLNAME`;
ALTER TABLE `oxuser` ADD INDEX ( `OXCUSTNR` );
ALTER TABLE `oxuser` ADD  KEY `OXACTIVE` (`OXACTIVE`);
ALTER TABLE `oxuser` ADD  KEY `OXLNAME` (`OXLNAME`);
ALTER TABLE `oxuser` CHANGE `OXCUSTNR` `OXCUSTNR` INT( 11 ) NOT NULL AUTO_INCREMENT;

ALTER TABLE `oxgroups` ADD `OXTITLE_1` varchar(128) NOT NULL default '' AFTER `OXTITLE` ;
ALTER TABLE `oxgroups` ADD `OXTITLE_2` varchar(128) NOT NULL default '' AFTER `OXTITLE_1` ;
ALTER TABLE `oxgroups` ADD `OXTITLE_3` varchar(128) NOT NULL default '' AFTER `OXTITLE_2` ;

#
# Table structure for table `oxobject2seodata`
# For storing SEO meta data
# Created 2010-05-11
#
DROP TABLE IF EXISTS `oxobject2seodata`;

CREATE TABLE `oxobject2seodata` (
`OXOBJECTID` CHAR( 32 ) character set latin1 collate latin1_general_ci NOT NULL,
`OXSHOPID` CHAR( 32 ) character set latin1 collate latin1_general_ci NOT NULL default '',
`OXLANG` INT( 2 ) NOT NULL default '0',
`OXKEYWORDS` TEXT NOT NULL ,
`OXDESCRIPTION` TEXT NOT NULL ,
PRIMARY KEY ( `OXOBJECTID` , `OXSHOPID` , `OXLANG` )
) ENGINE = MYISAM ;

# temporary table to copy data
CREATE TEMPORARY TABLE `_SUB` (
`OXOBJECTID` CHAR( 32 ) character set latin1 collate latin1_general_ci NOT NULL,
`OXSHOPID` CHAR( 32 ) character set latin1 collate latin1_general_ci NOT NULL default '',
`OXLANG` INT( 2 ) NOT NULL default '0',
`OXKEYWORDS` TEXT NOT NULL ,
`OXDESCRIPTION` TEXT NOT NULL
) ENGINE = MYISAM ;

# copying keywords
INSERT INTO `_SUB` ( oxobjectid, oxshopid, oxlang, oxkeywords )
SELECT oxseo.oxobjectid, oxseo.oxshopid, oxseo.oxlang, GROUP_CONCAT( oxseo.oxkeywords ) FROM oxseo
WHERE oxseo.oxkeywords != '' GROUP BY oxseo.oxshopid, oxseo.oxobjectid, oxseo.oxlang;

INSERT INTO oxobject2seodata ( oxobjectid, oxshopid, oxlang, oxkeywords )
SELECT `_SUB`.oxobjectid, `_SUB`.oxshopid, `_SUB`.oxlang, `_SUB`.oxkeywords
FROM `_SUB` ON DUPLICATE KEY UPDATE oxobject2seodata.oxkeywords = `_SUB`.oxkeywords;

# cleanup
DELETE FROM `_SUB`;

# copying description
INSERT INTO `_SUB` ( oxobjectid, oxshopid, oxlang, oxdescription )
SELECT oxseo.oxobjectid, oxseo.oxshopid, oxseo.oxlang, GROUP_CONCAT( oxseo.oxdescription ) FROM oxseo
WHERE oxseo.oxdescription != '' GROUP BY oxseo.oxshopid, oxseo.oxobjectid, oxseo.oxlang;

INSERT INTO oxobject2seodata ( oxobjectid, oxshopid, oxlang, oxdescription )
SELECT `_SUB`.oxobjectid, `_SUB`.oxshopid, `_SUB`.oxlang, `_SUB`.oxdescription
FROM `_SUB` ON DUPLICATE KEY UPDATE oxobject2seodata.oxdescription = `_SUB`.oxdescription;

# dropping old fields
ALTER TABLE `oxseo` DROP `OXKEYWORDS`;
ALTER TABLE `oxseo` DROP `OXDESCRIPTION`;

# terms and conditions version number storage
CREATE TABLE `oxacceptedterms` (
  `OXUSERID` char(32) character set latin1 collate latin1_general_ci NOT NULL,
  `OXSHOPID` char(32) character set latin1 collate latin1_general_ci NOT NULL default '',
  `OXTERMVERSION` char(32) character set latin1 collate latin1_general_ci NOT NULL default '',
  `OXACCEPTEDTIME` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY (`OXUSERID`, `OXSHOPID`)
) TYPE=MyISAM;

ALTER TABLE `oxcontents` ADD `OXTERMVERSION` char(32) character set latin1 collate latin1_general_ci NOT NULL default '' AFTER `OXFOLDER` ;
UPDATE `oxcontents` SET `OXTERMVERSION` = '1' WHERE `OXLOADID` = 'oxagb';

# registration confirmation..
INSERT INTO `oxcontents` (`OXID`, `OXLOADID`, `OXSHOPID`, `OXSNIPPET`, `OXTYPE`, `OXACTIVE`, `OXACTIVE_1`, `OXPOSITION`, `OXTITLE`, `OXCONTENT`, `OXTITLE_1`, `OXCONTENT_1`, `OXACTIVE_2`, `OXTITLE_2`, `OXCONTENT_2`, `OXACTIVE_3`, `OXTITLE_3`, `OXCONTENT_3`, `OXCATID`, `OXFOLDER`) VALUES ('460f3d25a752eeca8f8dbd66d04277c1', 'oxregisteraltemail', 'oxbaseshop', 1, 0, 1, 1, '', 'Alternative Registration Email HTML', 'Hello, [{ $user->oxuser__oxsal->value|oxmultilangsal }] [{ $user->oxuser__oxfname->value }] [{ $user->oxuser__oxlname->value }], <br />\r\n<br />\r\nthanks for your registration at [{ $shop->oxshops__oxname->value }]!<br />\r\nFrom now on, you can log in with your customer number <strong>[{ $user->oxuser__oxcustnr->value }]</strong>.<br />\r\n<br />\r\nFollow this link to confirm your registration:<br />\r\n<br /><a href=\"[{ $oViewConf->getBaseDir() }]index.php?cl=register&fnc=confirmRegistration&uid=[{ $user->getUpdateId() }]&amp;lang=[{ $oViewConf->getActLanguageId() }]&shp=[{ $shop->oxshops__oxid->value }]\">[{ $oViewConf->getBaseDir() }]index.php?cl=register&fnc=confirmRegistration&uid=[{ $user->getUpdateId()}]&amp;lang=[{ $oViewConf->getActLanguageId() }]&shp=[{ $shop->oxshops__oxid->value }]</a><br />\r\n<br />\r\nYou can use this link within the next [{ $user->getUpdateLinkTerm()/3600 }] hours.<br />\r\n<br />\r\n<br />\r\nYour [{ $shop->oxshops__oxname->value }] team', 'Alternative Registration Email HTML', 'Hello, [{ $user->oxuser__oxsal->value|oxmultilangsal }] [{ $user->oxuser__oxfname->value }] [{ $user->oxuser__oxlname->value }], <br />\r\n<br />\r\nthanks for your registration at [{ $shop->oxshops__oxname->value }]!<br />\r\nFrom now on, you can log in with your customer number <strong>[{ $user->oxuser__oxcustnr->value }]</strong>.<br />\r\n<br />\r\nFollow this link to confirm your registration:<br />\r\n<br /><a href=\"[{ $oViewConf->getBaseDir() }]index.php?cl=register&fnc=confirmRegistration&uid=[{ $user->getUpdateId() }]&amp;lang=[{ $oViewConf->getActLanguageId() }]&shp=[{ $shop->oxshops__oxid->value }]\">[{ $oViewConf->getBaseDir() }]index.php?cl=register&fnc=confirmRegistration&uid=[{ $user->getUpdateId()}]&amp;lang=[{ $oViewConf->getActLanguageId() }]&shp=[{ $shop->oxshops__oxid->value }]</a><br />\r\n<br />\r\nYou can use this link within the next [{ $user->getUpdateLinkTerm()/3600 }] hours.<br />\r\n<br />\r\n<br />\r\nYour [{ $shop->oxshops__oxname->value }] team', 1, '', '', 1, '', '', '30e44ab82c03c3848.49471214', 'CMSFOLDER_EMAILS');
INSERT INTO `oxcontents` (`OXID`, `OXLOADID`, `OXSHOPID`, `OXSNIPPET`, `OXTYPE`, `OXACTIVE`, `OXACTIVE_1`, `OXPOSITION`, `OXTITLE`, `OXCONTENT`, `OXTITLE_1`, `OXCONTENT_1`, `OXACTIVE_2`, `OXTITLE_2`, `OXCONTENT_2`, `OXACTIVE_3`, `OXTITLE_3`, `OXCONTENT_3`, `OXCATID`, `OXFOLDER`) VALUES ('460273f2ae78b9c40c536a1c331317ee', 'oxregisterplainaltemail', 'oxbaseshop', 1, 0, 1, 1, '', 'Alternative Registration Email PLAIN', 'Hello, [{ $user->oxuser__oxsal->value|oxmultilangsal }] [{ $user->oxuser__oxfname->getRawValue() }] [{ $user->oxuser__oxlname->getRawValue() }],\r\n\r\nthanks for your registration at [{ $shop->oxshops__oxname->getRawValue() }]!\r\nFrom now on, you can log in with your customer number [{ $user->oxuser__oxcustnr->value }].\r\n\r\nFollow this link to confirm your registration:\r\n[{ $oViewConf->getBaseDir() }]index.php?cl=register&fnc=confirmRegistration&uid=[{ $user->getUpdateId() }]&amp;lang=[{ $oViewConf->getActLanguageId() }]&shp=[{ $shop->oxshops__oxid->value }]\r\n\r\nYou can use this link within the next [{ $user->getUpdateLinkTerm()/3600 }] hours.<br />\r\n\r\n\r\nYour [{ $shop->oxshops__oxname->getRawValue() }] team', 'Alternative Registration Email PLAIN', 'Hello, [{ $user->oxuser__oxsal->value|oxmultilangsal }] [{ $user->oxuser__oxfname->getRawValue() }] [{ $user->oxuser__oxlname->getRawValue() }],\r\n\r\nthanks for your registration at [{ $shop->oxshops__oxname->getRawValue() }]!\r\nFrom now on, you can log in with your customer number [{ $user->oxuser__oxcustnr->value }].\r\n\r\nFollow this link to confirm your registration:\r\n[{ $oViewConf->getBaseDir() }]index.php?cl=register&fnc=confirmRegistration&uid=[{ $user->getUpdateId() }]&amp;lang=[{ $oViewConf->getActLanguageId() }]&shp=[{ $shop->oxshops__oxid->value }]\r\n\r\nYou can use this link within the next [{ $user->getUpdateLinkTerm()/3600 }] hours.<br />\r\n\r\n\r\nYour [{ $shop->oxshops__oxname->getRawValue() }] team', 1, '', '', 1, '', '', '30e44ab82c03c3848.49471214', 'CMSFOLDER_EMAILS');

# TS article delivery time
ALTER TABLE `oxarticles` ADD `OXMINDELTIME` int(11) NOT NULL default '0';
ALTER TABLE `oxarticles` ADD `OXMAXDELTIME` int(11) NOT NULL default '0';
ALTER TABLE `oxarticles` ADD `OXDELTIMEUNIT` varchar(255) NOT NULL default '';

# Right to Cancel confirm text
INSERT INTO `oxcontents` VALUES ('220404cee0caf470e227c1c9f1ec4ae2', 'oxrighttocancellegend', 'oxbaseshop', 1, 0, 1, 1, '', 'Widerrufsrecht Hinweistext', '[{oxifcontent ident="oxagb" object="oCont"}]\r\n    Ich habe die <a id="test_OrderOpenAGBBottom" rel="nofollow" href="[{ $oCont->getLink() }]" onclick="window.open(''[{ $oCont->getLink()|oxaddparams:"plain=1"}]'', ''agb_popup'', ''resizable=yes,status=no,scrollbars=yes,menubar=no,width=620,height=400'');return false;" class="fontunderline">AGB</a> gelesen und erkl�re mich mit ihnen einverstanden.&nbsp;\r\n[{/oxifcontent}]\r\n[{oxifcontent ident="oxrightofwithdrawal" object="oCont"}]\r\n    Ich wurde �ber mein <a id="test_OrderOpenWithdrawalBottom" rel="nofollow" href="[{ $oCont->getLink() }]" onclick="window.open(''[{ $oCont->getLink()|oxaddparams:"plain=1"}]'', ''rightofwithdrawal_popup'', ''resizable=yes,status=no,scrollbars=yes,menubar=no,width=620,height=400'');return false;">[{ $oCont->oxcontents__oxtitle->value }]</a> informiert.\r\n[{/oxifcontent}]', 'Right to Cancel Legend', '[{oxifcontent ident="oxagb" object="oCont"}] I agree to the <a id="test_OrderOpenAGBBottom" rel="nofollow" href="[{ $oCont->getLink() }]" onclick="window.open(''[{ $oCont->getLink()|oxaddparams:"plain=1"}]'', ''agb_popup'', ''resizable=yes,status=no,scrollbars=yes,menubar=no,width=620,height=400'');return false;" class="fontunderline">Terms and Conditions</a>.&nbsp;\r\n[{/oxifcontent}]\r\n[{oxifcontent ident="oxrightofwithdrawal" object="oCont"}]\r\n    I have been informed about my <a id="test_OrderOpenWithdrawalBottom" rel="nofollow" href="[{ $oCont->getLink() }]" onclick="window.open(''[{ $oCont->getLink()|oxaddparams:"plain=1"}]'', ''rightofwithdrawal_popup'', ''resizable=yes,status=no,scrollbars=yes,menubar=no,width=620,height=400'');return false;">[{ $oCont->oxcontents__oxtitle->value }]</a>.\r\n[{/oxifcontent}]', 1, '', '', 1, '', '', '8a142c3e4143562a5.46426637', 'CMSFOLDER_USERINFO', '');



# promotions
ALTER TABLE `oxactions` ADD `OXTYPE` TINYINT( 1 ) NOT NULL AFTER `OXID` ;
ALTER TABLE `oxactions` ADD `OXSHOPID` varchar(32) NOT NULL default '' AFTER `OXID` ;
ALTER TABLE `oxactions` ADD `OXLONGDESC` TEXT NOT NULL AFTER `OXTITLE_3`,
ADD `OXLONGDESC_1` TEXT NOT NULL AFTER `OXLONGDESC` ,
ADD `OXLONGDESC_2` TEXT NOT NULL AFTER `OXLONGDESC_1`,
ADD `OXLONGDESC_3` TEXT NOT NULL AFTER `OXLONGDESC_2`;
ALTER TABLE `oxactions` ADD `OXSORT` INT( 5 ) NOT NULL DEFAULT '0' AFTER `OXACTIVETO` ;
ALTER TABLE `oxactions` ADD INDEX ( `OXSORT` ) ;

CREATE TABLE IF NOT EXISTS `oxobject2action` (
  `OXID` char(32) collate latin1_general_ci NOT NULL,
  `OXACTIONID` char(32) collate latin1_general_ci NOT NULL default '',
  `OXOBJECTID` char(32) collate latin1_general_ci NOT NULL default '',
  `OXCLASS` char(32) collate latin1_general_ci NOT NULL default '',
  PRIMARY KEY  (`OXID`),
  KEY `OXOBJECTID` (`OXOBJECTID`),
  KEY `OXACTIONID` (`OXACTIONID`,`OXCLASS`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

# Invitation
CREATE TABLE IF NOT EXISTS `oxinvitations` (
   `OXUSERID` char(32) collate latin1_general_ci NOT NULL,
   `OXDATE` date NOT NULL,
   `OXEMAIL` varchar(255) collate latin1_general_ci NOT NULL,
   `OXPENDING` mediumint(9) NOT NULL,
   `OXACCEPTED` mediumint(9) NOT NULL,
   `OXTYPE` tinyint(4) NOT NULL default '1',
    KEY `OXUSERID` (`OXUSERID`),
    KEY `OXDATE` (`OXDATE`)
) ENGINE=MYISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

ALTER TABLE `oxuser` ADD `OXPOINTS` double NOT NULL default '0';
INSERT INTO `oxconfig` VALUES ('bd3e73e699331eb92c557113bac02fc4', 'oxbaseshop', 'dPointsForInvitation', 'str', 0x07c4);
INSERT INTO `oxconfig` VALUES ('bd320d322fa2f638086787c512329eec', 'oxbaseshop', 'dPointsForRegistration', 'str', 0x07c4);

# facebook user id
ALTER TABLE `oxuser` ADD `OXFBID` bigint(20) unsigned NOT NULL default '0';

# basket reservation expiration
ALTER TABLE `oxuserbaskets` ADD `OXUPDATE` INT NOT NULL default '0';

# trusted shops buyer protection
ALTER TABLE `oxpayments` ADD `OXTSPAYMENTID` char(32) NOT NULL default '';
ALTER TABLE `oxorder` ADD `OXTSPROTECTID` char(64) NOT NULL default '';
ALTER TABLE `oxorder` ADD `OXTSPROTECTCOSTS` double NOT NULL default '0';

# promotions lists selection
ALTER TABLE `oxactions` ADD INDEX ( `OXTYPE`, `OXACTIVE`, `OXACTIVETO`, `OXACTIVEFROM` );

# retrieving of timed out baskets
ALTER TABLE `oxuserbaskets` ADD INDEX (`OXUPDATE`);

# for #1918 fix
UPDATE oxseo SET oxexpired = '1' WHERE oxtype != "static";

# updating shop version
UPDATE `oxshops` SET `OXVERSION` = '4.4.0';