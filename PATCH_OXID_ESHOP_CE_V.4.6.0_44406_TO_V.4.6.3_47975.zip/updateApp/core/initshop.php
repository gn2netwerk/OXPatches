<?php
/**
 * This Software is the property of OXID eSales and is protected
 * by copyright law - it is NOT Freeware.
 *
 * Any unauthorized use of this software without a valid license key
 * is a violation of the license agreement and will be prosecuted by
 * civil and criminal law.
 *
 * @link http://www.oxid-esales.com
 * @package updateApp
 * @copyright (C) OXID eSales AG 2003-2011
 * @version OXID eShop EE
 */

//setting basic configuration parameters
ini_set('session.name', 'sid' );
ini_set('session.use_cookies', 0 );
ini_set('session.use_trans_sid', 0);
ini_set('url_rewriter.tags', '');
ini_set('magic_quotes_runtime', 0);

if (!function_exists('getShopBasePath')) {
    /**
     * Returns shop base path.
     *
     * @return string
     */
    function getShopBasePath()
    {
        return dirname(__FILE__).'/../../';
    }
}

set_include_path(get_include_path() . PATH_SEPARATOR . getShopBasePath());


/**
 * Returns true.
 *
 * @return bool
 */
if ( !function_exists( 'isAdmin' )) {
    function isAdmin()
    {
        return true;
    }
}

error_reporting( E_ALL ^ E_NOTICE );

// custom functions file
include getShopBasePath() . 'modules/functions.php';
// Generic utility method file
require_once getShopBasePath() . 'core/oxfunctions.php';
// Including main ADODB include
require_once getShopBasePath() . 'core/adodblite/adodb.inc.php';
// initializes singleton config class
$myConfig = oxConfig::getInstance();
// reset it so it is done with oxnew
$myConfig->setConfigParam( 'iDebug', -1 );
$iDebug = $myConfig->getConfigParam('iDebug');
// set the exception handler already here to catch everything, also uncaught exceptions from the config or utils
set_exception_handler(array(oxNew('oxexceptionhandler', $iDebug), 'handleUncaughtException'));
//strips magics quote if any
oxUtils::getInstance()->stripGpcMagicQuotes();

error_reporting( E_ALL | E_NOTICE | E_STRICT );
