<?php
/**
 *    This file is part of OXID eShop Community Edition.
 *
 *    OXID eShop Community Edition is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    OXID eShop Community Edition is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with OXID eShop Community Edition.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @link http://www.oxid-esales.com
 * @package updateApp
 * @copyright (C) OXID eSales AG 2003-2011
 * @version OXID eShop CE
 */

require_once dirname(__FILE__).'/interfaces.php';

/**
 * abstract CLI question class
 */
abstract class uiCliQuestion
{
    protected $_sDefault = null;

    /**
     * set default value
     *
     * @param string $sDefault
     *
     * @return null
     */
    public function setDefault($sDefault)
    {
        $this->_sDefault = $sDefault;
    }

    /**
     * validate input for question format
     * returns fixed string or null on failure
     *
     * @param string $sInput
     *
     * @return string
     */
    abstract public function validate($sInput);
}

/**
 * class for using free text questions in CLI UI
 */
class uiCliTextQuestion extends uiCliQuestion implements IQuestionUIText
{
    protected $_sLabel = '';

    /**
     * set question label
     *
     * @param string $sMsg label
     *
     * @return null
     */
    public function setLabel($sMsg)
    {
        $this->_sLabel = $sMsg;
    }

    /**
     * display question
     *
     * @return null
     */
    public function display()
    {
        $sInDef = '';
        if ($this->_sDefault !== null) {
            $sInDef = " (default is $this->_sDefault)";
        }
        echo "[input required:$sInDef] $this->_sLabel\n";
    }

    /**
     * validate input for question format
     *
     * @param string $sInput
     *
     * @return bool
     */
    public function validate($sInput)
    {
        if (!strlen($sInput) && $this->_sDefault !== null) {
            return $this->_sDefault;
        }
        return $sInput;
    }
}

class uiCliRadioBtnQuestion extends uiCliQuestion implements IQuestionUIRadioBtn
{
    protected $_aOptions     = array();
    protected $_sDescription = '';
    
    /**
     * set question options
     *
     * @param array $aOptions with key as abbrevation and value as text
     *
     * @return null
     */
    public function setOptions(array $aOptions)
    {
        $this->_aOptions = $aOptions;
    }
    
    /**
     * set general question description
     *
     * @param string $sDescription question description
     *
     * @return null
     */
    public function setDescription($sDescription)
    {
        $this->_sDescription = $sDescription;
    }

    /**
     * display question
     *
     * @return null
     */
    public function display()
    {
        if ( !empty($this->_sDescription) ) {
            echo "\n" . $this->_sDescription . "\n" ;
        }

        foreach ($this->_aOptions as $key => $text) {
            echo "[$key]\t$text\n";
        }
        $sInDef = '';
        if ($this->_sDefault !== null) {
            $sInDef = " (default is $this->_sDefault)";
        }
        echo "[please choose:$sInDef]\n";
    }

    /**
     * validate input for question format
     *
     * @param string $sInput
     *
     * @return bool
     */
    public function validate($sInput)
    {
        if (!strlen($sInput) && $this->_sDefault !== null) {
            $sInput = $this->_sDefault;
        }
        $keys = array_keys($this->_aOptions);
        foreach ($keys as $k=>$v) {
            $keys[$k] = (string)$v;
        }
        if (in_array((string)$sInput, $keys, 1)) {
            return (string)$sInput;
        }
        return null;
    }
}


class uiCliUserTextNotification implements IUserTextNotification
{
    protected $_sText = '';

    /**
     * set note text
     *
     * @param string $sMsg text
     *
     * @return null
     */
    public function setText($sMsg)
    {
        $this->_sText = $sMsg;
    }

    /**
     * display note
     *
     * @return null
     */
    public function display()
    {
        echo "[Note:]$this->_sText\n";
    }
}

class uiCliUserDataTableNotification implements IUserDataTableNotification
{
    protected $_aRows = array();
    protected $_sHeader = '';

    /**
     * set note data.
     *
     * @param array $aRows data matrix. rows[] = array(columns)
     *
     * @return null
     */
    public function setData(array $aRows)
    {
        $this->_aRows = $aRows;
    }

    /**
     * set note header
     *
     * @param string $sMessage
     *
     * @return null
     */
    public function setHeader($sMessage)
    {
        $this->_sHeader = $sMessage;
    }

    /**
     * get max len of string
     * 
     * @param string $sString 
     * 
     * @return int
     */
    protected function _getMaxLen($sString)
    {
        $aS = explode("\n", $sString);
        $max = 0;
        foreach ($aS as $sS) {
            if ($max < strlen($sS)) {
                $max = strlen($sS);
            }
        }
        return $max;
    }

    /**
     * display note
     *
     * @return null
     */
    public function display()
    {
        echo "[Note: $this->_sHeader]\n";
        $maxW = array();
        foreach ($this->_aRows as $aColumns) {
            $i = 0;
            foreach ($aColumns as $sText) {
                if (!isset($maxW[$i])) {
                    $maxW[$i] = 0;
                }
                $iLen = $this->_getMaxLen($sText);
                if ($maxW[$i] < $iLen) {
                    $maxW[$i] = $iLen;
                }
                $i++;
            }
        }
        foreach ($this->_aRows as $aColumns) {
            $i = 0;
            $left = 0;
            foreach ($aColumns as $sText) {
                echo "|".str_replace("\n", "\n".str_repeat(" ", $left).'|   ', str_pad($sText, $maxW[$i]));
                $left += $maxW[$i]+1;
                $i++;
            }
            echo "|\n";
        }
    }
}


/**
 * CLI UI handler class
 */
class uiCli implements IUpdateUI
{
    protected $_aAnswer = array();

    /**
     * called on step start
     *
     * @return null
     */
    public function stepStart() {}

    /**
     * called on step end
     *
     * @return
     */
    public function stepEnd() {}

    /**
     * IQuestionUIText factory
     *
     * @return IQuestionUIText
     */
    public function createTextQuestion()
    {
        return new uiCliTextQuestion();
    }

    /**
     * IQuestionUIRadioBtn factory
     *
     * @return IQuestionUIRadioBtn
     */
    public function createRadioBtnQuestion()
    {
        return new uiCliRadioBtnQuestion();
    }

    /**
     * IUserTextNotification factory
     *
     * @return IUserTextNotification
     */
    public function createTextNotification()
    {
        return new uiCliUserTextNotification();
    }

    /**
     * IUserDataTableNotification factory
     *
     * @return IUserDataTableNotification
     */
    public function createDataTableNotification()
    {
        return new uiCliUserDataTableNotification();
    }

    /**
     * user input required. $aInput in request is array(data_id => IQuestionUI)
     * after processing user request, callback fnc is invoked with array(data_id => user answer)
     *
     * @param string $sId         question id, to filter the answer
     * @param array  $aInput      questions
     * @param string $sMessage    question message header
     *
     * @return string
     */
    public function userInputRequest($sId, array $aInput, $sMessage)
    {
        $aRet = array();
        echo "\n--------------------------------------\n";

        if ($sMessage) {
            echo "$sMessage\n";
        }
        foreach ($aInput as $id => $question) {
            $ok = false;
            $sAnswer = '';
            do {
                $question->display();
                $sAnswer = $this->_readUserInput();
                $sAnswer = $question->validate($sAnswer);
                if ($sAnswer !== null) {
                    do {
                        $ok = $this->_readEnsurance($sAnswer);
                    } while ($ok === null);
                }
            } while (!$ok);
            $aRet[$id] = $sAnswer;
        }
        $this->_aAnswer[$sId] = $aRet;
    }

    /**
     * user inputed answer
     *
     * @param string $sId         question id, to filter the answer
     *
     * @return array
     */
    public function getUserAnswer($sId)
    {
        return $this->_aAnswer[$sId];
    }

    /**
     * reads user input from stdin
     *
     * @return string
     */
    protected function _readUserInput()
    {
        $fp = fopen("php://stdin","r");
        $line = '';
        $aRet = array();
        $blMoreLines = false;
        do {
            $line = rtrim(fgets($fp,65535));
            $aRet[] = rtrim(rtrim($line, '\\'));
            if ($iLen = strlen($line)) {
                $blMoreLines = ($line[$iLen - 1] == '\\');
            } else {
                $blMoreLines = false;
            }
        } while ($blMoreLines);
        fclose($fp);
        return implode("\n", $aRet);
    }

    /**
     * repeat given answer and ask yes/no with Y default
     * return null on "not sure" answer (any different than y/n or empty)
     *
     * @param string $sAnswer
     *
     * @return bool|null
     */
    protected function _readEnsurance($sAnswer)
    {
        echo "\n---\nyou answered:\n$sAnswer\nis this correct? (Y/n)";
        $sEnsure = trim($this->_readUserInput());
        if (!$sEnsure || $sEnsure=='Y' || $sEnsure == 'y') {
            return true;
        }
        if ($sEnsure == 'n' || $sEnsure == 'N') {
            return false;
        }
        return null;
    }

    /**
     * print info for user
     *
     * @param IUserNotification $oInfo
     * @param bool              $blPause
     * @param bool              $blCopyMain
     *
     * @return null
     */
    public function addInfoForUser(IUserNotification $oInfo, $blPause = true, $blCopyMain = false)
    {
        $oInfo->display();
        if ($blPause) {
            echo " *> press enter to continue:\n";
            $this->_readUserInput();
        }
    }

    /**
     * print error for user
     *
     * @param IUserNotification $oInfo
     *
     * @return null
     */
    public function addErrorForUser(IUserNotification $oInfo)
    {
        echo "\n================\n";
        $oInfo->display();
        echo " *> press enter to continue:\n";
        $this->_readUserInput();
    }

}
