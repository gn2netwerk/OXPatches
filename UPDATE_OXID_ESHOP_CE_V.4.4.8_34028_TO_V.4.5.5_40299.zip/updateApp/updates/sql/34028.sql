UPDATE `oxshops` SET `OXVERSION` = '4.5.0-';

ALTER TABLE  `oxpayments` ADD  `OXADDSUMRULES` INT( 11 ) NOT NULL DEFAULT  '0' AFTER  `OXADDSUMTYPE`;

CREATE INDEX listall ON oxconfig (`OXSHOPID`, `OXMODULE`);
DROP INDEX OXSHOPID ON oxconfig;


update oxconfig set oxvartype = 'select' where oxvarname='iNewBasketItemMessage';

-- copy
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`)
select md5( concat( RAND(), oxvarname, oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:basic', oxvarname, oxvartype, oxvarvalue
from oxconfig, oxshops
where oxvarname in (
    'sThumbnailsize',
    'sCatThumbnailsize',
    'sZoomImageSize',
    'aDetailImageSizes',
    'sIconsize'
);

-- update
update oxconfig
set oxmodule = 'theme:basic'
where oxvarname in (
    'bl_perfShowLeftBasket',
    'bl_perfShowRightBasket',
    'bl_showCompareList',
    'bl_showListmania',
    'bl_showWishlist',
    'bl_showVouchers',
    'bl_showGiftWrapping',
    'bl_showOpenId',
    'iNewBasketItemMessage',
    'blShowBirthdayFields',
    'blTopNaviLayout',
    'iTopNaviCatCount',
    'bl_perfShowTopBasket',
    'blShowFinalStep',
    'blDisableNavBars'
);

-- data for basic theme

DELETE FROM `oxconfig` WHERE `oxvarname` = 'aNrofCatArticles';
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`) SELECT md5( concat( RAND(), 'aNrofCatArticles', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:basic', 'aNrofCatArticles', 'arr', 0x4dbace2972e14bf2cbd3a9a4113b83ad1c8f7b704f710ba39fd1ecd29b438b41809712e316c6f4fdc92741f7876cc6fca127d78994e604dcc99519 FROM oxshops;

-- data for azure theme
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`) SELECT md5( concat( RAND(), 'sIconsize', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:azure', 'sIconsize', 'str', 0x8064a213b1 FROM oxshops;
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`) SELECT md5( concat( RAND(), 'sThumbnailsize', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:azure', 'sThumbnailsize', 'str', 0x079a3a49ca3630 FROM oxshops;
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`) SELECT md5( concat( RAND(), 'sCatThumbnailsize', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:azure', 'sCatThumbnailsize', 'str', 0x77e7ed4ecd3137 FROM oxshops;
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`) SELECT md5( concat( RAND(), 'sZoomImageSize', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:azure', 'sZoomImageSize', 'str', 0x170A3340D372BE FROM oxshops;
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`) SELECT md5( concat( RAND(), 'aDetailImageSizes', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:azure', 'aDetailImageSizes', 'aarr', 0x4dba326a73d2cdcb471b9533d7800b4b898873f7ae9dc29ed9e0e4f6bc678f00ea1438810efd6c1fe338a39dc20247d3a63beec4852106b7a1dd7cb1451f56975c3fd6159579cd2cab97104f17ae6c45a38a41e9a5bc59ceee828bfd6883e282aef2e55d00fb7ee9abb79b63c74cb7ba3fa76665f6a9294d8bf365bf7d3d0d56faf2355df145b02498b144bc6b0ab9fc9f74d2e1dd0ac7a4989184f58b7e2c58400bb4b92c9468f3d8ca7170cde789d6c1282016056e51005091e19803a859992a5549080378f64fff88ce4c1cbdf4afd32943b63877831b221ca302652eabe106a93f9f4d1ed363f2f33c1e29716b95b8541d2f79ec8a7a1d821a46270a1bb5f32622a06655b85a31d7ee2f52dbf963fd4426a6047b0e2bc4896143076e8dbc7dd8a7448ba2a5233ec8d166b611c288134420559cc4a6f4eec2835336d4f71df0ac899e314365a321d1d774bdb9 FROM oxshops;
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`) SELECT md5( concat( RAND(), 'bl_showCompareList', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:azure', 'bl_showCompareList', 'bool', 0x07 FROM oxshops;
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`) SELECT md5( concat( RAND(), 'bl_showListmania', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:azure', 'bl_showListmania', 'bool', 0x07 FROM oxshops;
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`) SELECT md5( concat( RAND(), 'bl_showWishlist', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:azure', 'bl_showWishlist', 'bool', 0x07 FROM oxshops;
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`) SELECT md5( concat( RAND(), 'bl_showVouchers', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:azure', 'bl_showVouchers', 'bool', 0x07 FROM oxshops;
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`) SELECT md5( concat( RAND(), 'bl_showGiftWrapping', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:azure', 'bl_showGiftWrapping', 'bool', 0x07 FROM oxshops;
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`) SELECT md5( concat( RAND(), 'bl_showOpenId', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:azure', 'bl_showOpenId', 'bool', 0x07 FROM oxshops;
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`) SELECT md5( concat( RAND(), 'bl_perfLoadCompare', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:azure', 'bl_perfLoadCompare', 'bool', 0x07 FROM oxshops;
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`) SELECT md5( concat( RAND(), 'blShowBirthdayFields', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:azure', 'blShowBirthdayFields', 'bool', 0x07 FROM oxshops;
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`) SELECT md5( concat( RAND(), 'iTopNaviCatCount', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:azure', 'iTopNaviCatCount', 'str', '' FROM oxshops;
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`) SELECT md5( concat( RAND(), 'blShowFinalStep', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:azure', 'blShowFinalStep', 'bool', 0x07 FROM oxshops;
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`) SELECT md5( concat( RAND(), 'sManufacturerIconsize', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:azure', 'sManufacturerIconsize', 'str', 0x07c4b144c7b838 FROM oxshops;
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`) SELECT md5( concat( RAND(), 'sCatIconsize', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:azure', 'sCatIconsize', 'str', 0x070de94ac9b636 FROM oxshops;
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`) SELECT md5( concat( RAND(), 'sCatPromotionsize', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:azure', 'sCatPromotionsize', 'str', 0xb06fb441c2bd94 FROM oxshops;
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`) SELECT md5( concat( RAND(), 'sDefaultListDisplayType', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:azure', 'sDefaultListDisplayType', 'select', 0x83CD10B7F09064ED FROM oxshops;
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`) SELECT md5( concat( RAND(), 'blShowListDisplayType', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:azure', 'blShowListDisplayType', 'bool', 0x07 FROM oxshops;
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`) SELECT md5( concat( RAND(), 'iNewBasketItemMessage', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:azure', 'iNewBasketItemMessage', 'select', 0x07 FROM oxshops;
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`) SELECT md5( concat( RAND(), 'aNrofCatArticles', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:azure', 'aNrofCatArticles', 'arr', 0x4dbace2972e14bf2cbd3a9a4113b83ad1c8f7b704f710ba39fd1ecd29b438b41809712e316c6f4fdc92741f7876cc6fca127d78994e604dcc99519 FROM oxshops;
INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`) SELECT md5( concat( RAND(), 'aNrofCatArticlesInGrid', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, 'theme:azure', 'aNrofCatArticlesInGrid', 'arr', 0x4dbace2972e14bf2cbd3a9a4113b83c51e8d79724d7309a19dd3ee6153448c46879015e411c1f3fa250245f38368c2f8a523d58c91546b92cdf6 FROM oxshops;

-- updating collations
ALTER TABLE  `oxconfig` CHANGE  `OXMODULE`  `OXMODULE` varchar(32) character set latin1 collate latin1_general_ci NOT NULL default '';
ALTER TABLE  `oxconfig` CHANGE  `OXVARNAME`  `OXVARNAME` char(32) character set latin1 collate latin1_general_ci NOT NULL default '';
ALTER TABLE  `oxconfig` CHANGE  `OXVARTYPE`  `OXVARTYPE` varchar(16) character set latin1 collate latin1_general_ci NOT NULL default '';

--


CREATE TABLE `oxconfigdisplay` (
  `OXID`            char(32) character set latin1 collate latin1_general_ci NOT NULL,
  `OXCFGMODULE`     varchar(32) character set latin1 collate latin1_general_ci NOT NULL default '',
  `OXCFGVARNAME`    char(32) character set latin1 collate latin1_general_ci NOT NULL default '',
  `OXGROUPING`      varchar(255) NOT NULL default '',
  `OXVARCONSTRAINT` varchar(255) NOT NULL default '',
  `OXPOS`           int NOT NULL default 0,
  PRIMARY KEY  (`OXID`),
  KEY `list` (`OXCFGMODULE`, `OXCFGVARNAME`)
) ENGINE=MyISAM;


INSERT INTO `oxconfigdisplay` VALUES('0ec4235c2aee774aa45d772875437919', 'theme:basic', 'sIconsize',              'images',   '', 1);
INSERT INTO `oxconfigdisplay` VALUES('0563fba1bee774aec57c192086494217', 'theme:basic', 'sThumbnailsize',         'images',   '', 2);
INSERT INTO `oxconfigdisplay` VALUES('0563fba1bee774aec599d56894094456', 'theme:basic', 'sCatThumbnailsize',      'images',   '', 3);
INSERT INTO `oxconfigdisplay` VALUES('02642dfaa1dee77488b1b22948593071', 'theme:basic', 'sZoomImageSize',         'images',   '', 4);
INSERT INTO `oxconfigdisplay` VALUES('02642dfaa1dee77487d0644506753921', 'theme:basic', 'aDetailImageSizes',      'images',   '', 5);
INSERT INTO `oxconfigdisplay` VALUES('08a9473894d473f6ed28f04e80d929fc', 'theme:basic', 'bl_showCompareList',     'features', '', 6);
INSERT INTO `oxconfigdisplay` VALUES('08acb2f595da54b5f865e54aa5cdb967', 'theme:basic', 'bl_showListmania',       'features', '', 7);
INSERT INTO `oxconfigdisplay` VALUES('08a12329124850cd8f63cda6e8e7b4e1', 'theme:basic', 'bl_showWishlist',        'features', '', 8);
INSERT INTO `oxconfigdisplay` VALUES('08a23429124850cd8f63cda6e8e7b4e1', 'theme:basic', 'bl_showVouchers',        'features', '', 8);
INSERT INTO `oxconfigdisplay` VALUES('08a34529124850cd8f63cda6e8e7b4e1', 'theme:basic', 'bl_showGiftWrapping',    'features', '', 10);
INSERT INTO `oxconfigdisplay` VALUES('08a45629124850cd8f63cda6e8e7b4e1', 'theme:basic', 'bl_showOpenId',          'features', '', 11);
INSERT INTO `oxconfigdisplay` VALUES('069425a324684b6c089769ee77426393', 'theme:basic', 'bl_perfShowLeftBasket',  'display',  '', 12);
INSERT INTO `oxconfigdisplay` VALUES('069425a324685ee7745199.098323559', 'theme:basic', 'bl_perfShowRightBasket', 'display',  '', 13);
INSERT INTO `oxconfigdisplay` VALUES('069425a32468ee77455199.098243559', 'theme:basic', 'bl_perfShowTopBasket',   'display',  '', 14);
INSERT INTO `oxconfigdisplay` VALUES('05342e4cab0ee774acb3905838384984', 'theme:basic', 'blShowBirthdayFields',   'display',  '', 15);
INSERT INTO `oxconfigdisplay` VALUES('01296159b2341d31b93423972af6150b', 'theme:basic', 'blTopNaviLayout',        'display',  '', 16);
INSERT INTO `oxconfigdisplay` VALUES('01296159b7641d31b93423972af6150b', 'theme:basic', 'iTopNaviCatCount',       'display',  '', 17);
INSERT INTO `oxconfigdisplay` VALUES('073455b29d0db9ee774b788731623955', 'theme:basic', 'blShowFinalStep',        'display',  '', 18);
INSERT INTO `oxconfigdisplay` VALUES('0ec42a395d0595ee7741091898848474', 'theme:basic', 'iNewBasketItemMessage',  'display',  '0|1|2|3', 19);
INSERT INTO `oxconfigdisplay` VALUES('0545423fe8ce213a06.20230295', 'theme:basic', 'aNrofCatArticles', 'display',   '', 20);
INSERT INTO `oxconfigdisplay` VALUES('omc4555952125c3c2.98253113',  'theme:basic', 'blDisableNavBars', 'display',   '', 21);

#
# config variables for list type display options
# created 2010-12-14
#
INSERT INTO `oxconfigdisplay` VALUES('1ec4235c2aee774aa45d772875437919', 'theme:azure', 'sIconsize',              'images',   '', 1);
INSERT INTO `oxconfigdisplay` VALUES('1563fba1bee774aec57c192086494217', 'theme:azure', 'sThumbnailsize',         'images',   '', 2);
INSERT INTO `oxconfigdisplay` VALUES('1563fba1bee774aec599d56894094456', 'theme:azure', 'sCatThumbnailsize',      'images',   '', 3);
INSERT INTO `oxconfigdisplay` VALUES('12642dfaa1dee77488b1b22948593071', 'theme:azure', 'sZoomImageSize',         'images',   '', 4);
INSERT INTO `oxconfigdisplay` VALUES('12642dfaa1dee77487d0644506753921', 'theme:azure', 'aDetailImageSizes',      'images',   '', 5);
INSERT INTO `oxconfigdisplay` VALUES('18a9473894d473f6ed28f04e80d929fc', 'theme:azure', 'bl_showCompareList',     'features', '', 6);
INSERT INTO `oxconfigdisplay` VALUES('18acb2f595da54b5f865e54aa5cdb967', 'theme:azure', 'bl_showListmania',       'features', '', 7);
INSERT INTO `oxconfigdisplay` VALUES('18a12329124850cd8f63cda6e8e7b4e1', 'theme:azure', 'bl_showWishlist',        'features', '', 8);
INSERT INTO `oxconfigdisplay` VALUES('18a23429124850cd8f63cda6e8e7b4e1', 'theme:azure', 'bl_showVouchers',        'features', '', 8);
INSERT INTO `oxconfigdisplay` VALUES('18a34529124850cd8f63cda6e8e7b4e1', 'theme:azure', 'bl_showGiftWrapping',    'features', '', 10);
INSERT INTO `oxconfigdisplay` VALUES('18a45629124850cd8f63cda6e8e7b4e1', 'theme:azure', 'bl_showOpenId',          'features', '', 11);
INSERT INTO `oxconfigdisplay` VALUES('15342e4cab0ee774acb3905838384984', 'theme:azure', 'blShowBirthdayFields',   'display',  '', 15);
INSERT INTO `oxconfigdisplay` VALUES('11296159b7641d31b93423972af6150b', 'theme:azure', 'iTopNaviCatCount',       'display',  '', 17);
INSERT INTO `oxconfigdisplay` VALUES('173455b29d0db9ee774b788731623955', 'theme:azure', 'blShowFinalStep',        'display',  '', 18);
INSERT INTO `oxconfigdisplay` VALUES('6ec4235c2aee774aa45d772875437789', 'theme:azure',   'sManufacturerIconsize',  'images',   '', 6);
INSERT INTO `oxconfigdisplay` VALUES('8563fba1bee774aec57c192086494897', 'theme:azure',   'sCatIconsize',           'images',   '', 7);
INSERT INTO `oxconfigdisplay` VALUES('8563fba1bee774aec599d56894094987', 'theme:azure',   'sCatPromotionsize',      'images',   '', 8);
INSERT INTO `oxconfigdisplay` VALUES('1ec42a395d0595ee7741091898848989', 'theme:azure', 'sDefaultListDisplayType',  'display',  'infogrid|line|grid', 21);
INSERT INTO `oxconfigdisplay` VALUES('1ec42a395d0595ee7741091898848990', 'theme:azure', 'blShowListDisplayType',  'display',  '', 20);
INSERT INTO `oxconfigdisplay` VALUES('1ec42a395d0595ee7741091898848474', 'theme:azure', 'iNewBasketItemMessage',  'display',  '0|1', 19);
INSERT INTO `oxconfigdisplay` VALUES('1545423fe8ce213a06.20230295', 'theme:azure', 'aNrofCatArticles', 'display',   '', 22);
INSERT INTO `oxconfigdisplay` VALUES('1ec42a395d0595ee7741091898848991', 'theme:azure', 'aNrofCatArticlesInGrid', 'display',   '', 23);

#
# Table structure for table `oxtplblocks`
# for storing blocks for template parts override
# created 2010-10-12
#

CREATE TABLE `oxtplblocks` (
    `OXID`        char(32) character set latin1 collate latin1_general_ci NOT NULL,
    `OXACTIVE`    tinyint(1) NOT NULL DEFAULT '1',
    `OXSHOPID`    char(32) character set latin1 collate latin1_general_ci NOT NULL,
    `OXTEMPLATE`  char(64) character set latin1 collate latin1_general_ci NOT NULL,
    `OXBLOCKNAME` char(32) character set latin1 collate latin1_general_ci NOT NULL,
    `OXPOS`       int  NOT NULL,
    `OXFILE`      char(64) character set latin1 collate latin1_general_ci NOT NULL,
    `OXMODULE`    char(32) character set latin1 collate latin1_general_ci NOT NULL,
    PRIMARY KEY (`OXID`),
    INDEX `search` (`OXACTIVE`, `OXTEMPLATE`, `OXPOS`)
) ENGINE=MyISAM;


# updating Taiwan country name
# created 2010-11-26

UPDATE `oxcountry` SET oxtitle = 'Republik China (Taiwan)', oxtitle_1 = 'Taiwan, Province of China' WHERE `oxid` = '8f241f11096687ec7.58824735';


#
# table changes for banners
#

ALTER TABLE `oxactions`
    ADD COLUMN `OXPIC`   VARCHAR(128) NOT NULL DEFAULT '' AFTER `OXACTIVETO`,
    ADD COLUMN `OXLINK`   VARCHAR(128) NOT NULL DEFAULT '' AFTER `OXPIC`;

ALTER TABLE `oxpayments` CHANGE `OXLONGDESC` `OXLONGDESC` text COLLATE latin1_general_ci NOT NULL DEFAULT '';

ALTER TABLE  `oxcategories` ADD  `OXPROMOICON` VARCHAR(128) NOT NULL DEFAULT  '' AFTER  `OXICON`;
ALTER TABLE  `oxorderarticles` ADD  `OXISBUNDLE` TINYINT( 1 ) NOT NULL DEFAULT  '0';

UPDATE `oxshops` SET `OXVERSION` = '4.5.0';

#add new conditions
INSERT INTO `oxcontents` VALUES ('220404cee0caf470e227c1c9f1ec4ae3', 'oxrighttocancellegend2', 'oxbaseshop', 1, 0, 1, 1, '', 'Widerrufsrecht Hinweistext', '[{oxifcontent ident="oxagb" object="oCont"}]\r\n    Es gelten unsere <a id="orderConfirmAgbBottom" rel="nofollow" href="[{ $oCont->getLink() }]" onclick="window.open(''[{ $oCont->getLink()|oxaddparams:"plain=1"}]'', ''agb_popup'', ''resizable=yes,status=no,scrollbars=yes,menubar=no,width=620,height=400'');return false;" class="fontunderline">Allgemeinen Gesch�ftsbedingungen</a>.&nbsp;\r\n[{/oxifcontent}]\r\n[{oxifcontent ident="oxrightofwithdrawal" object="oCont"}]\r\n    Hier finden Sie Einzelheiten zum <a id="test_OrderOpenWithdrawalBottom" rel="nofollow" href="[{ $oCont->getLink() }]" onclick="window.open(''[{ $oCont->getLink()|oxaddparams:"plain=1"}]'', ''rightofwithdrawal_popup'', ''resizable=yes,status=no,scrollbars=yes,menubar=no,width=620,height=400'');return false;">Widerrufsrecht</a>.\r\n[{/oxifcontent}]', 'Right to Cancel Legend', '[{oxifcontent ident="oxagb" object="oCont"}] Our general <a id="orderConfirmAgbBottom" rel="nofollow" href="[{ $oCont->getLink() }]" onclick="window.open(''[{ $oCont->getLink()|oxaddparams:"plain=1"}]'', ''agb_popup'', ''resizable=yes,status=no,scrollbars=yes,menubar=no,width=620,height=400'');return false;" class="fontunderline">terms and conditions</a> apply.&nbsp;\r\n[{/oxifcontent}]\r\n[{oxifcontent ident="oxrightofwithdrawal" object="oCont"}]\r\n    Read details about  <a id="test_OrderOpenWithdrawalBottom" rel="nofollow" href="[{ $oCont->getLink() }]" onclick="window.open(''[{ $oCont->getLink()|oxaddparams:"plain=1"}]'', ''rightofwithdrawal_popup'', ''resizable=yes,status=no,scrollbars=yes,menubar=no,width=620,height=400'');return false;">right of withdrawal</a>.\r\n[{/oxifcontent}]', 1, '', '', 1, '', '', '8a142c3e4143562a5.46426637', 'CMSFOLDER_USERINFO', '');
