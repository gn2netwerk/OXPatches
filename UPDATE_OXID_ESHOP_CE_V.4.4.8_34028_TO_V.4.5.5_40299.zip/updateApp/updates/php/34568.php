<?php
/**
 * This Software is the property of OXID eSales and is protected
 * by copyright law - it is NOT Freeware.
 *
 * Any unauthorized use of this software without a valid license key
 * is a violation of the license agreement and will be prosecuted by
 * civil and criminal law.
 *
 * @link http://www.oxid-esales.com
 * @package updateApp
 * @copyright (C) OXID eSales AG 2003-2011
 * @version OXID eShop PE
 */

/**
 * update class for rev.
 */
class update_34568 extends updateBase
{
    /**
     * default action, used in start update
     *
     * @var string
     */
    protected $_sDefaultAction = 'requestPermissionToProceed';

    /**
     * Database field, source and new target structure
     * @var array
     */
    protected $_aMasterPaths = array(
                        "oxcategories"    => array( "oxicon"      => array( "icon",  "master/category/icon", "sCatIconsize" ),
                                                    "oxpromoicon" => array( "icon",  "master/category/promo_icon", "sCatPromotionsize" ),
                                                    "oxthumb"     => array( "0",     "master/category/thumb", "sCatThumbnailsize" ) ),
                        "oxmanufacturers" => array( "oxicon"      => array( "icon",  "master/manufacturer/icon", "sManufacturerIconsize" ) ),
                        "oxvendor"        => array( "oxicon"      => array( "icon",  "master/vendor/icon", "sManufacturerIconsize" ) ),
                        "oxwrapping"      => array( "oxpic"       => array( "0",     "master/wrapping" ) ),
                        "oxarticles"      => array( "oxicon"      => array( "icon",  "master/product/icon", "sIconsize" ),
                                                    "oxthumb"     => array( "0",     "master/product/thumb", "sThumbnailsize" ) )
                       );
    /**
     * Number of records to monitor for file relocation
     * @var int
     */
    protected $_iMaxRecords = 50;

    /**
     * Adds product picture paths
     *
     * @param string $sPicturesPath path to check
     *
     * @return array
     */
    protected function _addPathInfo( $sPicturesPath )
    {
        // appending product zoom images folder
        foreach ( glob( "{$sPicturesPath}master/*", GLOB_ONLYDIR ) as $sFolderName ) {
            $sFolderName = basename( $sFolderName );
            if ( strcmp( $sFolderName, (int) $sFolderName ) == 0 ) {
                $this->_aMasterPaths["oxarticles"]["oxpic{$sFolderName}"] = array( "master/$sFolderName", "master/product/{$sFolderName}" );
            }
        }

        return $this->_aMasterPaths;
    }

    /**
     * Returns base pictures folder
     *
     * @return string
     */
    protected function _getPicturePath()
    {
        return $this->getConfig()->getPicturePath( "", false, 0 );
    }

    /**
     * Checks if path/db field mapping is valid
     *
     * @param string $sQ     query string
     * @param array  $aPaths path array
     * @param string $sTable table name
     * @param array  $aPath  current record path info
     * @param string $sField check field name
     * @param bool   $blUnset unset non existing or not
     *
     * @return null
     */
    protected function _checkPath( $sQ, & $aPaths, $sTable, $aPath, $sField, $blUnset = true )
    {
        $oRs = oxDb::getDb(true)->execute( $sQ );
        if ( $oRs != false && $oRs->recordCount() > 0 ) {
            while ( !$oRs->EOF ) {
                $sField = strtolower( $oRs->fields["Field"] );
                // appending new columns
                if ( !isset( $aPaths[$sTable][$sField] ) ) {
                    $aPaths[$sTable][$sField] = $aPath;
                }
                $oRs->moveNext();
            }
        } elseif ( $blUnset ) {
            // unsetting non existing fields
            unset( $aPaths[$sTable][$sField] );
            if ( count( $aPaths[$sTable] ) == 0 ) {
                unset( $aPaths[$sTable] );
            }
        }
    }

    /**
     * Relocates source file to given target. If relocation failed - sends error
     * message to UI and returns false
     *
     * @param string $sSource source
     * @param string $sTarget targer
     * @param bool   $blMove  move or just copy source image
     *
     * @return bool
     */
    protected function _relocate( $sSource, $sTarget, $blMove = true )
    {
        $blPicMoved = true;
        if ( !file_exists( $sTarget ) ) {
            $blPicMoved = file_exists( $sSource ) && is_readable( $sSource );
            if ( $blPicMoved ) {
                $blPicMoved = $blMove ? @rename( $sSource, $sTarget ) : @copy( $sSource, $sTarget );
            }
        }

        // sometimes rename returns false even if it copies..
        if ( !$blPicMoved ) {
            $blPicMoved = file_exists( $sTarget );
            // removing source..
            if ( $blMove && $blPicMoved ) {
                @unlink( $sSource );
            }
        }

        // if source file exists and readable also of target file does not exist yet
        /*
        if ( !$blPicMoved ) {
            // throw error: unable to move file
            $oUI = $this->_getProcess()->getUI();
            $oInfo = $oUI->createTextNotification();
            $oInfo->setText( "Unable to move file \"{$sSource}\"/\"{$sTarget}\"" );
            $oUI->addErrorForUser( $oInfo, false, false );
        }
        */

        return $blPicMoved;
    }

    /**
     * Relocates image files
     *
     * @param array $aPaths     image path info
     * @param int   $iStartFrom start move files from position
     *
     * @return null
     */
    protected function _relocateFiles( & $aPaths, & $iStartFrom )
    {
        $sPicturesPath = $this->_getPicturePath();
        $aPathInfo = reset( $aPaths );
        $sTable = key( $aPaths );

        foreach ( $aPathInfo as $sField => $aPath ) {
            list( $sSourceDir, $sMasterTargetDir ) = $aPath;

            // start listing records from line..
            $iStartFrom = (int) $iStartFrom;


            $sQ = "select {$sField}, oxshopid from " . getViewName( $sTable, -1, -1 ) . " where {$sField} != '' limit {$iStartFrom}, {$this->_iMaxRecords}";

            $oRs = oxDb::getDb(true)->execute( $sQ );
            if ( $oRs != false && $oRs->recordCount() > 0 ) {
                while ( !$oRs->EOF ) {
                    $sFileName = basename( reset( $oRs->fields ) );
                    $sShopId   = next( $oRs->fields );

                    // do not move nopic files..
                    if ( $sFileName != "nopic.jpg" && $sFileName != "nopic_ico.jpg" ) {

                        $blMove = true;

                        // category promo, regular icons and thumbs must be copied, not moved
                        if ( $sTable == "oxcategories" ) {
                            if( strpos( $sField, "oxpromoicon" ) !== false || strpos( $sField, "oxicon" ) !== false || strpos( $sField, "oxthumb" ) !== false ) {
                               $blMove = false;
                            }
                        }

                        // manufacturer/vendor icons must be copied, not moved
                        if ( $sTable == "oxmanufacturers" || $sTable == "oxvendor" ) {
                            if( strpos( $sField, "oxicon" ) !== false ) {
                               $blMove = false;
                            }
                        }

                        // product icons and thumbs must be copied, not moved
                        if ( $sTable == "oxarticles" ) {
                            if ( strpos( $sField, "oxicon" ) !== false || strpos( $sField, "oxthumb" ) !== false ) {
                               $blMove = false;
                            }
                        }

                        $this->_relocate( $sPicturesPath . $sSourceDir . "/" . $sFileName, $sPicturesPath . $sMasterTargetDir  . "/" . $sFileName, $blMove );
                        if ( $sTable != "oxwrapping" ) {

                            // removing master folder name from path
                            // as we are moving not from master dir
                            $sGeneratedSourceDir = str_ireplace("master/", "", $sSourceDir );
                            $sGeneratedTargetDir = preg_replace( "#master/#", "generated/", $sMasterTargetDir );

                            //if this is oxarticle table and picture oxpic field,
                            //also moving "ico" and zoom files
                            if ( $sTable == "oxarticles") {
                                if ( strpos($sField, "oxpic") === 0 ) {

                                    // moving main pic
                                    $sTargetDir = $this->_getGeneratedPicPath( $sGeneratedTargetDir, $sShopId, $sTable, $sField );
                                    $this->_makeDir( $sPicturesPath . $sTargetDir );
                                    $this->_relocate( $sPicturesPath . $sGeneratedSourceDir . "/" . $sFileName, $sPicturesPath . $sTargetDir  . "/" . $sFileName );

                                    //moving ico file (generated from main pic file)
                                    $sTargetDir = $this->_getGeneratedPicPath( $sGeneratedTargetDir, $sShopId, $sTable, "oxicon" );
                                    $this->_makeDir( $sPicturesPath . $sTargetDir );
                                    $sIcoFileName = preg_replace( "/(\.\w+$)/", "_ico$1", $sFileName );
                                    $this->_relocate( $sPicturesPath . $sGeneratedSourceDir . "/" . $sIcoFileName, $sPicturesPath . $sTargetDir  . "/" . $sFileName );

                                    //moving thumbnail file (generated from main pic1 file)
                                    if ( $sField == "oxpic1" ) {
                                        $sTargetDir = $this->_getGeneratedPicPath( $sGeneratedTargetDir, $sShopId, $sTable, "oxthumb" );
                                        $this->_makeDir( $sPicturesPath . $sTargetDir );
                                        $sIcoFileName = preg_replace( "/(\.\w+$)/", "_th$1", $sFileName );
                                        $sThumbSourceDir = preg_replace( "/(\d+$)/", "0", $sGeneratedSourceDir );
                                        $this->_relocate( $sPicturesPath . $sThumbSourceDir . "/" . $sIcoFileName, $sPicturesPath . $sTargetDir  . "/" . $sFileName );
                                    }

                                    //moving zoom image
                                    $sTargetDir = $this->_getGeneratedPicPath( $sGeneratedTargetDir, $sShopId, $sTable, "oxzoom" );
                                    $this->_makeDir( $sPicturesPath . $sTargetDir );
                                    preg_match( "/(\d+)$/", $sMasterTargetDir, $aMatches );
                                    $iIndex = $aMatches[1];
                                    $sZoomSourceDir = preg_replace( "/(\d+)$/", "z$1", $sGeneratedSourceDir );
                                    $sZoomFileName = preg_replace( "/(\.\w+)$/", "_z".$iIndex."\\1", $sFileName );
                                    $this->_relocate( $sPicturesPath . $sZoomSourceDir . "/" . $sZoomFileName, $sPicturesPath . $sTargetDir  . "/" . $sFileName );

                                } else {
                                    $sTargetDir = $this->_getGeneratedPicPath( $sGeneratedTargetDir, $sShopId, $sTable, $sField );
                                    $this->_makeDir( $sPicturesPath . $sTargetDir );
                                    $this->_relocate( $sPicturesPath . $sGeneratedSourceDir . "/" . $sFileName, $sPicturesPath . $sTargetDir  . "/" . $sFileName );
                                }
                            } else {
                                $sTargetDir = $this->_getGeneratedPicPath( $sGeneratedTargetDir, $sShopId, $sTable, $sField );
                                $this->_makeDir( $sPicturesPath . $sTargetDir );
                                $this->_relocate( $sPicturesPath . $sGeneratedSourceDir . "/" . $sFileName, $sPicturesPath . $sTargetDir  . "/" . $sFileName );
                            }
                        }
                    }
                    $oRs->moveNext();
                    $iStartFrom++;
                }
                break;
            } else {
                // cleanup
                unset( $aPaths[$sTable][$sField] );
                if ( count( $aPaths[$sTable] ) == 0 ) {
                    unset( $aPaths[$sTable] );
                }
                $iStartFrom = 0;
            }
        }
    }

    /**
     * Tries to create requested folder, returns creation status -
     * TRUE if no error occured, FALSE on error
     *
     * @param string $sNewPath path to create
     *
     * @return string
     */
    protected function _makeDir( $sNewPath )
    {
        $blOk = true;

        $sInfoText = "<hr> Please read more information about pictures update process at <a href='http://wiki.oxidforge.org/Tutorials/image_handling_changes#Running_update_application' target='_blank'>wiki.oxidforge.org</a>.";

        if ( !file_exists( $sNewPath ) ) {
            $iMode = 0755;
            if ( defined( 'OXID_PHP_UNIT' ) ) {
                $iMode = 0777;
            }
            if ( ! mkdir( $sNewPath, $iMode, true ) ) {

                // throw error: unable create full folder structure
                $oUI = $this->_getProcess()->getUI();
                $oInfo = $oUI->createTextNotification();
                $oInfo->setText( "Can not create folder \"{$sNewPath}\"" . $sInfoText );
                $oUI->addErrorForUser( $oInfo, false, false );
                $blOk = false;
            }
        } elseif ( !is_writable( $sNewPath ) ) {

            // throw error: unable to write to folder
            $oUI = $this->_getProcess()->getUI();
            $oInfo = $oUI->createTextNotification();
            $oInfo->setText( "Unable to write to folder \"{$sNewPath}\"" . $sInfoText );
            $oUI->addErrorForUser( $oInfo, false, false );
            $blOk = false;
        }
        return $blOk;
    }

    /**
     * requests user to answer the question
     *
     * @return string
     */
    public function requestPermissionToProceed()
    {
        $sPicturesPath = $this->_getPicturePath();

        $oUI = $this->_getProcess()->getUI();
        $oInfo = $oUI->createRadioBtnQuestion();
        $oInfo->setOptions( array( "1" => "Yes", "2" => "No" ) );
        $sDescription  = "Do you want to move master and resized image files to new destination?";
        $sDescription .= "<br><br><span style='font-size:11px; color: #900;'>Please backup existing images stored at \"{$sPicturesPath}\". ";
        $sDescription .= "Script will create new folders and move related images to them.</span>";
        $sDescription .= "<hr>";
        $sDescription .= "<div style='font-size:11px;'>More information about update process you find at <a href='http://wiki.oxidforge.org/Tutorials/image_handling_changes#Running_update_application' target='_blank'>wiki.oxidforge.org</a>.</div>";

        $oInfo->setDescription( $sDescription );
        $oUI->userInputRequest( "reqId1", array( "q1" => $oInfo ), "Relocating (moving) image files" );

        return "collectPathInfo";
    }

    /**
     * Collects image directory structure information. Returns next task
     * name and task persistent info
     *
     * @return array
     */
    public function collectPathInfo()
    {
        $aResponse = $this->_getProcess()->getUI()->getUserAnswer( "reqId1" );
        if ( isset( $aResponse["q1"] ) && $aResponse["q1"] == 1 ) {

            // collecting path info
            $aPaths = $this->_addPathInfo( $this->_getPicturePath() );

            return array( "createFolderStructure", serialize( $aPaths ) );
        } else {
            return "updateSql";
        }
    }

    /**
     * Displays folder creation error. Returns next task name
     *
     * @param string $sError error text
     *
     * @return string
     */
    public function displayError( $sError )
    {
        $oUI = $this->_getProcess()->getUI();
        $oInfo = $oUI->createRadioBtnQuestion();
        $oInfo->setDescription( "<span style='font-size:11px; color: #900;'>{$sError}</span>" );
        $oUI->userInputRequest( "reqId1", array( "q1" => $oInfo ), "Please check folder permissions" );

        return "requestPermissionToProceed";
    }

    /**
     * Creates folder structure according to info array collected by
     * collectPathInfo() method. Returns next task name and task
     * persistent info
     *
     * @param string $sPathInfo serialized path info array
     *
     * @return array
     */
    public function createFolderStructure( $sPathInfo )
    {
        if ( ( $aPaths = unserialize( $sPathInfo ) ) !== false ) {

            $sPicturesPath = $this->_getPicturePath();

            $sInfoText = "<hr> Please read more information about pictures update process at <a href='http://wiki.oxidforge.org/Tutorials/image_handling_changes#Running_update_application' target='_blank'>wiki.oxidforge.org</a>.";

            // try to create directory structure first, so will be able to check file/folder permissions
            foreach ( $aPaths as $sTable => $aPathInfo ) {
                foreach ( $aPathInfo as $sField => $aPath ) {
                    list( , $sNewPath ) = $aPath;

                    if ( !$this->_makeDir( $sPicturesPath . $sNewPath ) ) {

                        // unable to create folder
                        return array( "displayError", "Unable to create folder \"{$sPicturesPath}{$sNewPath}\"" . $sInfoText );
                    }
                }
            }

        }

        return array( "collectDbInfo", serialize( $aPaths ) );
    }

    /**
     * Checks and collects database info related to images which
     * needs to be moved to the new destination. Returns next
     * task name and task persistent info
     *
     * @param string $sPathInfo serialized path info array
     *
     * @return array
     */
    public function collectDbInfo( $sPathInfo )
    {
        if ( ( $aPaths = unserialize( $sPathInfo ) ) !== false ) {

            // exists oxfield2shop table?
            $blField2Shop = oxDb::getDb(true)->getOne( "show tables like 'oxfield2shop'" );

            // collecting field names (multilanguage) where image info is stored
            foreach ( $aPaths as $sTable => $aPathInfo ) {

                foreach ( $aPathInfo as $sField => $aPath ) {

                    $sQ = "show columns from " . getViewName( $sTable, -1, -1 ) . " where field regexp '{$sField}.*'";
                    $this->_checkPath( $sQ, $aPaths, $sTable, $aPath, $sField );

                    // check in field2shop table
                    if ( $blField2Shop ) {
                        $sQ = "show columns from " . getViewName( "oxfield2shop", -1, -1 ) . " where field regexp '{$sField}.*'";
                        $this->_checkPath( $sQ, $aPaths, $sTable, $aPath, $sField, false );
                    }
                }
            }
        }

        return array( "relocateImageFiles", serialize( array( $aPaths, 0 ) ) );
    }

    /**
     * Relocates image files to repated folders
     *
     * @param string $sPathInfo serialized path info array
     *
     * @return mixed
     */
    public function relocateImageFiles( $sPathInfo )
    {
        if ( ( $aInfo = unserialize( $sPathInfo ) ) !== false ) {

            list( $aPaths, $iStartFrom ) = $aInfo;

            // moving image files
            $this->_relocateFiles( $aPaths, $iStartFrom );

            // continue if there is something to movw
            if ( count( $aPaths ) ) {
                return array( "relocateImageFiles", serialize( array( $aPaths, $iStartFrom ) ) );
            } else {
                // if last image was moved - moving nopic file also
                $sPicturesPath = $this->_getPicturePath();
                $this->_relocate( $sPicturesPath . "master/1/nopic.jpg", $sPicturesPath . "master/nopic.jpg" );
            }
        }

        return "renameFileUploadFolder";
    }

    /**
     * Renames media files upload folder "pictures/0" to "pictures/media"
     *
     * @return string
     */
    public function renameFileUploadFolder()
    {
        $blDirMoved = true;
        $sPicturesPath = $this->_getPicturePath();
        $sSource = $sPicturesPath . "0";
        $sTarget = $sPicturesPath . "media";

        if ( file_exists( $sSource ) && is_dir( $sSource ) ) {
            @rename( $sSource, $sTarget );
        }

        return "updateHtaccess";
    }

    /**
     * Returns new htaccess rule
     *
     * @return string
     */
    protected function _getNewHtaccessRule()
    {
        return "\nRewriteCond %{REQUEST_URI} (\/out\/pictures\/)\n".
               "RewriteCond %{REQUEST_FILENAME} !-f\n".
               "RewriteCond %{REQUEST_FILENAME} !-d\n".
               "RewriteRule (\.jpg|\.gif|\.png)$ core/utils/getimg.php\n";
    }

    /**
     * Updates .htaccess file by writing additional rewrite rules for image handling
     *
     * @return string
     */
    public function updateHtaccess()
    {
        $blUpdated = false;
        $sHtaccess = getShopBasePath().".htaccess";
        if ( is_readable( $sHtaccess ) && is_writable( $sHtaccess ) ) {
            $sContents = file_get_contents( $sHtaccess );
            $blUpdated = (bool) $sContents;

            if ( $sContents && strpos( $sContents, "getimg.php" ) === false ) {
                $sContents = str_replace( "</IfModule>", $this->_getNewHtaccessRule() . "</IfModule>", $sContents );

                // now truncating original and writing changed contents..
                if ( ( $oFile = @fopen( $sHtaccess, "w" ) ) !== false ) {
                    if ( ( $blUpdated = fwrite( $oFile, $sContents ) ) != false ) {
                        $blUpdated = fclose( $oFile );
                    }
                } else {
                    $blUpdated = false;
                }
            }
        }

        if ( !$blUpdated ) {
            $sInfoText = "<hr> Please read more information about pictures update process at <a href='http://wiki.oxidforge.org/Tutorials/image_handling_changes#Running_update_application' target='_blank'>wiki.oxidforge.org</a>.";
            $this->displayError( "Unable to update \".htaccess\" file" . $sInfoText );
        }

        return "updateSql";
    }

    /**
     * Display complete message
     *
     * @return null
     */
    public function updateSql( $iInStepCounter )
    {
        $sReturn = parent::updateSql( $iInStepCounter );

        $sText = "Update complete! <hr> Please read more information about finalizing pictures update process at <a href='http://wiki.oxidforge.org/Tutorials/image_handling_changes#Running_update_application' target='_blank'>wiki.oxidforge.org</a>.";
        $oUI = $this->_getProcess()->getUI();
        $oInfo = $oUI->createTextNotification();
        $oInfo->setText( $sText );
        $oUI->addInfoForUser( $oInfo, true, true );

        return $sReturn;
    }

    /**
     * Gets image size, quality and formats image new path
     *
     * @param string $sPath   path string which will be modified
     * @param string $sShopId shop ID
     * @param string $sTable  table name
     * @param string $sField  field name
     *
     * @return string
     */
    protected function _getGeneratedPicPath( $sPath, $sShopId, $sTable, $sField )
    {
        $sImageQuality = $this->_getThemeConfigValue( "sDefaultImageQuality", $sShopId );
        $sSize = $this->_getPicSize( $sShopId, $sTable, $sField );
        $sSize = str_replace( "*", "_", $sSize );

        $sPath .= '/' . $sSize . "_{$sImageQuality}";

        return $sPath;
    }

    /**
     * Gets picture size according it's type
     *
     * @param string $sShopId shop ID
     * @param string $sTable  table name
     * @param string $sField  field name
     *
     * @return string
     */
    protected function _getPicSize( $sShopId, $sTable, $sField )
    {
        $sSize = "";

        if ( isset( $this->_aMasterPaths[$sTable][$sField] ) && is_array($this->_aMasterPaths[$sTable][$sField])) {
            $sConfigVarName = end( $this->_aMasterPaths[$sTable][$sField] );
            reset( $this->_aMasterPaths );
        }

        switch ( $sTable ) {
            case "oxcategories":
                if ( strpos( $sField, "oxthumb") === 0 )  {
                    $sSize = $this->_getThemeConfigValue( "sCatThumbnailsize", $sShopId );
                } else {
                    $sSize = $this->_getThemeConfigValue( $sConfigVarName, $sShopId );
                }
                break;
            case "oxarticles":
                if ( strpos( $sField, "oxpic") === 0 )  {
                    $aSizes = $this->_getThemeConfigValue( "aDetailImageSizes", $sShopId );
                    $sSize  = $aSizes[$sField];
                } elseif ( strpos( $sField, "oxicon") === 0 )  {
                    $sSize = $this->_getThemeConfigValue( "sIconsize", $sShopId );
                } elseif ( strpos( $sField, "oxthumb") === 0 )  {
                    $sSize = $this->_getThemeConfigValue( "sThumbnailsize", $sShopId );
                } elseif ( strpos( $sField, "oxzoom") === 0 )  {
                    $sSize = $this->_getThemeConfigValue( "sZoomImageSize", $sShopId );
                }
                break;
            default:
                if ( $sConfigVarName ) {
                    $sSize = $this->_getThemeConfigValue( $sConfigVarName, $sShopId );
                }
        }
		
        
        /*if ( !$sSize ) {
            //error: no config value for pic size
            $oUI = $this->_getProcess()->getUI();
            $oInfo = $oUI->createTextNotification();
            $oInfo->setText( "Unable to get config value for \"{$sConfigVarName}\" " );
            $oUI->addErrorForUser( $oInfo, false, false );
        }*/

        return $sSize;
    }

    /**
     * Get theme config value. Searches in current active custom theme, if not found
     * then in parent theme, if not found again - in basic shop config values
     *
     * @param string $sVarName variable name
     * @param string $sShopID  variable type - arr, aarr, bool or str
     *
     * @return mixed
     */
    protected function _getThemeConfigValue( $sVarName, $sShopID )
    {
        $sTheme = "theme:" . $this->_getConfVar( "sCustomTheme", $sShopID, null );
        $sParentTheme = "theme:" . $this->_getConfVar( "sTheme", $sShopID, null );

        $sValue = $this->_getConfVar( $sVarName, $sShopID, $sTheme );

        // searching value in parent theme
        if ( !$sValue ) {
            $sValue = $this->_getConfVar( $sVarName, $sShopID, $sParentTheme );
        }

        // searching value in basic theme
        if ( !$sValue ) {
            $sValue = $this->_getConfVar( $sVarName, $sShopID, null );
        }

        return $sValue;
    }


    /**
     * Get config variable value
     *
     * @param string $sVarName variable name
     * @param string $sShopID  variable type - arr, aarr, bool or str
     * @param string $sTheme   serialized by type value
     *
     * @return mixed
     */
    protected function _getConfVar( $sVarName, $sShopID, $sTheme )
    {
        $oDb = oxDb::getDb();
        $sQ = "select oxvarname, oxvartype, ".$this->_getDecodeValueQuery()." as oxvarvalue from oxconfig where oxshopid = '$sShopID' and oxmodule='$sTheme' and oxvarname = '$sVarName' limit 1 ";

        $oRs = $oDb->execute( $sQ );

        $sVarType = false;
        $sRetVal  = null;
        if ( $oRs != false && $oRs->recordCount() > 0 ) {
            while ( !$oRs->EOF ) {
                $sVarName = $oRs->fields[0];
                $sVarType = $oRs->fields[1];
                $sVarVal  = $oRs->fields[2];

                $oRs->moveNext();
            }
        }

        if ( $sVarType !== false ) {
            switch ( $sVarType ) {
                case 'arr':
                case 'aarr':
                    $sRetVal = unserialize( $sVarVal );
                    break;
                case 'bool':
                    $sRetVal =  ( $sVarVal == 'true' || $sVarVal == '1' );
                    break;
                default:
                    $sRetVal = $sVarVal;
                    break;
            }
        }

        return $sRetVal;
    }

    /**
     * Returns decode query part user to decode config field value
     *
     * @param string $sFieldName field name, default "oxvarvalue" [optional]
     *
     * @return string
     */
    protected function _getDecodeValueQuery( $sFieldName = "oxvarvalue" )
    {
        return " DECODE( {$sFieldName}, '".$this->getConfig()->getConfigParam( 'sConfigKey' )."') ";
    }

}