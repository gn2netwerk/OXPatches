<?php
/**
 *    This file is part of OXID eShop Community Edition.
 *
 *    OXID eShop Community Edition is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    OXID eShop Community Edition is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with OXID eShop Community Edition.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @link http://www.oxid-esales.com
 * @package updateApp
 * @copyright (C) OXID eSales AG 2003-2011
 * @version OXID eShop CE
 */

/**
 * base updater class, used for providing base utility functions
 */
class updateBase extends oxSuperCfg
{
    private $_oProcess = null;
    protected $_iRev = 0;
    static $SQL_TIME_LIMIT = 7;
    protected $_aMultilingualFields = null;

    /**
     * constructor
     *
     * @param updateProcess $oProcess parent process
     * @param int           $iRev     revision for this update
     */
    public function __construct(updateProcess $oProcess, $iRev)
    {
        $this->_oProcess = $oProcess;
        $this->_iRev = $iRev;

        if ( $this->getConfig()->isUtf() ) {
            $this->_getDb( true )->execute( "SET CHARACTER SET latin1" );
        }
    }

    /**
     * process object getter
     *
     * @return updateProcess
     */
    protected function _getProcess()
    {
        return $this->_oProcess;
    }

    /**
     * default action, used in start update
     *
     * @var string
     */
    protected $_sDefaultAction = 'updateSql';

    /**
     * revisioned updater entry
     * returns next action
     *
     * @param string $sAction action to execute
     * @param mixed  $data    action data
     *
     * @return null
     */
    public function update($sAction, $data)
    {
        if (!$sAction) {
            $sAction = $this->_sDefaultAction;
        }

        if ($sAction && method_exists($this, $sAction)) {
            $oUi = $this->_getProcess()->getUI();
            $oNote = $oUi->createTextNotification();
            $oNote->setText("[exec:] rev: $this->_iRev action: $sAction");
            $oUi->addInfoForUser($oNote, false);

            $sNext = $this->$sAction($data);
            $sNextData = 0;
            if (is_array($sNext) && count($sNext) == 2) {
                $sNextData = $sNext[1];
                $sNext = $sNext[0];
            }
            $iNextRev = $sNext ? $this->_iRev : $this->_iRev + 1;
            $this->_getProcess()->getTracker()->setNextStep(
                    $iNextRev,
                    $sNext,
                    $sNextData
            );
        } else {
            throw new Exception("action $sAction not found");
        }
    }

    /**
     * parse sql file to array
     *
     * @param int $iRev     revision
     * @param int $iCounter counter to slice from
     *
     * @return array
     */
    public function getSqlArray($iRev, $iCounter)
    {
        $sFile = $this->_getProcess()->getConfig()->getSqlPath()."/$iRev.sql";
        if (is_readable($sFile)) {
            $aSqls = preg_split('/;[\s]*$/m', file_get_contents($sFile));
            if ($iCounter) {
                $aSqls = array_slice($aSqls, $iCounter);
            }
            return $aSqls;
        }
        return array();
    }

    /**
     * updates sql and keeps track of last executed one
     *
     * @param int $iInStepCounter sql counter
     *
     * @return string
     */
    public function updateSql($iInStepCounter)
    {
        $iInStepCounter = (int) $iInStepCounter;
        $aSqls = $this->getSqlArray($this->_iRev, $iInStepCounter);
        if (count($aSqls)) {
            $oUi = $this->_getProcess()->getUI();
            $oNote = $oUi->createTextNotification();
            $start = time();
            foreach ($aSqls as $sSql) {
                $this->_getProcess()->getTracker()->setNextStep($this->_iRev, 'updateSql', ++$iInStepCounter);
                $sSql = trim($sSql);
                if ($sSql) {
                    $oNote->setText("[SQL:] $sSql");
                    $oUi->addInfoForUser($oNote, false);
                    $blResult = $this->_getDb()->execute($sSql);

                    if ( ! $blResult ) {

                       $oUI = $this->_getProcess()->getUI();
                       $oInfo = $oUI->createTextNotification();
                       $oInfo->setText( "Errors in SQL: " . $sSql . ', check this SQL script, fix it and run it manually. After this proceed updateApp by clicking "Continue" button.' );
                       $oUI->addErrorForUser( $oInfo, true, true );

					   return array('updateSql', $iInStepCounter);
                    }
                }
                if (time() - self::$SQL_TIME_LIMIT > $start) {
                    return array('updateSql', $iInStepCounter);
                }
            }
        }
        return 'updateMultilingualFields';
    }

    /**
     * updates oxconfig table - copy theme:basic values to theme:{curr theme}
     *
     * @param int $iInStepCounter step counter
     *
     * @return string
     */
    public function updateMultilingualFields($iInStepCounter)
    {
        if ( $this->_aMultilingualFields && is_array($this->_aMultilingualFields) ) {
            foreach ( $this->_aMultilingualFields as $sField => $sTable ) {
                $this->addMultilingualFields($sTable, $sField);
            }
        }

        return '';
    }

    /**
     * updates sql and keeps track of last executed one
     *
     * @param string $sTableName table name
     * @param string $sFieldName old field name
     *
     * @return string
     */
    public function addMultilingualFields($sTableName, $sFieldName)
    {
        $aSql = array();
        $aIndexesSql = array();

        $aLangData = $this->getConfig()->getConfigParam( 'aLanguages' );
        $sLastMultilangFieldName = $sFieldName;

        if ( is_array($aLangData) ) {
            $sLangCount    = (count($aLangData) < 5) ? 4 : count($aLangData);
            $sFieldTypeSql = $this->_getFieldTypeSql($sFieldName, $sTableName);
            $sIndexSql     = $this->_getTableIndex($sFieldName, $sTableName);
            for ( $iLang = 1; $iLang < $sLangCount; $iLang++ ) {
                $sTable = getLangTableName($sTableName, $iLang);
                $sNewFieldName = $sFieldName . "_" . $iLang;

                if ( !$this->fieldExists( $sNewFieldName, $sTableName ) ) {
                    $aSql[] = $this->_getDublicatedFieldSql( $sFieldName, $sNewFieldName, $sTable, $sFieldTypeSql, $sLastMultilangFieldName );

                    //getting create index sql on added field
                    if ( $sIndexSql ) {
                        $aFieldIndexSql[] = $this->_getDublicatedFieldIndexesSql( $sFieldName, $sNewFieldName, $sTable, $sIndexSql );
                    }
                } else {
                    $aSql[] = $this->_getUpdateFieldSql( $sFieldName, $sNewFieldName, $sTable, $sFieldTypeSql, $sLastMultilangFieldName );
                }
                $sLastMultilangFieldName = $sNewFieldName;
            }
        }

        if ( !empty($aSql) ) {
            $this->_executeSql( $aSql );
        }

        if ( !empty($aIndexesSql) ) {
            $this->_executeSql( $aIndexesSql );
        }

        $this->_updateViews();

        return '';
    }

    /**
     * Generates views
     *
     * @return null
     */
    protected function _updateViews()
    {
        oxDb::getInstance()->updateViews();
    }

    /**
     * Get sql string with old field type
     *
     * @param string $sOldFieldName old field name
     * @param string $sTableName    table name
     *
     * @return string
     */
    protected function _getFieldTypeSql( $sOldFieldName, $sTableName )
    {
        $aRes = $this->_getDb()->getAll("show create table {$sTableName}");
        $sSql = $aRes[0][1];

        preg_match( "/.*,\s+(['`]?".$sOldFieldName."['`]?\s+[^,]+),.*/", $sSql, $aMatch );
        $sFieldSql = $aMatch[1];

        return $sFieldSql;
    }

    /**
     * Get old field index
     *
     * @param string $sOldFieldName old field name
     * @param string $sTableName    table name
     *
     * @return string
     */
    protected function _getTableIndex( $sOldFieldName, $sTableName )
    {
        $aRes = $this->_getDb()->getAll("show create table {$sTableName}");
        $sSql = $aRes[0][1];

        preg_match_all("/([\w]+\s+)?\bKEY\s+(`[^`]+`)?\s*\([^)]+\)/iU", $sSql, $aMatch);

        $aIndexes = $aMatch[0];

        if ( !empty($aIndexes) ) {

            foreach ( $aIndexes as $sIndexSql ) {
                if ( preg_match("/\([^)]*\b" . $sOldFieldName . "\b[^)]*\)/i", $sIndexSql )  ) {

                    //removing index name - new will be added automaticly
                    $sIndexSql = preg_replace("/(.*\bKEY\s+)`[^`]+`/", "$1", $sIndexSql );
                }
            }

        }

        return $sIndexSql;
    }

    /**
     * Get sql string for dublicating multilang field
     *
     * @param string $sOldFieldName     old field name, which will be copied
     * @param string $sNewFieldName     new field name
     * @param string $sTableName        table name in which new field will be added
     * @param string $sInsertAfterField insert after field name
     * @param string $sFieldTypeSql     old field type, to add to new field
     *
     * @return string
     */
    protected function _getDublicatedFieldSql( $sOldFieldName, $sNewFieldName, $sTableName, $sFieldTypeSql, $sInsertAfterField = null )
    {
        $sFullSql = "";

        if ( !empty($sFieldTypeSql) ) {

            $sFieldTypeSql = preg_replace( "/" . $sOldFieldName . "/", $sNewFieldName, $sFieldTypeSql );
            $sFullSql = "ALTER TABLE `$sTableName` ADD " . $sFieldTypeSql;

            if ( $sInsertAfterField ) {
                $sFullSql .= " AFTER `$sInsertAfterField`";
            }
        }

        return $sFullSql;
    }

    /**
     * Get sql string for dublicating indexes for new multilang field
     *
     * @param string $sOldFieldName old field name, which index will be copied
     * @param string $sNewFieldName new field name
     * @param string $sTableName    table name in which new index will be added
     * @param string $sIndexSql     old field indexes
     *
     * @return string
     */
    protected function _getDublicatedFieldIndexesSql( $sOldFieldName, $sNewFieldName, $sTableName, $sIndexSql )
    {
        $sFullSql = "";

        $sIndexSql = preg_replace("/\b" . $sOldFieldName . "\b/", $sNewFieldName, $sIndexSql );
        $sFullSql = "ALTER TABLE `$sTableName` ADD ". $sIndexSql;

        return $sFullSql;
    }

    /**
     * Executes arrary of sql strings
     *
     * @param array $aSql SQL query array
     *
     * @return null
     */
    protected function _executeSql( $aSql )
    {
        $oDb = $this->_getDb();

        if ( is_array($aSql) && !empty($aSql) ) {
            foreach ( $aSql as $sSql) {
                $oDb->execute( $sSql );
            }
        }
    }

    /**
     * Get sql string for changing multilang field
     *
     * @param string $sOldFieldName old field name, which will be copied
     * @param string $sNewFieldName new field name
     * @param string $sTableName    table name in which new field will be added
     * @param string $sFieldTypeSql new field type
     *
     * @return string
     */
    protected function _getUpdateFieldSql( $sOldFieldName, $sNewFieldName, $sTableName, $sFieldTypeSql )
    {
        $sFullSql = "";

        if ( !empty($sFieldTypeSql) ) {

            $sFieldTypeSql = preg_replace( "/" . $sOldFieldName . "/", $sNewFieldName, $sFieldTypeSql );
            $sFullSql = "ALTER TABLE `$sTableName` CHANGE `$sNewFieldName` " . $sFieldTypeSql;
        }

        return $sFullSql;
    }

    /**
     *  Get table fields
     *
     *  @param string $sTableName table name
     *
     *  @return array
     */
    public function getFields( $sTableName )
    {
        $aFields = $this->_getDb()->MetaColumns( $sTableName );

        $aDbTablesFields[$sTableName] = array();

        foreach ( $aFields as $oField ) {
           $aDbTablesFields[$sTableName][] = $oField->name;
        }
        return $aDbTablesFields[$sTableName];
    }

    /**
     * Check if field exists in table
     *
     * @param string $sFieldName field name
     * @param string $sTableName table name
     *
     * @return bool
     */
    public function fieldExists( $sFieldName, $sTableName )
    {
        $aTableFields = $this->getFields( $sTableName );

        if ( is_array($aTableFields) ) {
            $sFieldName = strtoupper( $sFieldName );
            if ( in_array( $sFieldName, $aTableFields ) ) {
                return true;
            }
        }

        return false;
    }

    protected function _getDb( $blAssoc = false )
    {
        return oxDb::getDb($blAssoc);
    }
}
