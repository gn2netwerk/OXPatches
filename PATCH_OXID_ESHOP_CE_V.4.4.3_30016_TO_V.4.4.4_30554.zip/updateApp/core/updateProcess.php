<?php
/**
 *    This file is part of OXID eShop Community Edition.
 *
 *    OXID eShop Community Edition is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    OXID eShop Community Edition is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with OXID eShop Community Edition.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @link http://www.oxid-esales.com
 * @package updateApp
 * @copyright (C) OXID eSales AG 2003-2010
 * @version OXID eShop CE
 */

require_once dirname(__FILE__).'/updateConfig.php';
require_once dirname(__FILE__).'/updateTracker.php';
require_once dirname(__FILE__).'/updateBase.php';

/**
 * main call handler
 */
class updateProcess
{
    private $_oTracker = null;
    private $_oConfig  = null;
    private $_oUi      = null;

    /**
     * construct process object
     * 
     * @param IUpdateUI $oUI
     */
    public function __construct(IUpdateUI $oUI)
    {
        $this->_oUi = $oUI;
    }

    /**
     * get user interface object
     * 
     * @return IUpdateUI
     */
    public function getUI()
    {
        return $this->_oUi;
    }

    /**
     * return updateTracker
     * 
     * @return updateTracker
     */
    public function getTracker()
    {
        if (!$this->_oTracker) {
            $this->_oTracker = new updateTracker();
        }
        return $this->_oTracker;
    }

    /**
     * return updateConfig
     *
     * @return updateConfig
     */
    public function getConfig()
    {
        if (!$this->_oConfig) {
            $this->_oConfig = new updateConfig();
        }
        return $this->_oConfig;
    }

    /**
     * finds next suitable update step
     *
     * @return array
     */
    protected function _findNextStep()
    {
        $aNext = $this->getTracker()->getNextStep();
        if (!$aNext) {
            $aNext = array($this->getConfig()->getStartRevision(), '', 0);
        }
        return $aNext;
    }

    /**
     * return altered step with valid revision, null on error
     * 
     * @param array $aStep
     *
     * @return array
     */
    protected function _validateStep(array $aStep)
    {
        $aAllRevs = $this->getConfig()->getAvailableRevisions();

        foreach ($aAllRevs as $iRev) {
            if ($aStep[0] <= $iRev) {
                $aStep[0] = $iRev;
                return $aStep;
            }
        }
        return null;
    }

    /**
     * create updateBase for step
     *
     * @param array $aStep
     *
     * @return updateBase
     */
    protected function _updateFactory(array $aStep)
    {
        $iRev = $aStep[0];
        $sFile = $this->getConfig()->getPhpPath()."/$iRev.php";
        if (file_exists($sFile)) {
            require_once $sFile;
            $sClass = 'update_'.$iRev;
            if (class_exists($sClass)) {
                return new $sClass($this, $iRev);
            }
        }
        return new updateBase($this, $iRev);
    }

    /**
     * run single update step. return true if more steps pending
     *
     * @return bool
     */
    public function runStep()
    {
        $aStep = $this->_findNextStep();
        $aStep = $this->_validateStep($aStep);

        if (!$aStep) {
            $this->getTracker()->deleteTable();
            $oUi = $this->getUI();
            $oNote = $oUi->createTextNotification();

            if ( $this->_delUpdateApp() ) {
                $oNote->setText("Directory 'updateApp' was deleted after successful update.", false, true);
                $oUi->addInfoForUser($oNote, false, true);
            } else {
                $oNote->setText("Unable to delete 'updateApp' directory after update. Please delete it manualy!", false, true);
                $oUi->addErrorForUser($oNote);
            }
            return false;
        }

        $this->_updateFactory($aStep)->update($aStep[1], $aStep[2]);

        return true;
    }

    /**
     * #1216 delete updateApp directory
     *
     * @return bool
     */
    protected function _delUpdateApp()
    {
        return $this->_removeDir( dirname(__FILE__)."/../../updateApp", true );
    }

    /**
     * Delete directory
     *
     * @return bool
     */
    protected function _removeDir( $sPath, $blDeleteSuccess )
    {
        // setting path to remove
        $sPath = realpath( $sPath );
        $d = dir( $sPath );
        $d->handle;
        while (false !== ($entry = $d->read())) {
    
            if ( $entry != "." &&  $entry != "..") {
    
                $sFilePath = $sPath."/".$entry;
    
                if ( is_file($sFilePath)) {
                    // setting file status deletable
                    $blThisChMod = is_writable($sFilePath) ? true : @chmod( $sFilePath, 0755);
                    //deleting file if possible
                    if ( $blThisChMod) $blThisChMod = @unlink ( $sFilePath);
                    // setting global deletion status
                    $blDeleteSuccess = $blDeleteSuccess * $blThisChMod;
                } elseif ( is_dir($sFilePath)) {
                    // removing direcotry contents
                    $this->_removeDir( $sFilePath, $blDeleteSuccess);
                    // setting directory status deletable
                    $blThisChMod = is_writable($sFilePath) ? true : @chmod( $sFilePath, 0755);
                    //deleting directory if possible
                    if ( $blThisChMod) $blThisChMod = @rmdir ( $sFilePath);
                    // setting global deletion status
                    $blDeleteSuccess = $blDeleteSuccess * $blThisChMod;
                } else { // there are some other objects ?
                    $blDeleteSuccess = $blDeleteSuccess * false;
                }
            }
        }
        $d->close();
    
        return $blDeleteSuccess;
    }
}
